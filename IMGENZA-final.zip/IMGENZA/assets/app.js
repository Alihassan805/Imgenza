const LOGO='<span class="lgo" aria-hidden="true"><svg viewBox="0 0 64 64"><g class="lg-px"><rect x="12" y="13" width="11" height="11" rx="3" fill="#fff"/><rect x="26" y="8" width="11" height="11" rx="3" fill="#FFD166"/><rect x="40" y="14" width="11" height="11" rx="3" fill="#fff" opacity=".85"/></g><path d="M9 33c0 13 10 22 23 22s23-9 23-22z" fill="#fff"/><path d="M16 39c4 3 10 4.5 16 4.5S44 42 48 39" stroke="#7C5CFF" stroke-width="3.2" fill="none" stroke-linecap="round"/></svg></span>';
"use strict";
/* =====================================================================
   PIXELNEST  –  CORE
   Beginner map of this file:
     0. small helpers          3. IMAGE ENGINE (load, resize, save)
     1. SETTINGS you can edit  4. PIXEL EFFECTS (colors, blur, sharpen)
     2. toast + confetti       5. ZIP maker, 6. PDF maker, 7. EXIF reader
   Everything here is plain JavaScript. No library is needed for any of it
   (only HEIC photos use a small helper that downloads once).
   ===================================================================== */

/* ---------- 0. small helpers ---------- */
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const debounce = (fn, ms) => { let t; const f = (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; f.cancel = () => clearTimeout(t); return f; };
const coded = code => { const e = new Error(code); e.code = code; return e; };
const rafThrottle = fn => { let q = false, last; return (...a) => { last = a; if (q) return; q = true; requestAnimationFrame(() => { q = false; fn(...last); }); }; };

/* ---------- 1. SETTINGS (edit these!) ---------- */
const SITE = {
  name: 'IMGENZA',
  tagline: 'Every picture tool you need. Free.',
  email: ''                       // put your contact e-mail here, it shows on the Contact page
};
/* ADS: when you get AdSense approval set enabled:true, paste your ids, and set showPlaceholders:false.
   Ads live in their own boxes (top, side, inline, bottom). They never cover a tool or a button. */
const ADS = {
  enabled: false,
  client: 'ca-pub-XXXXXXXXXXXXXXXX',
  slots: { top: '', side: '', inline: '', bottom: '' },
  showPlaceholders: true
};
const PV_MAX = 1400;             // preview picture size (keeps sliders smooth)

/* ---------- 2. toast + confetti ---------- */
function toast(msg, kind = '') {
  const el = document.createElement('div');
  el.className = 'toast ' + kind; el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), 4600);
}
function confetti() {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const c = document.createElement('canvas'); c.className = 'confetti';
  c.width = innerWidth; c.height = innerHeight; document.body.appendChild(c);
  const x = c.getContext('2d'), cols = ['#5B4BFF', '#FF5C8A', '#FF9A3D', '#10B981', '#0EA5E9', '#F59E0B'];
  const P = Array.from({ length: 110 }, () => ({
    x: innerWidth / 2 + (Math.random() - .5) * 240, y: innerHeight * .75, vx: (Math.random() - .5) * 16, vy: -Math.random() * 17 - 6,
    s: 6 + Math.random() * 7, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[(Math.random() * cols.length) | 0]
  }));
  let f = 0;
  (function tick() {
    x.clearRect(0, 0, c.width, c.height);
    P.forEach(p => { p.vy += .45; p.x += p.vx; p.y += p.vy; p.r += p.vr; x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.s / 2, -p.s / 2, p.s, p.s * .6); x.restore(); });
    if (++f < 100) requestAnimationFrame(tick); else c.remove();
  })();
}

/* ---------- safe loader for the only outside helper (HEIC) ---------- */
const LIBS = { heic2any: { url: 'https://cdn.jsdelivr.net/npm/heic2any@0.0.4/dist/heic2any.min.js', global: 'heic2any' } };
const libCache = {};
function loadLib(name) {
  const L = LIBS[name];
  if (window[L.global]) return Promise.resolve(window[L.global]);
  if (!libCache[name]) {
    libCache[name] = new Promise((resolve, reject) => {
      const s = document.createElement('script'); s.src = L.url; s.async = true;
      const fail = () => { libCache[name] = null; s.remove(); reject(coded('NET')); };
      s.onload = () => window[L.global] ? resolve(window[L.global]) : fail();
      s.onerror = fail; document.head.appendChild(s);
    });
  }
  return libCache[name];
}

/* =====================================================================
   3. IMAGE ENGINE
   ===================================================================== */
const FMT = {
  jpg:  { key: 'jpg',  mime: 'image/jpeg', ext: 'jpg',  lossy: true },
  png:  { key: 'png',  mime: 'image/png',  ext: 'png',  lossy: false },
  webp: { key: 'webp', mime: 'image/webp', ext: 'webp', lossy: true }
};
const MIME_EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };
const IMG_EXT = ['png', 'jpg', 'jpeg', 'jfif', 'webp', 'gif', 'bmp', 'avif', 'svg', 'ico', 'heic', 'heif', 'tif', 'tiff'];
const heicCache = new WeakMap();

const Engine = {
  ext(n) { const m = /\.([a-z0-9]+)$/i.exec(n || ''); return m ? m[1].toLowerCase() : ''; },
  base(n) { return (n || 'picture').replace(/\.[^.]+$/, ''); },
  isImage(f) { return (f.type && f.type.startsWith('image/')) || IMG_EXT.includes(Engine.ext(f.name)); },
  isHeic(f) { const e = Engine.ext(f.name); return e === 'heic' || e === 'heif' || /hei[cf]/i.test(f.type || ''); },
  isSvg(f) { return Engine.ext(f.name) === 'svg' || f.type === 'image/svg+xml'; },
  formatBytes(b) {
    if (b < 1024) return b + ' B';
    if (b < 1048576) return (b / 1024).toFixed(b < 10240 ? 1 : 0) + ' KB';
    return (b / 1048576).toFixed(2) + ' MB';
  },
  canvas(w, h) {
    w = Math.round(w); h = Math.round(h);
    if (!(w >= 1 && h >= 1) || w > 16384 || h > 16384 || w * h > 268e6) throw coded('SIZE');
    const c = document.createElement('canvas'); c.width = w; c.height = h; return c;
  },
  /* HEIC files are turned into PNG first (needs internet once for the helper) */
  async blobFor(file) {
    if (!Engine.isHeic(file)) return file;
    if (heicCache.has(file)) return heicCache.get(file);
    const lib = await loadLib('heic2any');
    let r = await lib({ blob: file, toType: 'image/png' });
    r = Array.isArray(r) ? r[0] : r; heicCache.set(file, r); return r;
  },
  /* Load ANY picture. EXIF turning is respected.
     o.maxSide = make it smaller for fast preview.  o.width = wanted width (SVG only).
     Returns { src, w, h, ow, oh, s, close() }  (ow/oh = real original size, s = w/ow) */
  /* read width/height (+EXIF turn) from the first bytes of a file – no decoding, so it is instant */
  async dims(file) {
    try {
      const b = new Uint8Array(await file.slice(0, 262144).arrayBuffer()), u16 = i => (b[i] << 8) | b[i + 1], l16 = i => b[i] | (b[i + 1] << 8);
      if (b[0] === 0xFF && b[1] === 0xD8) {
        let i = 2, ori = 1;
        while (i < b.length - 9) {
          if (b[i] !== 0xFF) { i++; continue; }
          const m = b[i + 1]; if (m === 0xFF) { i++; continue; }
          if (m === 0xD8 || (m >= 0xD0 && m <= 0xD7) || m === 0x01) { i += 2; continue; }
          const len = u16(i + 2);
          if (m === 0xE1 && b[i + 4] === 0x45 && b[i + 5] === 0x78) {         // "Ex"if
            const t = i + 10, le = b[t] === 0x49, g = (p, n) => n === 2 ? (le ? l16(p) : u16(p)) : 0, ifd = t + (le ? (b[t + 4] | (b[t + 5] << 8) | (b[t + 6] << 16)) : ((b[t + 4] << 24) | (b[t + 5] << 16) | (b[t + 6] << 8) | b[t + 7]));
            const n = g(ifd, 2); for (let k = 0; k < n && k < 60; k++) { const e = ifd + 2 + k * 12; if (g(e, 2) === 0x0112) { ori = g(e + 8, 2); break; } }
          }
          if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) return { w: u16(i + 7), h: u16(i + 5), ori };
          i += 2 + len;
        }
        return null;
      }
      if (b[0] === 0x89 && b[1] === 0x50) return { w: (b[16] << 24) | (b[17] << 16) | (b[18] << 8) | b[19], h: (b[20] << 24) | (b[21] << 16) | (b[22] << 8) | b[23], ori: 1 };
      return null;
    } catch (e) { return null; }
  },
  /* fast path for thumbnails + previews: the browser shrinks the picture WHILE decoding (much faster, far less memory).
     We pass only ONE side so the browser keeps the shape itself – a turned (EXIF) photo can never be squashed. */
  async loadFast(file, o) {
    if (!o.maxSide || !self.createImageBitmap || Engine.isHeic(file) || Engine.isSvg(file)) return null;
    const d = await Engine.dims(file); if (!d || !d.w || !d.h) return null;
    const m = o.maxSide, long = Math.max(d.w, d.h), short = Math.min(d.w, d.h);
    if (long < m * 1.7) return null;
    try {
      const opt = { imageOrientation: 'from-image', resizeQuality: 'high' };
      if (d.w >= d.h) opt.resizeWidth = m; else opt.resizeHeight = m;
      const bm = await createImageBitmap(file, opt);
      const ow = bm.width >= bm.height ? long : short, oh = bm.width >= bm.height ? short : long;
      if (Math.abs(bm.width / bm.height - ow / oh) > 0.05) { bm.close(); return null; }
      const im = Engine.wrap(bm, bm.width, bm.height, () => bm.close && bm.close(), m);
      return Object.assign(im, { ow, oh, s: im.w / ow });
    } catch (e) { return null; }
  },
  async load(file, o = {}) {
    if (Engine.isSvg(file)) return Engine.loadSvg(file, o);
    const fast = await Engine.loadFast(file, o); if (fast) return fast;
    const blob = await Engine.blobFor(file);
    let src, w, h, close = () => {};
    try {
      const b = await createImageBitmap(blob, { imageOrientation: 'from-image' });
      src = b; w = b.width; h = b.height; close = () => b.close && b.close();
    } catch (e) { ({ src, w, h } = await Engine.imgEl(blob)); }
    return Engine.wrap(src, w, h, close, o.maxSide);
  },
  wrap(src, w, h, close, maxSide) {
    if (maxSide && Math.max(w, h) > maxSide) {
      const r = maxSide / Math.max(w, h), tw = Math.max(1, Math.round(w * r)), th = Math.max(1, Math.round(h * r));
      const c = Engine.resample(src, 0, 0, w, h, tw, th); close();
      return { src: c, w: tw, h: th, ow: w, oh: h, s: tw / w, close() {} };
    }
    return { src, w, h, ow: w, oh: h, s: 1, close };
  },
  imgEl(blob) {
    return new Promise((res, rej) => {
      const u = URL.createObjectURL(blob), im = new Image();
      im.onload = () => { URL.revokeObjectURL(u); res({ src: im, w: im.naturalWidth, h: im.naturalHeight }); };
      im.onerror = () => { URL.revokeObjectURL(u); rej(coded('DECODE')); };
      im.src = u;
    });
  },
  async loadSvg(file, o) {
    const root = new DOMParser().parseFromString(await file.text(), 'image/svg+xml').documentElement;
    if (!root || root.nodeName.toLowerCase() !== 'svg') throw coded('DECODE');
    let ratio = 1;
    const vb = (root.getAttribute('viewBox') || '').trim().split(/[\s,]+/).map(Number);
    const aw = parseFloat(root.getAttribute('width')), ah = parseFloat(root.getAttribute('height'));
    if (vb.length === 4 && vb[2] > 0 && vb[3] > 0) ratio = vb[2] / vb[3]; else if (aw > 0 && ah > 0) ratio = aw / ah;
    const fw = Math.max(1, Math.round(o.width || 1024)), fh = Math.max(1, Math.round(fw / ratio));
    let pw = fw, ph = fh;
    if (o.maxSide && Math.max(fw, fh) > o.maxSide) { const r = o.maxSide / Math.max(fw, fh); pw = Math.max(1, Math.round(fw * r)); ph = Math.max(1, Math.round(fh * r)); }
    root.setAttribute('width', pw); root.setAttribute('height', ph);
    if (!root.getAttribute('xmlns')) root.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    const blob = new Blob([new XMLSerializer().serializeToString(root)], { type: 'image/svg+xml' });
    const { src } = await Engine.imgEl(blob);
    return { src, w: pw, h: ph, ow: fw, oh: fh, s: pw / fw, close() {} };
  },
  toCanvas(img) { const c = Engine.canvas(img.w, img.h); c.getContext('2d').drawImage(img.src, 0, 0, img.w, img.h); return c; },
  toBlob(canvas, mime, q) {
    return new Promise((resolve, reject) => {
      canvas.toBlob(b => {
        if (!b) return reject(coded('ENCODE'));
        if (b.type !== mime) return reject(coded('FORMAT'));
        resolve(b);
      }, mime, q);
    });
  },
  flatten(c, bg = '#ffffff') {
    const o = Engine.canvas(c.width, c.height), x = o.getContext('2d');
    x.fillStyle = bg; x.fillRect(0, 0, o.width, o.height); x.drawImage(c, 0, 0); return o;
  },
  /* High quality draw: shrinks in steps of 2 (looks sharp, like Lanczos), then final smooth draw */
  draw(ctx, src, sx, sy, sw, sh, dx, dy, dw, dh) {
    dw = Math.max(1, Math.round(dw)); dh = Math.max(1, Math.round(dh));
    let cur = src, cx = sx, cy = sy, cw = sw, ch = sh;
    while (cw / 2 >= dw && ch / 2 >= dh) {
      const nw = Math.max(dw, Math.floor(cw / 2)), nh = Math.max(dh, Math.floor(ch / 2));
      const t = Engine.canvas(nw, nh), x = t.getContext('2d');
      x.imageSmoothingQuality = 'high'; x.drawImage(cur, cx, cy, cw, ch, 0, 0, nw, nh);
      cur = t; cx = 0; cy = 0; cw = nw; ch = nh;
    }
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(cur, cx, cy, cw, ch, dx, dy, dw, dh);
  },
  resample(src, sx, sy, sw, sh, dw, dh) {
    const out = Engine.canvas(dw, dh); Engine.draw(out.getContext('2d'), src, sx, sy, sw, sh, 0, 0, dw, dh); return out;
  },
  /* Fit a picture into tw x th.  mode: stretch | cover | contain | blur
     o = { bg:'#fff' or null, fx:0..1, fy:0..1 (where to crop when cover) } */
  fit(img, tw, th, mode = 'cover', o = {}) {
    tw = Math.max(1, Math.round(tw)); th = Math.max(1, Math.round(th));
    const out = Engine.canvas(tw, th), ctx = out.getContext('2d'), W = img.w, H = img.h;
    const fx = o.fx == null ? .5 : o.fx, fy = o.fy == null ? .5 : o.fy;
    if (mode === 'stretch') { Engine.draw(ctx, img.src, 0, 0, W, H, 0, 0, tw, th); return out; }
    if (mode === 'cover') {
      const r = Math.max(tw / W, th / H), sw = Math.min(W, tw / r), sh = Math.min(H, th / r);
      Engine.draw(ctx, img.src, (W - sw) * fx, (H - sh) * fy, sw, sh, 0, 0, tw, th); return out;
    }
    if (mode === 'blur') {                                  // whole picture on top of a soft blurry copy
      const k = 160 / Math.min(tw, th), bw = Math.max(8, Math.round(tw * k)), bh = Math.max(8, Math.round(th * k));
      const small = Engine.canvas(bw, bh), sc = small.getContext('2d');
      const rr = Math.max(bw / W, bh / H), sw2 = Math.min(W, bw / rr), sh2 = Math.min(H, bh / rr);
      Engine.draw(sc, img.src, (W - sw2) / 2, (H - sh2) / 2, sw2, sh2, 0, 0, bw, bh);
      Pix.blur(small, Math.max(2, bw / 28));
      ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; ctx.drawImage(small, 0, 0, tw, th);
      ctx.fillStyle = 'rgba(0,0,0,.12)'; ctx.fillRect(0, 0, tw, th);
    } else if (o.bg) { ctx.fillStyle = o.bg; ctx.fillRect(0, 0, tw, th); }
    const r = Math.min(tw / W, th / H), dw = Math.max(1, Math.round(W * r)), dh = Math.max(1, Math.round(H * r));
    Engine.draw(ctx, img.src, 0, 0, W, H, Math.round((tw - dw) / 2), Math.round((th - dh) / 2), dw, dh);
    return out;
  },
  download(blob, name) {
    const u = URL.createObjectURL(blob), a = document.createElement('a');
    a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 8000);
  }
};

/* rotate / flip / straighten a picture. t = { rot90:0..3, flipH, flipV, angle (degrees), fill (hide empty corners) } */
function transformImg(img, t) {
  const rot = ((t.rot90 || 0) % 4 + 4) % 4, odd = rot % 2 === 1;
  const bw = odd ? img.h : img.w, bh = odd ? img.w : img.h, ang = t.angle || 0, th = ang * Math.PI / 180;
  const total = (rot * 90 + ang) * Math.PI / 180;
  const cs = Math.round(Math.cos(total) * 1e9) / 1e9, sn = Math.round(Math.sin(total) * 1e9) / 1e9;
  let ow = bw, oh = bh, k = 1;
  if (ang) {
    const c = Math.abs(Math.cos(th)), s = Math.abs(Math.sin(th));
    if (t.fill) k = c + s * Math.max(bh / bw, bw / bh);
    else { ow = Math.round(bw * c + bh * s); oh = Math.round(bw * s + bh * c); }
  }
  const out = Engine.canvas(ow, oh), x = out.getContext('2d');
  x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
  x.translate(ow / 2, oh / 2); x.scale(t.flipH ? -1 : 1, t.flipV ? -1 : 1); x.transform(cs, sn, -sn, cs, 0, 0); x.scale(k, k);
  x.drawImage(img.src, -img.w / 2, -img.h / 2, img.w, img.h);
  return out;
}

/* =====================================================================
   4. PIXEL EFFECTS  (brightness, contrast, blur, sharpen ... all written by hand)
   ===================================================================== */
const Pix = {
  /* fast "box blur" three times = almost the same as a soft gaussian blur */
  blur(canvas, radius) {
    const r = Math.round(radius); if (r < 1) return canvas;
    const ctx = canvas.getContext('2d'), w = canvas.width, h = canvas.height;
    const id = ctx.getImageData(0, 0, w, h), a = id.data, b = new Uint8ClampedArray(a.length);
    for (let i = 0; i < 3; i++) { Pix._box(a, b, w, h, r, true); Pix._box(b, a, w, h, r, false); }
    ctx.putImageData(id, 0, 0); return canvas;
  },
  _box(src, dst, w, h, r, hor) {
    const n = hor ? w : h, lines = hor ? h : w, stride = hor ? 4 : w * 4, ls = hor ? w * 4 : 4, win = 2 * r + 1;
    for (let l = 0; l < lines; l++) {
      const base = l * ls;
      for (let c = 0; c < 4; c++) {
        let sum = 0;
        for (let k = -r; k <= r; k++) sum += src[base + (k < 0 ? 0 : k > n - 1 ? n - 1 : k) * stride + c];
        for (let i = 0; i < n; i++) {
          dst[base + i * stride + c] = sum / win;
          const add = i + r + 1 > n - 1 ? n - 1 : i + r + 1, rem = i - r < 0 ? 0 : i - r;
          sum += src[base + add * stride + c] - src[base + rem * stride + c];
        }
      }
    }
  },
  sharpen(canvas, amount, radius) {                     // "unsharp mask"
    if (amount <= 0) return canvas;
    const ctx = canvas.getContext('2d'), w = canvas.width, h = canvas.height;
    const orig = ctx.getImageData(0, 0, w, h), o = orig.data;
    const bl = Engine.canvas(w, h); bl.getContext('2d').putImageData(orig, 0, 0); Pix.blur(bl, radius);
    const b = bl.getContext('2d').getImageData(0, 0, w, h).data, out = ctx.createImageData(w, h), d = out.data;
    for (let i = 0; i < o.length; i += 4) {
      d[i] = o[i] + amount * (o[i] - b[i]); d[i + 1] = o[i + 1] + amount * (o[i + 1] - b[i + 1]);
      d[i + 2] = o[i + 2] + amount * (o[i + 2] - b[i + 2]); d[i + 3] = o[i + 3];
    }
    ctx.putImageData(out, 0, 0); return canvas;
  },
  vignette(c, amount) {
    if (amount <= 0) return c;
    const x = c.getContext('2d'), w = c.width, h = c.height;
    const g = x.createRadialGradient(w / 2, h / 2, Math.min(w, h) * .22, w / 2, h / 2, Math.hypot(w, h) / 2);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${amount / 100 * .9})`);
    x.save(); x.globalCompositeOperation = 'source-atop'; x.fillStyle = g; x.fillRect(0, 0, w, h); x.restore(); return c;
  },
  pixelate(c, block) {
    block = Math.round(block); if (block < 2) return c;
    const w = c.width, h = c.height, s = Engine.canvas(Math.max(1, Math.ceil(w / block)), Math.max(1, Math.ceil(h / block))), sx = s.getContext('2d');
    sx.imageSmoothingEnabled = true; sx.drawImage(c, 0, 0, s.width, s.height);
    const x = c.getContext('2d'); x.save(); x.clearRect(0, 0, w, h); x.imageSmoothingEnabled = false; x.drawImage(s, 0, 0, s.width, s.height, 0, 0, s.width * block, s.height * block); x.restore(); return c;
  },
  autoLevels(c) {                                       // "auto enhance": stretches dull pictures
    const x = c.getContext('2d'), id = x.getImageData(0, 0, c.width, c.height), d = id.data, hist = new Uint32Array(256);
    let n = 0;
    for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 8) { hist[(d[i] * .299 + d[i + 1] * .587 + d[i + 2] * .114) | 0]++; n++; }
    if (!n) return c;
    let lo = 0, hi = 255, a = 0;
    for (let i = 0; i < 256; i++) { a += hist[i]; if (a >= n * .006) { lo = i; break; } }
    a = 0; for (let i = 255; i >= 0; i--) { a += hist[i]; if (a >= n * .006) { hi = i; break; } }
    if (hi - lo < 30) return c;
    const k = 255 / (hi - lo);
    for (let i = 0; i < d.length; i += 4) { d[i] = (d[i] - lo) * k; d[i + 1] = (d[i + 1] - lo) * k; d[i + 2] = (d[i + 2] - lo) * k; }
    x.putImageData(id, 0, 0); return c;
  },
  /* all colour changes in ONE pass over the pixels (fast).
     p: exposure brightness contrast saturation hue temperature sepia gray invert grain  (all -100..100 or 0..100) */
  adjust(c, p) {
    const ex = +p.exposure || 0, br = +p.brightness || 0, ct = +p.contrast || 0, sa = +p.saturation || 0, hu = +p.hue || 0,
      tp = +p.temperature || 0, se = (+p.sepia || 0) / 100, gr = (+p.gray || 0) / 100, iv = (+p.invert || 0) / 100, gn = +p.grain || 0;
    if (!(ex || br || ct || sa || hu || tp || se || gr || iv || gn)) return c;
    const x = c.getContext('2d'), id = x.getImageData(0, 0, c.width, c.height), d = id.data;
    const E = Math.pow(2, ex / 50), B = br * 2.55, C = ct >= 0 ? 1 + ct / 50 : 1 + ct / 100, S = 1 + sa / 100, T = tp * .6;
    const a = hu * Math.PI / 180, cs = Math.cos(a), sn = Math.sin(a);
    const m = [.213 + cs * .787 - sn * .213, .715 - cs * .715 - sn * .715, .072 - cs * .072 + sn * .928,
      .213 - cs * .213 + sn * .143, .715 + cs * .285 + sn * .140, .072 - cs * .072 - sn * .283,
      .213 - cs * .213 - sn * .787, .715 - cs * .715 + sn * .715, .072 + cs * .928 + sn * .072];
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] === 0) continue;
      let r = d[i] * E + B, g = d[i + 1] * E + B, b = d[i + 2] * E + B;
      if (ct) { r = (r - 128) * C + 128; g = (g - 128) * C + 128; b = (b - 128) * C + 128; }
      if (sa) { const l = .299 * r + .587 * g + .114 * b; r = l + (r - l) * S; g = l + (g - l) * S; b = l + (b - l) * S; }
      if (hu) { const r2 = m[0] * r + m[1] * g + m[2] * b, g2 = m[3] * r + m[4] * g + m[5] * b, b2 = m[6] * r + m[7] * g + m[8] * b; r = r2; g = g2; b = b2; }
      if (tp) { r += T; b -= T; g += T * .15; }
      if (se) { const tr = .393 * r + .769 * g + .189 * b, tg = .349 * r + .686 * g + .168 * b, tb = .272 * r + .534 * g + .131 * b; r += (tr - r) * se; g += (tg - g) * se; b += (tb - b) * se; }
      if (gr) { const l = .299 * r + .587 * g + .114 * b; r += (l - r) * gr; g += (l - g) * gr; b += (l - b) * gr; }
      if (iv) { r += (255 - r - r) * iv; g += (255 - g - g) * iv; b += (255 - b - b) * iv; }
      if (gn) { const n = (Math.random() - .5) * gn * 1.1; r += n; g += n; b += n; }
      d[i] = r; d[i + 1] = g; d[i + 2] = b;
    }
    x.putImageData(id, 0, 0); return c;
  },
  /* find the box that has real content (not see-through / not plain colour) */
  contentBox(c, tol) {
    const w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data;
    const a0 = d[3], tr = a0 < 10, r0 = d[0], g0 = d[1], b0 = d[2];
    const isBg = i => tr ? d[i + 3] < 10 : (d[i + 3] < 10 || (Math.abs(d[i] - r0) + Math.abs(d[i + 1] - g0) + Math.abs(d[i + 2] - b0)) <= tol * 3);
    let x1 = w, y1 = h, x2 = -1, y2 = -1;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (!isBg((y * w + x) * 4)) { if (x < x1) x1 = x; if (x > x2) x2 = x; if (y < y1) y1 = y; if (y > y2) y2 = y; }
    return x2 < 0 ? null : { x: x1, y: y1, w: x2 - x1 + 1, h: y2 - y1 + 1 };
  }
};

/* =====================================================================
   5. ZIP MAKER (no library: writes a normal .zip file by hand)
   ===================================================================== */
const Zip = {
  table: (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })(),
  crc(u8) { let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = Zip.table[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; },
  async build(items) {
    const enc = new TextEncoder(), parts = [], central = [], used = new Set(), d = new Date();
    const dt = (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) >>> 0;
    const tm = ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) >>> 0;
    let offset = 0;
    for (const it of items) {
      let name = it.name, i = 1;
      while (used.has(name)) name = it.name.replace(/(\.[^.]*)?$/, m => `-${i++}${m}`);
      used.add(name);
      const data = new Uint8Array(await it.blob.arrayBuffer()), crc = Zip.crc(data), nb = enc.encode(name);
      const lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, tm, true); lh.setUint16(12, dt, true); lh.setUint32(14, crc, true); lh.setUint32(18, data.length, true);
      lh.setUint32(22, data.length, true); lh.setUint16(26, nb.length, true); lh.setUint16(28, 0, true);
      parts.push(lh.buffer, nb, data);
      const ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, tm, true); ch.setUint16(14, dt, true); ch.setUint32(16, crc, true); ch.setUint32(20, data.length, true);
      ch.setUint32(24, data.length, true); ch.setUint16(28, nb.length, true); ch.setUint32(42, offset, true);
      central.push(ch.buffer, nb);
      offset += 30 + nb.length + data.length;
    }
    const cd = central.reduce((a, b) => a + b.byteLength, 0), end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, items.length, true); end.setUint16(10, items.length, true);
    end.setUint32(12, cd, true); end.setUint32(16, offset, true);
    return new Blob([...parts, ...central, end.buffer], { type: 'application/zip' });
  }
};

/* =====================================================================
   6. PDF MAKER (no library: writes a real PDF with JPEG pages)
   pages: [{ jpg:Uint8Array, w:px, h:px }]   opt: { size:'a4'|'letter'|'fit', orient:'auto'|'p'|'l', margin:pt }
   ===================================================================== */
const PDF = {
  build(pages, opt) {
    const enc = new TextEncoder(), chunks = [], offs = [];
    let len = 0;
    const push = d => { const u = typeof d === 'string' ? enc.encode(d) : d; chunks.push(u); len += u.length; };
    const f2 = n => (Math.round(n * 100) / 100).toString();
    push(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x34, 0x0A, 0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A]));
    const obj = (n, body) => { offs[n] = len; push(`${n} 0 obj\n${body}\nendobj\n`); };
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    const kids = pages.map((_, i) => `${3 + i * 3} 0 R`).join(' ');
    obj(2, `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`);
    pages.forEach((p, i) => {
      const pid = 3 + i * 3, cid = pid + 1, iid = pid + 2, m = opt.margin || 0;
      let pw, ph;
      if (opt.size === 'fit') {
        const k = Math.min(1, 14000 / Math.max(p.w * .75 + 2 * m, p.h * .75 + 2 * m));
        pw = (p.w * .75) * k + 2 * m; ph = (p.h * .75) * k + 2 * m;
      } else {
        const A = opt.size === 'letter' ? [612, 792] : [595.28, 841.89];
        const land = opt.orient === 'l' || (opt.orient !== 'p' && p.w > p.h);
        pw = land ? A[1] : A[0]; ph = land ? A[0] : A[1];
      }
      const bw = pw - 2 * m, bh = ph - 2 * m, r = Math.min(bw / p.w, bh / p.h), iw = p.w * r, ih = p.h * r;
      const x = (pw - iw) / 2, y = (ph - ih) / 2, content = `q ${f2(iw)} 0 0 ${f2(ih)} ${f2(x)} ${f2(y)} cm /Im0 Do Q`;
      obj(pid, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f2(pw)} ${f2(ph)}] /Resources << /XObject << /Im0 ${iid} 0 R >> >> /Contents ${cid} 0 R >>`);
      obj(cid, `<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
      offs[iid] = len;
      push(`${iid} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${p.w} /Height ${p.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.jpg.length} >>\nstream\n`);
      push(p.jpg); push('\nendstream\nendobj\n');
    });
    const n = 2 + pages.length * 3, xref = len;
    let x = `xref\n0 ${n + 1}\n0000000000 65535 f \n`;
    for (let i = 1; i <= n; i++) x += String(offs[i]).padStart(10, '0') + ' 00000 n \n';
    push(x + `trailer\n<< /Size ${n + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    return new Blob(chunks, { type: 'application/pdf' });
  }
};

/* =====================================================================
   7. EXIF READER (finds camera, date and GPS location hidden inside JPG files)
   ===================================================================== */
const Exif = {
  async read(file) {
    try {
      const v = new DataView(await file.slice(0, 262144).arrayBuffer());
      if (v.getUint16(0) !== 0xFFD8) return null;
      let p = 2;
      while (p < v.byteLength - 4) {
        if (v.getUint8(p) !== 0xFF) break;
        const mk = v.getUint8(p + 1), len = v.getUint16(p + 2);
        if (mk === 0xE1 && v.getUint32(p + 4) === 0x45786966) return Exif.parse(v, p + 10);
        if (mk === 0xDA) break;
        p += 2 + len;
      }
    } catch (e) { /* no exif */ }
    return null;
  },
  parse(v, t) {
    const le = v.getUint16(t) === 0x4949, u16 = o => v.getUint16(o, le), u32 = o => v.getUint32(o, le);
    const SZ = { 1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 7: 1, 9: 4, 10: 8 };
    const val = (type, cnt, o) => {
      if (type === 2) { let s = ''; for (let i = 0; i < cnt - 1; i++) s += String.fromCharCode(v.getUint8(o + i)); return s.trim(); }
      const a = [], m = Math.min(cnt, 6);
      for (let i = 0; i < m; i++) {
        if (type === 3) a.push(u16(o + i * 2)); else if (type === 4) a.push(u32(o + i * 4));
        else if (type === 5 || type === 10) { const n = u32(o + i * 8), d = u32(o + i * 8 + 4); a.push(d ? n / d : 0); }
        else a.push(v.getUint8(o + i));
      }
      return cnt === 1 ? a[0] : a;
    };
    const ifd = off => {
      const out = {}, n = u16(t + off);
      for (let i = 0; i < n && i < 200; i++) {
        const e = t + off + 2 + i * 12, tag = u16(e), type = u16(e + 2), cnt = u32(e + 4), size = (SZ[type] || 1) * cnt;
        try { out[tag] = val(type, cnt, size <= 4 ? e + 8 : t + u32(e + 8)); } catch (er) { /* skip */ }
      }
      return out;
    };
    const i0 = ifd(u32(t + 4)), ex = i0[0x8769] ? ifd(i0[0x8769]) : {}, gp = i0[0x8825] ? ifd(i0[0x8825]) : {};
    const rows = [], add = (k, x) => { if (x !== undefined && x !== '' && x !== null && !Number.isNaN(x)) rows.push([k, String(x)]); };
    add('Camera', [i0[0x010F], i0[0x0110]].filter(Boolean).join(' '));
    add('Lens', ex[0xA434]); add('Taken on', ex[0x9003] || i0[0x0132]); add('Software', i0[0x0131]);
    if (ex[0x829A]) add('Shutter', ex[0x829A] < 1 ? '1/' + Math.round(1 / ex[0x829A]) + ' s' : ex[0x829A] + ' s');
    if (ex[0x829D]) add('Aperture', 'f/' + (+ex[0x829D]).toFixed(1));
    add('ISO', ex[0x8827]); if (ex[0x920A]) add('Focal length', Math.round(ex[0x920A]) + ' mm');
    let gps = null;
    if (Array.isArray(gp[2]) && Array.isArray(gp[4])) {
      const dec = a => a[0] + (a[1] || 0) / 60 + (a[2] || 0) / 3600;
      let lat = dec(gp[2]), lng = dec(gp[4]);
      if (gp[1] === 'S') lat = -lat; if (gp[3] === 'W') lng = -lng;
      gps = { lat, lng };
    }
    return { rows, gps, count: Object.keys(i0).length + Object.keys(ex).length + Object.keys(gp).length };
  }
};

/* =====================================================================
   Anim – the download moment (about 5 seconds), Apple-style and SMOOTH
   Built only from transform + opacity animations, which the browser runs on the
   GPU compositor. They keep playing smoothly even while the page is busy making
   the file, so the animation can never "hang".
   1) the page dims, the picture rises as a glass card with a spring and floats
   2) a "Dynamic Island" pill drops in with a spinning ring, light glides over the card
   3) the card is pulled into the Downloads button (genie-style squeeze)
   4) the button squashes, a ripple runs out, the Island turns into a green check
   The real file is made while it plays and is saved at step 3.
   ===================================================================== */
const Anim = (() => {
  let running = false;
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function colorsOf(src) {                      // 3 soft colours from the picture for the ambient light
    const out = [];
    try {
      const c = document.createElement('canvas'); c.width = c.height = 3; const k = c.getContext('2d'); k.drawImage(src, 0, 0, 3, 3);
      const d = k.getImageData(0, 0, 3, 3).data; [0, 4, 8].forEach(i => out.push(`rgb(${d[i * 4]},${d[i * 4 + 1]},${d[i * 4 + 2]})`));
    } catch (e) { /* ignore */ }
    return out.length ? out : ['#7C5CFF', '#FF5C8A', '#2ad4a5'];
  }
  function dataUrl(src, max, q) {
    const sw = src.width || src.naturalWidth, sh = src.height || src.naturalHeight, s = Math.min(1, max / Math.max(sw, sh));
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(sw * s)); c.height = Math.max(1, Math.round(sh * s));
    c.getContext('2d').drawImage(src, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', q);
  }

  /**
   * opts.src   : canvas/image shown as the card (may be null)
   * opts.work  : async () => result      – makes the file(s) while the animation plays
   * opts.save  : (result) => any         – saves the file, called when the card is pulled in
   * opts.title : text while working;  opts.sub : (result) => string shown after saving
   * opts.count : number of pictures (draws a stack when > 1)
   */
  function run(opts) {
    if (running) return Promise.resolve().then(async () => { const r = await opts.work(); await opts.save(r); return r; });
    running = true;
    const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    const W = innerWidth, H = innerHeight, small = W < 600;
    let src = opts.src, sw = 0, sh = 0;
    try { sw = src.width || src.naturalWidth; sh = src.height || src.naturalHeight; } catch (e) { /* none */ }
    if (!sw || !sh) { src = null; sw = 4; sh = 3; }
    const maxW = Math.min(W * (small ? .74 : .4), 500), maxH = Math.min(H * (small ? .38 : .44), 400);
    const sc = Math.min(maxW / sw, maxH / sh), cw = Math.round(Math.max(90, sw * sc)), ch = Math.round(Math.max(70, sh * sc)), R = Math.round(Math.min(28, cw * .07));
    let big = '', thumb = '', cols = ['#7C5CFF', '#FF5C8A', '#2ad4a5'];
    try { if (src) { big = dataUrl(src, 760, .86); thumb = dataUrl(src, 96, .8); cols = colorsOf(src); } } catch (e) { /* tainted */ }
    const count = Math.max(1, opts.count | 0 || 1), layers = Math.min(3, count);

    const root = document.createElement('div');
    root.className = 'ax'; root.setAttribute('role', 'status'); root.setAttribute('aria-live', 'polite');
    const cardHTML = (i) => `<div class="ax-fl" style="margin-left:${-cw / 2}px;margin-top:${-ch / 2}px;z-index:${10 - i}"><div class="ax-sw" data-i="${i}"><div class="ax-card" style="width:${cw}px;height:${ch}px;border-radius:${R}px">${big ? `<img alt="" src="${big}">` : '<div style="width:100%;height:100%;background:linear-gradient(135deg,#7C5CFF,#FF5C8A)"></div>'}${i === 0 && !reduce ? '<div class="ax-gloss"></div>' : ''}${i ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,.18)"></div>' : ''}</div></div></div>`;
    root.innerHTML = `<div class="ax-bg"><i style="background:radial-gradient(48% 42% at 22% 26%,${cols[0]},transparent 70%),radial-gradient(46% 40% at 80% 70%,${cols[1]},transparent 70%),radial-gradient(40% 36% at 60% 20%,${cols[2]},transparent 70%)"></i></div>
      <div class="ax-stage">${Array.from({ length: layers }, (_, k) => cardHTML(layers - 1 - k)).join('')}</div>
      <div class="ax-isl"><div class="ax-in"><img class="ax-th" alt="" ${thumb ? `src="${thumb}"` : 'style="display:none"'}><div class="ax-tx"><b class="ax-t1"></b><span class="ax-t2"></span></div>
        <div class="ax-rg"><svg class="spin" viewBox="0 0 36 36" aria-hidden="true"><circle class="bg" cx="18" cy="18" r="15"/><circle class="fg" cx="18" cy="18" r="15" pathLength="100"/></svg>
        <svg class="ok" viewBox="0 0 36 36" aria-hidden="true"><circle cx="18" cy="18" r="15"/><path d="M11 18.5l5 5 9.5-11"/></svg></div></div></div>
      <div class="ax-tray" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 4.5v11M7.5 11.5L12 16l4.5-4.5M5.5 19.5h13"/></svg><i class="ax-rip"></i></div>`;
    document.body.appendChild(root); document.documentElement.classList.add('anim-on');
    const isl = root.querySelector('.ax-isl'), tray = root.querySelector('.ax-tray'), t1 = root.querySelector('.ax-t1'), t2 = root.querySelector('.ax-t2');
    t1.textContent = opts.title || 'Preparing your picture'; t2.textContent = count > 1 ? `${count} pictures` : 'Just a moment…';
    const cards = [...root.querySelectorAll('.ax-card')], sws = [...root.querySelectorAll('.ax-sw')], fls = [...root.querySelectorAll('.ax-fl')];
    requestAnimationFrame(() => root.classList.add('on'));

    // gentle fan for a stack of pictures
    cards.forEach((c, k) => {                                              // spring entrance (transform + opacity only)
      const i = +c.parentNode.dataset.i, rot = i ? (i % 2 ? -1 : 1) * (4 + i * 2) : 0, oy = i * 14;
      if (reduce) { c.style.transform = `translateY(${oy}px) rotate(${rot}deg)`; return; }
      c.animate([{ transform: `translateY(${oy + 30}px) scale(.74) rotate(0deg)`, opacity: 0 }, { transform: `translateY(${oy - 4}px) scale(1.035) rotate(${rot}deg)`, opacity: 1, offset: .62 }, { transform: `translateY(${oy}px) scale(${1 - i * .05}) rotate(${rot}deg)`, opacity: 1 }],
        { duration: 800, delay: (layers - 1 - i) * 70, easing: 'cubic-bezier(.22,1,.36,1)', fill: 'both' });
    });

    let finish; const donePromise = new Promise(res => { finish = res; });
    let workRes, workErr = null, saveErr = null;
    const MIN = reduce ? 600 : 2700;                                       // the show lasts about 5 seconds in total
    const t0 = performance.now();
    const workP = (async () => { await sleep(260); try { workRes = await opts.work(); } catch (e) { workErr = e; } })();   // start the heavy work after the first frames are on screen
    const cleanup = () => { root.remove(); document.documentElement.classList.remove('anim-on'); running = false; };

    (async () => {
      await Promise.all([workP, sleep(MIN)]);
      if (workErr) { cleanup(); finish(); return; }
      // --- pull the card into the Downloads button ---
      t1.textContent = 'Saving'; t2.textContent = 'Almost there…';
      try { Promise.resolve(opts.save(workRes)).catch(e => { saveErr = e; }); } catch (e) { saveErr = e; }
      const tr = tray.getBoundingClientRect(), tx = tr.left + tr.width / 2, ty = tr.top + tr.height / 2;
      const SW = reduce ? 1 : 900;
      await Promise.all(sws.map((s, k) => {
        const r = s.querySelector('.ax-card').getBoundingClientRect(), dx = tx - (r.left + r.width / 2), dy = ty - (r.top + r.height / 2);
        if (reduce) { s.style.opacity = 0; return Promise.resolve(); }
        return s.animate([
          { transform: 'translate(0,0) scale(1,1)', opacity: 1, offset: 0 },
          { transform: 'translate(0,0) scale(1.05,1.05)', opacity: 1, offset: .14 },
          { transform: `translate(${dx * .34}px,${dy * .3}px) scale(.8,1.1)`, opacity: 1, offset: .42 },
          { transform: `translate(${dx * .8}px,${dy * .78}px) scale(.3,.56)`, opacity: 1, offset: .8 },
          { transform: `translate(${dx}px,${dy}px) scale(.05,.08)`, opacity: 0 }
        ], { duration: SW, delay: k * 60, easing: 'cubic-bezier(.5,0,.75,.55)', fill: 'forwards' }).finished.catch(() => { });
      }));
      // --- landed ---
      tray.classList.add('hit'); isl.classList.add('done');
      let sub = ''; try { sub = opts.sub ? opts.sub(workRes) : ''; } catch (e) { /* ignore */ }
      t1.textContent = saveErr ? 'Could not save' : 'Saved'; t2.textContent = saveErr ? 'Please try again' : (sub || 'In your Downloads');
      await sleep(reduce ? 500 : 1050);
      root.classList.add('out'); await sleep(420);
      cleanup(); finish();
    })();
    return donePromise.then(async () => { if (workErr) throw workErr; if (saveErr) throw saveErr; return workRes; });
  }
  return { run };
})();

/* =====================================================================
   Tour – friendly step-by-step guide for first-time visitors
   Stage 1: a pulsing hand/bubble points at the upload box ("Step 1")
   Stage 2: after the picture is added, a gliding spotlight walks through
            preview → compare → settings → file size → Download
   "Skip tour" is on every step; once skipped or finished it never shows
   again unless the user presses "❓ Show me how".
   ===================================================================== */
const Tour = (() => {
  const KEY = 'pn_tour_v1';
  const get = () => { try { return localStorage.getItem(KEY); } catch (e) { return null; } };
  const set = v => { try { localStorage.setItem(KEY, v); } catch (e) { /* private mode */ } };
  let st = null, raf = 0, watch = 0, tool = null;

  const STD = [
    { sel: '#pv', ic: '👀', t: 'This is your picture – live!', x: 'Everything you change shows up right here, instantly. Nothing is hidden.' },
    { sel: '.prev-bar .seg', ic: '🔀', t: 'Compare before and after', x: 'Tap “Before” to see your original. Tap “After” to see the new one.' },
    { sel: '#ctl', ic: '🎛️', t: 'Change things here', x: 'Move a slider or tap an option. Go on, try one – watch the picture change!' },
    { sel: '#sizeBox', ic: '📦', t: 'Your new file size', x: 'See how big the new file will be before you download it.' },
    { sel: '#dl', ic: '🎉', t: 'Happy? Press Download!', x: 'Your file is made right on your device. It is never uploaded anywhere.' }
  ];
  const CROP = [
    { sel: '#cc', ic: '✂️', t: 'Drag to crop', x: 'Move the box or pull its corners. The picture updates live.' },
    { sel: '#asp', ic: '📐', t: 'Pick a shape', x: 'Tap a shape like Square or 16:9 and the box snaps to it.' },
    { sel: '#cctl', ic: '🎛️', t: 'Turn and flip', x: 'Rotate, flip or straighten the picture here.' },
    { sel: '#cdl', ic: '🎉', t: 'Press Download', x: 'Your cropped picture is saved on your device.' }
  ];
  const PDFS = [
    { sel: '#plist', ic: '🗂️', t: 'Your pages', x: 'Use ▲ ▼ to change the order of the pictures.' },
    { sel: '#paper', ic: '👀', t: 'Live PDF page', x: 'This is how your PDF page will look.' },
    { sel: '#pctl', ic: '🎛️', t: 'Page settings', x: 'Choose paper size, direction and margin.' },
    { sel: '#pdl', ic: '🎉', t: 'Make my PDF', x: 'Press the button and your PDF is ready.' }
  ];
  const stepsFor = t => /^crop/.test(t.id) ? CROP : /pdf|scan-to/.test(t.id) ? PDFS : t.mount ? [] : STD;

  const el = (cls, html) => { const d = document.createElement('div'); d.className = cls; if (html != null) d.innerHTML = html; document.body.appendChild(d); return d; };
  function clear() { cancelAnimationFrame(raf); raf = 0; clearInterval(watch); watch = 0; document.querySelectorAll('.tour-ui').forEach(n => n.remove()); st = null; }
  function stop() { clear(); tool = null; }
  function finish(permanent) { if (permanent) set('off'); clear(); }

  /* --- Stage 1: point at the upload box --- */
  function stage1() {
    clear();
    const dz = document.querySelector('.dz'); if (!dz) return;
    const ring = el('tour-ui tour-ring'), tip = el('tour-ui tour-tip tour-tip1',
      `<div class="tt-mascot" aria-hidden="true">👆</div>
       <div class="tt-step">Step 1 of 3</div>
       <b>Add your picture here</b>
       <p>Click the big box, or drop a picture on it. No picture? Tap “Try a sample” – it is free to play with!</p>
       <div class="tt-btns"><button type="button" class="tt-skip" data-tour="skip">Skip tour</button><button type="button" class="tt-next" data-tour="sample">✨ Try a sample</button></div>`);
    tip.setAttribute('role', 'dialog'); tip.setAttribute('aria-label', 'Guide: step 1');
    st = { stage: 1, ring, tip, dz };
    const loop = () => {
      if (!st || st.stage !== 1) return;
      const r = dz.getBoundingClientRect();
      if (!dz.isConnected || !document.querySelector('.dz')) { // picture was added → stage 2
        clear(); setTimeout(stage2Wait, 700); return;
      }
      const W = innerWidth, H = innerHeight, vis = r.bottom > 0 && r.top < H;
      ring.style.cssText = `left:${r.left - 6}px;top:${r.top - 6}px;width:${r.width + 12}px;height:${r.height + 12}px;opacity:${vis ? 1 : 0}`;
      const tw = Math.min(330, W - 24), th = tip.offsetHeight || 190;
      let tx = r.left + r.width / 2 - tw / 2, ty = r.top - th - 18;
      if (ty < 70) ty = Math.min(r.bottom - th - 18, r.top + 20); // not enough room above: sit inside the box's top
      if (ty < 70) ty = 80;
      tx = Math.max(12, Math.min(W - tw - 12, tx)); ty = Math.max(70, Math.min(H - th - 12, ty));
      tip.style.cssText = `width:${tw}px;left:${tx}px;top:${ty}px;opacity:${vis ? 1 : 0}`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  }

  /* --- Stage 2: gliding spotlight --- */
  function stage2Wait() {
    if (get() === 'off' || !tool) return;
    let n = 0; clearInterval(watch);
    watch = setInterval(() => {            // wait until the picture is really on screen
      n++; const pv = document.querySelector('#pv'), sz = document.querySelector('#sizeBox');
      const ready = pv ? pv.width > 1 && sz && !/Getting ready/.test(sz.textContent) : !!document.querySelector('#cc, #plist');
      if (ready) { clearInterval(watch); watch = 0; stage2(0); } else if (n > 40) clearInterval(watch);
    }, 300);
  }
  function stage2(i0) {
    clear();
    const steps = stepsFor(tool).filter(s => document.querySelector(s.sel)); if (!steps.length) return;
    const spot = el('tour-ui tour-spot'), tip = el('tour-ui tour-tip tour-tip2');
    tip.setAttribute('role', 'dialog'); tip.setAttribute('aria-live', 'polite');
    st = { stage: 2, steps, i: -1, spot, tip };
    const show = i => {
      if (i >= steps.length) { finish(true); confettiSafe(); return; }
      st.i = i; const s = steps[i], last = i === steps.length - 1;
      tip.classList.remove('pop'); void tip.offsetWidth; tip.classList.add('pop');
      tip.innerHTML = `<div class="tt-mascot" aria-hidden="true">${s.ic}</div>
        <div class="tt-step">Step ${i === 0 ? 2 : 3} of 3 · ${i + 1}/${steps.length}</div>
        <b>${s.t}</b><p>${s.x}</p>
        <div class="tt-dots" aria-hidden="true">${steps.map((_, k) => `<i class="${k === i ? 'on' : k < i ? 'dn' : ''}"></i>`).join('')}</div>
        <div class="tt-btns"><button type="button" class="tt-skip" data-tour="skip">Skip tour</button>${i ? '<button type="button" class="tt-back" data-tour="back">←</button>' : ''}<button type="button" class="tt-next" data-tour="next">${last ? 'Got it! ✓' : 'Next →'}</button></div>`;
      const target = document.querySelector(s.sel); if (target) target.scrollIntoView({ block: 'center', behavior: 'smooth' });
    };
    st.show = show; show(i0 || 0);
    const loop = () => {
      if (!st || st.stage !== 2) return;
      const s = steps[st.i], t = s && document.querySelector(s.sel);
      if (!t) { raf = requestAnimationFrame(loop); return; }
      const r = t.getBoundingClientRect(), W = innerWidth, H = innerHeight, pad = 8;
      let l = Math.max(6, r.left - pad), tp = Math.max(6, r.top - pad), rr = Math.min(W - 6, r.right + pad), bb = Math.min(H - 6, r.bottom + pad);
      if (rr < l || bb < tp) { l = tp = 6; rr = bb = 7; }
      spot.style.cssText = `left:${l}px;top:${tp}px;width:${rr - l}px;height:${bb - tp}px`;
      const tw = Math.min(340, W - 24), th = tip.offsetHeight || 200;
      let tx = (l + rr) / 2 - tw / 2, ty;
      if (H - bb >= th + 18) ty = bb + 14;                 // below
      else if (tp >= th + 18) ty = tp - th - 14;           // above
      else ty = H - th - 12;                               // big target: dock at the bottom
      tx = Math.max(12, Math.min(W - tw - 12, tx)); ty = Math.max(70, Math.min(H - th - 12, ty));
      tip.style.cssText = `width:${tw}px;left:${tx}px;top:${ty}px`;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
  }
  function confettiSafe() { try { confetti(); } catch (e) { /* ignore */ } }

  /* --- public --- */
  function begin(t) {                           // called every time a tool page opens
    stop(); tool = t;
    if (get() === 'off') return;
    setTimeout(() => { if (tool === t && document.querySelector('.dz')) stage1(); }, 650);
  }
  function replay() {
    if (!tool) return;
    set('on'); clear();
    if (document.querySelector('.dz')) stage1(); else stage2(0);
  }

  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('[data-tour]');
    if (b) {
      e.preventDefault(); e.stopPropagation(); const a = b.dataset.tour;
      if (a === 'skip') finish(true);
      else if (a === 'sample') { const s = document.querySelector('#sample'); if (s) s.click(); }
      else if (a === 'next' && st) st.show(st.i + 1);
      else if (a === 'back' && st) st.show(Math.max(0, st.i - 1));
      return;
    }
    if (e.target.closest && e.target.closest('#guideBtn')) { replay(); return; }
    if (st && st.stage === 2 && e.target.closest && e.target.closest('#dl, #cdl, #pdl')) finish(true);   // they pressed Download: tour done
  }, true);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && st) finish(true); });

  return { begin, stop, replay };
})();

/* =====================================================================
   PIXELNEST  –  TOOL REGISTRY
   HOW TO ADD A TOOL: call T({ ... }) once. Menu, search, page, settings,
   preview and download are all built automatically from that one object.

   T({ id, title, desc, icon, menu, group, kw:[search words],
       controls:[ {key,type,label,default,...} ],
       render:(img, opts, ctx) => canvas,        // the real picture work
       format:'jpg'|'png'|'webp' (optional fixed output) })
   img = { src, w, h, ow, oh }   (w/h = size being drawn, ow/oh = real original size)
   ctx = { preview:true/false }
   control types: slider number text select seg color toggle grid9 looks image size
   ===================================================================== */
const MENUS = [
  { id: 'convert',  label: 'Convert',        icon: '🔄', color: '#7C3AED', desc: 'Change a picture from one type to another.', groups: ['To JPG', 'To PNG', 'To WebP', 'Code & icons'] },
  { id: 'resize',   label: 'Resize',         icon: '📐', color: '#0EA5E9', desc: 'Make pictures the exact size you need.', groups: ['Exact size', 'Social media', 'Screens & ID photos'] },
  { id: 'crop',     label: 'Crop & Rotate',  icon: '✂️', color: '#F97316', desc: 'Cut, turn, flip and split pictures.', groups: ['Crop', 'Rotate', 'Flip', 'Split & trim'] },
  { id: 'compress', label: 'Compress',       icon: '🗜️', color: '#10B981', desc: 'Make files smaller without ruining them.', groups: ['Smart compress', 'Target size', 'By type'] },
  { id: 'edit',     label: 'Colors & Filters', icon: '🎨', color: '#EC4899', desc: 'Brighten, blur, sharpen and add looks.', groups: ['All-in-one', 'Adjust', 'Looks', 'Effects'] },
  { id: 'add',      label: 'Add & Decorate', icon: '✨', color: '#F59E0B', desc: 'Text, watermark, borders and rounded corners.', groups: ['Text & watermark', 'Frames & shapes', 'Backgrounds'] },
  { id: 'pdf',      label: 'PDF',            icon: '📄', color: '#EF4444', desc: 'Turn your pictures into a PDF file.', groups: ['Pictures to PDF'] },
  { id: 'info',     label: 'Info & Privacy', icon: '🛡️', color: '#14B8A6', desc: 'Remove hidden data, pick colors, compare.', groups: ['Privacy', 'Colors', 'Compare'] }
];
const POPULAR = ['compress', 'resize-pixels', 'png-to-jpg', 'jpg-to-png', 'crop', 'heic-to-jpg', 'image-to-pdf', 'photo-editor'];
const tools = [];
const getById = id => tools.find(t => t.id === id);
const menuOf = id => MENUS.find(m => m.id === id);
const byMenu = id => tools.filter(t => t.menu === id);
function T(t) {
  t = Object.assign({ multiple: true, controls: [], suffix: 'edited', kw: [], group: '', desc: '', icon: '🖼️' }, t);
  t.hay = [t.title, t.desc, t.group, ...t.kw].join(' ').toLowerCase();
  tools.push(t); return t;
}
function searchTools(q, list = tools) {
  const w = q.toLowerCase().split(/\s+/).filter(Boolean);
  return w.length ? list.filter(t => w.every(x => t.hay.includes(x))) : list;
}
function groupsOf(menuId) {
  const m = menuOf(menuId), list = byMenu(menuId), out = [];
  [...m.groups, ...new Set(list.map(t => t.group))].forEach(g => { if (!out.includes(g)) out.push(g); });
  return out.map(g => ({ name: g, tools: list.filter(t => t.group === g) })).filter(g => g.tools.length);
}

/* ---------- shared control pieces ---------- */
const FORMAT_L = { same: 'Same as picture', jpg: 'JPG', png: 'PNG', webp: 'WebP' };
function fmtCtl(def = 'same', list = ['same', 'jpg', 'png', 'webp']) {
  return [
    { key: 'format', type: 'seg', label: 'Save as', default: def, options: list.map(v => ({ v, l: FORMAT_L[v] })) },
    { key: 'quality', type: 'slider', label: 'Quality', min: 50, max: 100, default: 92, unit: '%', showIf: o => o.format !== 'png', hint: 'Higher looks better but makes a bigger file.' },
    { key: 'bg', type: 'color', label: 'Background (for see-through parts)', default: '#ffffff', showIf: o => o.format === 'jpg' }
  ];
}
function fixedCtl(fmt) {                                   // tools that always save one type
  const c = [];
  if (FMT[fmt].lossy) c.push({ key: 'quality', type: 'slider', label: 'Quality', min: 50, max: 100, default: 92, unit: '%', hint: 'Higher looks better but makes a bigger file.' });
  if (fmt === 'jpg') c.push({ key: 'bg', type: 'color', label: 'Background (for see-through parts)', default: '#ffffff' });
  return c;
}
const fitCtl = def => [
  { key: 'fit', type: 'seg', label: 'If the shape is different', default: def, options: [
    { v: 'blur', l: 'Keep all (blur)' }, { v: 'contain', l: 'Keep all (color)' }, { v: 'cover', l: 'Fill & crop' }, { v: 'stretch', l: 'Stretch' }] },
  { key: 'fill', type: 'color', label: 'Bar color', default: '#ffffff', showIf: o => o.fit === 'contain' },
  { key: 'fx', type: 'slider', label: 'Move picture left / right', min: 0, max: 100, default: 50, showIf: o => o.fit === 'cover', hint: 'Slide to keep faces inside.' },
  { key: 'fy', type: 'slider', label: 'Move picture up / down', min: 0, max: 100, default: 50, showIf: o => o.fit === 'cover' }
];
const fitOpts = o => ({ bg: o.fill, fx: (o.fx == null ? 50 : o.fx) / 100, fy: (o.fy == null ? 50 : o.fy) / 100 });
const pvK = (tw, th, ctx) => ctx.preview ? Math.min(1, PV_MAX / Math.max(tw, th)) : 1;
const copyCanvas = img => Engine.toCanvas(img);
const FONTS = {
  clean: 'system-ui,"Segoe UI",Roboto,Arial,sans-serif', bold: '"Arial Black","Segoe UI Black",Impact,sans-serif',
  serif: 'Georgia,"Times New Roman",serif', hand: '"Segoe Print","Comic Sans MS","Bradley Hand",cursive', mono: '"Courier New",Consolas,monospace'
};
const IMPACT = 'Impact,"Haettenschweiler","Anton","Arial Narrow Bold","Arial Black",sans-serif';

/* =====================================================================
   CONVERT
   ===================================================================== */
[
  ['png-to-jpg',  'PNG to JPG',  'jpg', '🖼️', 'Turn PNG pictures into JPG.', ['png', 'jpeg'], 'To JPG'],
  ['webp-to-jpg', 'WebP to JPG', 'jpg', '🌐', 'Open WebP pictures anywhere.', ['webp'], 'To JPG'],
  ['heic-to-jpg', 'HEIC to JPG', 'jpg', '📱', 'iPhone pictures to normal JPG.', ['heic', 'heif', 'iphone', 'apple'], 'To JPG'],
  ['svg-to-jpg',  'SVG to JPG',  'jpg', '✏️', 'Turn SVG drawings into JPG.', ['svg', 'vector'], 'To JPG'],
  ['bmp-to-jpg',  'BMP to JPG',  'jpg', '🗂️', 'Turn old BMP pictures into JPG.', ['bmp', 'bitmap'], 'To JPG'],
  ['gif-to-jpg',  'GIF to JPG',  'jpg', '🎞️', 'Save the first picture of a GIF as JPG.', ['gif', 'frame'], 'To JPG'],
  ['avif-to-jpg', 'AVIF to JPG', 'jpg', '🧊', 'Turn AVIF pictures into JPG.', ['avif'], 'To JPG'],
  ['jfif-to-jpg', 'JFIF to JPG', 'jpg', '📎', 'Turn JFIF files into normal JPG.', ['jfif'], 'To JPG'],
  ['any-to-jpg',  'Any Picture to JPG', 'jpg', '🌈', 'Any picture type to JPG.', ['any', 'all'], 'To JPG'],
  ['jpg-to-png',  'JPG to PNG',  'png', '🔄', 'Turn JPG pictures into PNG.', ['jpg', 'jpeg'], 'To PNG'],
  ['webp-to-png', 'WebP to PNG', 'png', '🧩', 'Turn WebP into PNG.', ['webp'], 'To PNG'],
  ['heic-to-png', 'HEIC to PNG', 'png', '🍎', 'iPhone pictures to PNG.', ['heic', 'heif', 'iphone'], 'To PNG'],
  ['svg-to-png',  'SVG to PNG',  'png', '🖋️', 'Turn SVG drawings into PNG.', ['svg', 'vector'], 'To PNG'],
  ['bmp-to-png',  'BMP to PNG',  'png', '🗃️', 'Turn BMP pictures into PNG.', ['bmp'], 'To PNG'],
  ['gif-to-png',  'GIF to PNG',  'png', '🎬', 'Save the first picture of a GIF as PNG.', ['gif', 'frame'], 'To PNG'],
  ['avif-to-png', 'AVIF to PNG', 'png', '❄️', 'Turn AVIF pictures into PNG.', ['avif'], 'To PNG'],
  ['ico-to-png',  'ICO to PNG',  'png', '🔖', 'Turn icon files into PNG.', ['ico', 'icon', 'favicon'], 'To PNG'],
  ['any-to-png',  'Any Picture to PNG', 'png', '🌈', 'Any picture type to PNG.', ['any', 'all'], 'To PNG'],
  ['jpg-to-webp', 'JPG to WebP', 'webp', '⚡', 'Smaller pictures for websites.', ['jpg', 'jpeg', 'small'], 'To WebP'],
  ['png-to-webp', 'PNG to WebP', 'webp', '🚀', 'Make PNG much smaller as WebP.', ['png', 'small'], 'To WebP'],
  ['gif-to-webp', 'GIF to WebP', 'webp', '🪄', 'Save the first picture of a GIF as WebP.', ['gif'], 'To WebP'],
  ['any-to-webp', 'Any Picture to WebP', 'webp', '🌈', 'Any picture type to WebP.', ['any', 'all'], 'To WebP']
].forEach(([id, title, to, icon, desc, kw, group]) => {
  const svg = id.startsWith('svg');
  T({
    id, title, desc, icon, menu: 'convert', group, kw: ['convert', 'change format', to, ...kw], suffix: 'converted', format: to,
    controls: [...(svg ? [{ key: 'width', type: 'number', label: 'Width (pixels)', default: 1024, min: 16, max: 8000, hint: 'SVG has no fixed size, so pick one. Bigger = sharper.' }] : []), ...fixedCtl(to)],
    reload: svg ? o => o.width : null,
    render: img => copyCanvas(img)
  });
});

/* =====================================================================
   RESIZE
   ===================================================================== */
const resizeCtls = def => [...fitCtl(def), ...fmtCtl('same')];
T({
  id: 'resize-pixels', title: 'Resize Pictures', desc: 'Pick the exact size in pixels.', icon: '📐', menu: 'resize', group: 'Exact size',
  kw: ['resize', 'pixels', 'width', 'height', 'dimension', 'change size'], suffix: 'resized',
  controls: [{ type: 'size', key: 'size', wkey: 'width', hkey: 'height', lkey: 'lock', label: 'Size in pixels' }, ...fitCtl('cover').map(c => ({ ...c, showIf: o => !o.lock && (c.showIf ? c.showIf(o) : true) })), ...fmtCtl('same')],
  init: (o, img) => { o.width = img.ow; o.height = img.oh; o.lock = true; },
  render(img, o, ctx) {
    const tw = Math.max(1, Math.round(+o.width || img.ow)), th = o.lock ? Math.max(1, Math.round(tw * img.oh / img.ow)) : Math.max(1, Math.round(+o.height || img.oh)), k = pvK(tw, th, ctx);
    return Engine.fit(img, tw * k, th * k, o.lock ? 'stretch' : o.fit, fitOpts(o));
  }
});
T({
  id: 'bulk-resize', title: 'Bulk Resizer', desc: 'Resize many pictures at once.', icon: '📚', menu: 'resize', group: 'Exact size',
  kw: ['bulk', 'batch', 'many', 'resize', 'multiple', 'zip'], suffix: 'resized',
  controls: [{ type: 'size', key: 'size', wkey: 'width', hkey: 'height', lkey: 'lock', label: 'Size in pixels' }, ...fitCtl('cover').map(c => ({ ...c, showIf: o => !o.lock && (c.showIf ? c.showIf(o) : true) })), ...fmtCtl('same')],
  init: (o, img) => { o.width = Math.min(img.ow, 1600); o.height = img.oh; o.lock = true; },
  render(img, o, ctx) {
    const tw = Math.max(1, Math.round(+o.width || img.ow)), th = o.lock ? Math.max(1, Math.round(tw * img.oh / img.ow)) : Math.max(1, Math.round(+o.height || img.oh)), k = pvK(tw, th, ctx);
    return Engine.fit(img, tw * k, th * k, o.lock ? 'stretch' : o.fit, fitOpts(o));
  }
});
T({
  id: 'resize-percent', title: 'Resize by Percent', desc: 'Make pictures bigger or smaller by %.', icon: '➗', menu: 'resize', group: 'Exact size',
  kw: ['percent', 'percentage', 'scale', 'half', 'smaller', 'bigger', 'resize'], suffix: 'resized',
  controls: [
    { key: 'pct', type: 'seg', label: 'Quick pick', default: 50, num: true, options: [25, 50, 75, 150, 200].map(v => ({ v, l: v + '%' })) },
    { key: 'pct', type: 'slider', label: 'Size', min: 5, max: 300, default: 50, unit: '%' }, ...fmtCtl('same')],
  render(img, o, ctx) {
    const f = (+o.pct || 50) / 100, tw = img.ow * f, th = img.oh * f, k = pvK(tw, th, ctx);
    return Engine.fit(img, tw * k, th * k, 'stretch');
  }
});
T({
  id: 'enlarge', title: 'Make Picture Bigger', desc: 'Enlarge 2×, 3× or 4× with smooth edges.', icon: '🔎', menu: 'resize', group: 'Exact size',
  kw: ['enlarge', 'upscale', 'bigger', 'zoom', 'increase size', '4x', '2x'], suffix: 'bigger',
  controls: [
    { key: 'f', type: 'seg', label: 'How much bigger?', default: 2, num: true, options: [2, 3, 4].map(v => ({ v, l: v + '×' })) },
    { key: 'sharp', type: 'toggle', label: 'Sharpen a little after', default: true, hint: 'Smooth enlarging, not magic AI: very small pictures will still look soft.' }, ...fmtCtl('png')],
  render(img, o, ctx) {
    const tw = img.ow * o.f, th = img.oh * o.f;
    const k = pvK(tw, th, ctx), c = Engine.fit(img, tw * k, th * k, 'stretch');
    if (o.sharp) Pix.sharpen(c, .6, Math.max(1, Math.min(c.width, c.height) * .0015));
    return c;
  }
});
[
  ['instagram-post', 'Instagram Post', 1080, 1080, '📸', ['instagram', 'insta', 'square']],
  ['instagram-portrait', 'Instagram Portrait (4:5)', 1080, 1350, '🤳', ['instagram', 'portrait', '4:5']],
  ['instagram-story', 'Instagram Story / Reel', 1080, 1920, '📱', ['instagram', 'story', 'reel', 'vertical']],
  ['youtube-thumb', 'YouTube Thumbnail', 1280, 720, '▶️', ['youtube', 'thumbnail', 'video']],
  ['youtube-banner', 'YouTube Banner', 2560, 1440, '🎬', ['youtube', 'banner', 'channel art']],
  ['facebook-cover', 'Facebook Cover', 820, 312, '👍', ['facebook', 'cover', 'fb']],
  ['facebook-post', 'Facebook Post', 1200, 630, '📘', ['facebook', 'post', 'link']],
  ['x-header', 'X (Twitter) Header', 1500, 500, '🐦', ['x', 'twitter', 'header', 'banner']],
  ['x-post', 'X (Twitter) Post', 1600, 900, '✖️', ['x', 'twitter', 'post']],
  ['linkedin-banner', 'LinkedIn Banner', 1584, 396, '💼', ['linkedin', 'banner', 'cover']],
  ['tiktok', 'TikTok Size', 1080, 1920, '🎵', ['tiktok', 'vertical', 'video']],
  ['pinterest-pin', 'Pinterest Pin', 1000, 1500, '📌', ['pinterest', 'pin']],
  ['whatsapp-dp', 'WhatsApp Profile Photo', 500, 500, '💬', ['whatsapp', 'dp', 'profile', 'avatar']],
  ['discord-avatar', 'Discord Avatar', 512, 512, '🎮', ['discord', 'avatar', 'profile']],
  ['twitch-banner', 'Twitch Banner', 1200, 480, '🟣', ['twitch', 'banner', 'stream']],
  ['whatsapp-status', 'WhatsApp Status', 1080, 1920, '🟢', ['whatsapp', 'status', 'story']]
].forEach(([id, title, w, h, icon, kw]) => T({
  id: 'resize-' + id, title, desc: `Perfect ${w} × ${h} picture.`, icon, menu: 'resize', group: 'Social media',
  kw: [...kw, 'resize', 'social', 'size'], suffix: id, controls: resizeCtls('blur'),
  render(img, o, ctx) { const k = pvK(w, h, ctx); return Engine.fit(img, w * k, h * k, o.fit, fitOpts(o)); }
}));
[
  ['passport', 'Passport Photo (35×45 mm)', 413, 531, '🪪', ['passport', 'id', 'visa'], 'cover'],
  ['passport-us', 'US Passport / Visa (2×2 in)', 600, 600, '🛂', ['passport', 'visa', 'us', 'usa'], 'cover'],
  ['id-card', 'ID Card Photo (3×4 cm)', 354, 472, '🆔', ['id', 'card', 'cnic', 'photo'], 'cover'],
  ['wallpaper-hd', 'Wallpaper HD (1920×1080)', 1920, 1080, '🖥️', ['wallpaper', 'desktop', 'hd', '1080p'], 'blur'],
  ['wallpaper-4k', 'Wallpaper 4K (3840×2160)', 3840, 2160, '📺', ['wallpaper', '4k', 'uhd'], 'blur'],
  ['wallpaper-phone', 'Phone Wallpaper (1080×2400)', 1080, 2400, '📲', ['wallpaper', 'phone', 'mobile'], 'blur'],
  ['icon-512', 'App Icon (512×512)', 512, 512, '🧿', ['app', 'icon', 'logo', '512'], 'contain'],
  ['thumbnail-small', 'Small Thumbnail (300×300)', 300, 300, '🔳', ['thumbnail', 'small', 'avatar'], 'cover']
].forEach(([id, title, w, h, icon, kw, def]) => T({
  id: 'resize-' + id, title, desc: `Perfect ${w} × ${h} picture.`, icon, menu: 'resize', group: 'Screens & ID photos',
  kw: [...kw, 'resize', 'size'], suffix: id, controls: resizeCtls(def),
  render(img, o, ctx) { const k = pvK(w, h, ctx); return Engine.fit(img, w * k, h * k, o.fit, fitOpts(o)); }
}));

/* =====================================================================
   CROP & ROTATE  (the visual cropper itself is in custom.js)
   ===================================================================== */
const rotCtl = (def) => fmtCtl(def);
T({ id: 'rotate-right', title: 'Rotate Right 90°', desc: 'Turn the picture clockwise.', icon: '↻', menu: 'crop', group: 'Rotate', kw: ['rotate', 'turn', 'clockwise', '90'], suffix: 'rotated', controls: rotCtl('same'), render: img => transformImg(img, { rot90: 1 }) });
T({ id: 'rotate-left', title: 'Rotate Left 90°', desc: 'Turn the picture counter-clockwise.', icon: '↺', menu: 'crop', group: 'Rotate', kw: ['rotate', 'turn', 'counter', '90'], suffix: 'rotated', controls: rotCtl('same'), render: img => transformImg(img, { rot90: 3 }) });
T({ id: 'rotate-180', title: 'Rotate 180°', desc: 'Turn the picture upside down.', icon: '🙃', menu: 'crop', group: 'Rotate', kw: ['rotate', 'upside down', '180'], suffix: 'rotated', controls: rotCtl('same'), render: img => transformImg(img, { rot90: 2 }) });
T({
  id: 'rotate-any', title: 'Rotate by Any Angle', desc: 'Turn the picture by any number of degrees.', icon: '🌀', menu: 'crop', group: 'Rotate', kw: ['rotate', 'angle', 'degrees', 'tilt'], suffix: 'rotated',
  controls: [{ key: 'angle', type: 'slider', label: 'Angle', min: -180, max: 180, step: 1, default: 30, unit: '°' },
    { key: 'fill', type: 'toggle', label: 'Zoom in to hide empty corners', default: false }, ...fmtCtl('png')],
  render: (img, o) => transformImg(img, { angle: +o.angle, fill: o.fill })
});
T({
  id: 'straighten', title: 'Straighten Picture', desc: 'Fix a crooked horizon with a slider.', icon: '📏', menu: 'crop', group: 'Rotate', kw: ['straighten', 'level', 'crooked', 'horizon', 'tilt'], suffix: 'straight',
  controls: [{ key: 'angle', type: 'slider', label: 'Tilt', min: -20, max: 20, step: .1, default: 3, unit: '°', hint: 'Look at the preview and slide until lines are straight.' },
    { key: 'fill', type: 'toggle', label: 'Zoom in to hide empty corners', default: true }, ...fmtCtl('same')],
  render: (img, o) => transformImg(img, { angle: +o.angle, fill: o.fill })
});
T({ id: 'flip-horizontal', title: 'Flip Horizontal', desc: 'Mirror left to right.', icon: '↔️', menu: 'crop', group: 'Flip', kw: ['flip', 'mirror', 'horizontal'], suffix: 'flipped', controls: rotCtl('same'), render: img => transformImg(img, { flipH: true }) });
T({ id: 'flip-vertical', title: 'Flip Vertical', desc: 'Mirror top to bottom.', icon: '↕️', menu: 'crop', group: 'Flip', kw: ['flip', 'mirror', 'vertical', 'upside'], suffix: 'flipped', controls: rotCtl('same'), render: img => transformImg(img, { flipV: true }) });
T({ id: 'mirror-image', title: 'Mirror Image', desc: 'Make a mirror copy of your picture.', icon: '🪞', menu: 'crop', group: 'Flip', kw: ['mirror', 'reflect', 'flip'], suffix: 'mirror', controls: rotCtl('same'), render: img => transformImg(img, { flipH: true }) });

/* circle avatar */
T({
  id: 'circle-crop', title: 'Round Photo (Avatar)', desc: 'Cut your photo into a perfect circle.', icon: '⭕', menu: 'crop', group: 'Crop', kw: ['circle', 'round', 'avatar', 'profile', 'dp'], suffix: 'circle', multiple: false,
  controls: [
    { key: 'size', type: 'seg', label: 'Size', default: 512, num: true, options: [256, 512, 1024].map(v => ({ v, l: v + ' px' })) },
    { key: 'zoom', type: 'slider', label: 'Zoom', min: 100, max: 300, default: 100, unit: '%' },
    { key: 'fx', type: 'slider', label: 'Move left / right', min: 0, max: 100, default: 50 },
    { key: 'fy', type: 'slider', label: 'Move up / down', min: 0, max: 100, default: 40 },
    { key: 'ring', type: 'slider', label: 'Ring thickness', min: 0, max: 12, default: 0, unit: '%' },
    { key: 'ringColor', type: 'color', label: 'Ring color', default: '#ffffff', showIf: o => o.ring > 0 },
    ...fmtCtl('png', ['png', 'webp'])],
  render(img, o, ctx) {
    const n = ctx.preview ? Math.min(o.size, 700) : o.size, c = Engine.canvas(n, n), x = c.getContext('2d'), z = o.zoom / 100;
    x.save(); x.beginPath(); x.arc(n / 2, n / 2, n / 2, 0, Math.PI * 2); x.clip();
    const r = Math.max(n / img.w, n / img.h) * z, sw = n / r, sh = n / r;
    const sx = (img.w - sw) * (o.fx / 100), sy = (img.h - sh) * (o.fy / 100);
    if (sw > img.w || sh > img.h) { Engine.draw(x, img.src, 0, 0, img.w, img.h, (n - img.w * r) / 2, (n - img.h * r) / 2, img.w * r, img.h * r); }
    else Engine.draw(x, img.src, clamp(sx, 0, img.w - sw), clamp(sy, 0, img.h - sh), sw, sh, 0, 0, n, n);
    x.restore();
    if (o.ring > 0) { const rw = n * o.ring / 100; x.beginPath(); x.arc(n / 2, n / 2, n / 2 - rw / 2, 0, Math.PI * 2); x.lineWidth = rw; x.strokeStyle = o.ringColor; x.stroke(); }
    return c;
  }
});

/* splitter + trim */
function splitCtl(cols, rows) {
  return [
    { key: 'cols', type: 'seg', label: 'Columns (across)', default: cols, num: true, options: [1, 2, 3, 4, 5].map(v => ({ v, l: String(v) })) },
    { key: 'rows', type: 'seg', label: 'Rows (down)', default: rows, num: true, options: [1, 2, 3, 4, 5].map(v => ({ v, l: String(v) })) },
    { key: 'square', type: 'toggle', label: 'Make every piece square (crops edges)', default: false },
    { key: 'order', type: 'toggle', label: 'Number files in Instagram posting order', default: true, hint: 'Post piece 1 first, then 2, 3 ... and your profile grid looks perfect.' },
    ...fmtCtl('jpg', ['jpg', 'png', 'webp']).map(c => c.key === 'quality' ? { ...c, default: 95 } : c)];
}
function splitBox(img, o) {
  let W = img.w, H = img.h, sx = 0, sy = 0;
  if (o.square) { const t = Math.min(W / o.cols, H / o.rows), nw = Math.floor(t * o.cols), nh = Math.floor(t * o.rows); sx = Math.floor((W - nw) / 2); sy = Math.floor((H - nh) / 2); W = nw; H = nh; }
  return { sx, sy, W, H };
}
function splitTool(id, title, cols, rows, icon, desc, kw) {
  T({
    id, title, desc, icon, menu: 'crop', group: 'Split & trim', kw: ['split', 'grid', 'cut', 'pieces', 'instagram', ...kw], suffix: 'piece', multiple: false,
    controls: splitCtl(cols, rows),
    render(img, o, ctx) {
      const b = splitBox(img, o), c = Engine.canvas(b.W, b.H), x = c.getContext('2d');
      x.drawImage(img.src, b.sx, b.sy, b.W, b.H, 0, 0, b.W, b.H);
      if (ctx.preview) {                                   // grid lines only in preview
        const lw = Math.max(2, b.W / 300); x.lineWidth = lw; x.strokeStyle = '#fff'; x.shadowColor = 'rgba(0,0,0,.8)'; x.shadowBlur = lw * 2;
        for (let i = 1; i < o.cols; i++) { x.beginPath(); x.moveTo(b.W * i / o.cols, 0); x.lineTo(b.W * i / o.cols, b.H); x.stroke(); }
        for (let j = 1; j < o.rows; j++) { x.beginPath(); x.moveTo(0, b.H * j / o.rows); x.lineTo(b.W, b.H * j / o.rows); x.stroke(); }
      }
      return c;
    },
    async outputs(canvas, o, item) {
      const tw = Math.floor(canvas.width / o.cols), th = Math.floor(canvas.height / o.rows), outs = [], total = o.cols * o.rows;
      for (let r = 0; r < o.rows; r++) for (let cc = 0; cc < o.cols; cc++) {
        const t = Engine.canvas(tw, th); t.getContext('2d').drawImage(canvas, cc * tw, r * th, tw, th, 0, 0, tw, th);
        const n = o.order ? total - (r * o.cols + cc) : r * o.cols + cc + 1;
        const e = await encodeCanvas(t, o, this, item.file);
        outs.push({ blob: e.blob, name: `${Engine.base(item.file.name)}-${String(n).padStart(2, '0')}.${e.ext}`, w: tw, h: th, n });
      }
      return outs.sort((a, b) => a.n - b.n);
    }
  });
}
splitTool('split-grid', 'Split Picture into Grid', 3, 3, '🧩', 'Cut a picture into equal pieces.', ['grid maker']);
splitTool('split-3x1', 'Instagram Grid 3×1', 3, 1, '🟦', 'Cut into 3 pieces side by side.', ['3x1']);
splitTool('split-3x2', 'Instagram Grid 3×2', 3, 2, '🔲', 'Cut into 6 pieces for your feed.', ['3x2']);
splitTool('split-3x3', 'Instagram Grid 3×3', 3, 3, '🎛️', 'Cut into 9 pieces for your feed.', ['3x3']);
splitTool('split-2x2', 'Split into 4 Pieces (2×2)', 2, 2, '🔳', 'Cut into 4 equal pieces.', ['2x2', 'quarters']);
T({
  id: 'auto-trim', title: 'Trim Empty Edges', desc: 'Remove see-through or plain-color borders.', icon: '🧽', menu: 'crop', group: 'Split & trim', kw: ['trim', 'autocrop', 'transparent', 'whitespace', 'borders', 'remove edges'], suffix: 'trimmed',
  controls: [{ key: 'tol', type: 'slider', label: 'How picky?', min: 0, max: 80, default: 12, hint: 'Higher removes more near-same colors.' },
    { key: 'pad', type: 'slider', label: 'Keep a little space', min: 0, max: 10, default: 0, unit: '%' }, ...fmtCtl('png')],
  render(img, o) {
    const c = Engine.toCanvas(img), b = Pix.contentBox(c, o.tol);
    if (!b) return c;
    const p = Math.round(Math.min(b.w, b.h) * o.pad / 100), x0 = Math.max(0, b.x - p), y0 = Math.max(0, b.y - p), x1 = Math.min(c.width, b.x + b.w + p), y1 = Math.min(c.height, b.y + b.h + p);
    const out = Engine.canvas(x1 - x0, y1 - y0); out.getContext('2d').drawImage(c, x0, y0, x1 - x0, y1 - y0, 0, 0, x1 - x0, y1 - y0); return out;
  }
});

/* =====================================================================
   COMPRESS
   ===================================================================== */
const MAXW = [[0, 'Original'], [4096, '4096'], [2560, '2560'], [1920, '1920'], [1600, '1600'], [1280, '1280'], [1080, '1080'], [800, '800']];
function compressCtl(o) {
  return [
    { key: 'mode', type: 'seg', label: 'How do you want to compress?', default: o.mode || 'quality', options: [{ v: 'quality', l: 'Pick quality' }, { v: 'size', l: 'Pick file size' }] },
    { key: 'quality', type: 'slider', label: 'Quality', min: 10, max: 100, default: o.quality || 75, unit: '%', showIf: x => x.mode === 'quality', hint: '70–80% is the sweet spot: looks the same, much smaller.' },
    { key: 'target', type: 'number', label: 'I want the file to be at most', default: o.target || 200, min: 1, max: 99999, showIf: x => x.mode === 'size' },
    { key: 'unit', type: 'seg', label: 'Unit', default: o.unit || 'KB', options: [{ v: 'KB', l: 'KB' }, { v: 'MB', l: 'MB' }], showIf: x => x.mode === 'size' },
    ...(o.fixed ? [] : [{ key: 'format', type: 'seg', label: 'Save as', default: 'same', options: [{ v: 'same', l: 'Same (PNG→WebP)' }, { v: 'jpg', l: 'JPG' }, { v: 'webp', l: 'WebP' }], hint: 'PNG files cannot shrink much, so they are saved as WebP (still sharp, keeps see-through).' }]),
    { key: 'maxw', type: 'seg', label: 'Also make the picture smaller? (longest side, px)', default: o.maxw || 0, num: true, options: MAXW.map(([v, l]) => ({ v, l })) },
    { key: 'bg', type: 'color', label: 'Background (see-through parts)', default: '#ffffff', showIf: x => (x.format === 'jpg') || o.fixed === 'jpg' }];
}
async function toTarget(canvas, fmt, limit) {
  let cur = canvas, last = null;
  const enc = q => Engine.toBlob(cur, fmt.mime, q);
  for (let round = 0; round < 6; round++) {
    let b = await enc(.95); if (b.size <= limit) return b;
    b = await enc(.5);
    if (b.size <= limit) { let lo = .5, hi = .95, ok = b; for (let i = 0; i < 6; i++) { const mid = (lo + hi) / 2, t = await enc(mid); if (t.size <= limit) { ok = t; lo = mid; } else hi = mid; } return ok; }
    last = b;
    const r = Math.sqrt(limit / b.size) * .96, nw = Math.max(16, Math.floor(cur.width * r)), nh = Math.max(16, Math.floor(cur.height * r));
    if (nw === cur.width && nh === cur.height) break;
    cur = Engine.resample(cur, 0, 0, cur.width, cur.height, nw, nh);
  }
  const b = await enc(.3); return last && last.size < b.size ? last : b;
}
function compressTool(id, title, icon, desc, kw, group, init) {
  const fixed = init.fixed || '';
  T({
    id, title, desc, icon, menu: 'compress', group, kw: ['compress', 'smaller', 'reduce', 'shrink', 'optimize', ...kw], suffix: 'compressed', format: fixed || null,
    controls: compressCtl(init), previewEncode: true,
    render(img, o) {
      const L = Math.max(img.ow, img.oh), r = o.maxw && L > o.maxw ? o.maxw / L : 1;
      return r < 1 ? Engine.fit(img, img.w * r, img.h * r, 'stretch') : Engine.toCanvas(img);
    },
    async encode(canvas, o, item, spec) {
      let fmt = spec.fmt; if (fmt.key === 'png') fmt = FMT.webp;
      const c = fmt.key === 'jpg' ? Engine.flatten(canvas, o.bg || '#ffffff') : canvas;
      const limit = (+o.target || 200) * (o.unit === 'MB' ? 1048576 : 1024);
      const blob = o.mode === 'size' ? await toTarget(c, fmt, limit) : await Engine.toBlob(c, fmt.mime, (o.quality || 75) / 100);
      const f = item.file, same = (f.type === fmt.mime) || (Engine.ext(f.name) === fmt.ext);
      if (o.mode !== 'size' && same && !o.maxw && blob.size >= f.size) return { blob: f, ext: Engine.ext(f.name) || fmt.ext, kept: true };
      return { blob, ext: fmt.ext, w: c.width, h: c.height };
    },
    previewQuality: o => o.mode === 'quality' ? (o.quality || 75) / 100 : null
  });
}
compressTool('compress', 'Compress Pictures', '🗜️', 'Make files smaller. Looks the same.', ['kb', 'mb', 'size', 'email'], 'Smart compress', {});
compressTool('bulk-compress', 'Bulk Compress', '📦', 'Shrink many pictures and get one ZIP.', ['bulk', 'batch', 'many', 'zip', 'multiple'], 'Smart compress', {});
compressTool('compress-whatsapp', 'Compress for WhatsApp', '💬', 'Small and sharp for chats.', ['whatsapp', 'chat', 'telegram'], 'Smart compress', { quality: 72, maxw: 1600 });
compressTool('compress-email', 'Compress for Email', '📧', 'Fits in any email (under 1 MB).', ['email', 'attachment', 'mail'], 'Smart compress', { mode: 'size', target: 1, unit: 'MB', maxw: 2560 });
[[20, 'KB'], [50, 'KB'], [100, 'KB'], [200, 'KB'], [500, 'KB'], [1, 'MB']].forEach(([n, u]) =>
  compressTool(`compress-to-${n}${u.toLowerCase()}`, `Compress to ${n} ${u}`, '🎯', `Make the file ${n} ${u} or smaller.`, [`${n}${u}`, 'target', 'exact size', 'form upload'], 'Target size', { mode: 'size', target: n, unit: u }));
compressTool('compress-jpg', 'Compress JPG', '🟧', 'Make JPG files smaller.', ['jpg', 'jpeg'], 'By type', { fixed: 'jpg' });
compressTool('compress-webp', 'Compress WebP', '🟦', 'Make WebP files smaller.', ['webp'], 'By type', { fixed: 'webp' });

/* =====================================================================
   COLORS & FILTERS
   ===================================================================== */
const ZERO = { exposure: 0, brightness: 0, contrast: 0, saturation: 0, hue: 0, temperature: 0, sepia: 0, gray: 0, invert: 0, grain: 0, blur: 0, sharpen: 0, vignette: 0, pixelate: 0 };
const LOOKS = {
  none:     { e: '🖼️', l: 'Original', v: {} },
  vivid:    { e: '🌈', l: 'Vivid', v: { saturation: 35, contrast: 15 } },
  warm:     { e: '🌅', l: 'Warm', v: { temperature: 35, saturation: 8 } },
  cool:     { e: '❄️', l: 'Cool', v: { temperature: -35 } },
  bw:       { e: '⚫', l: 'Black & White', v: { gray: 100, contrast: 10 } },
  vintage:  { e: '📻', l: 'Vintage', v: { sepia: 55, contrast: -8, saturation: -10, vignette: 35, grain: 22 } },
  dramatic: { e: '🎭', l: 'Dramatic', v: { contrast: 40, saturation: -15, vignette: 40, brightness: -5 } },
  fade:     { e: '🌫️', l: 'Faded', v: { contrast: -20, brightness: 12, saturation: -20 } },
  noir:     { e: '🎞️', l: 'Noir', v: { gray: 100, contrast: 40, vignette: 30 } },
  golden:   { e: '🌇', l: 'Golden Hour', v: { temperature: 45, exposure: 8, saturation: 15 } },
  sepia:    { e: '🟤', l: 'Sepia', v: { sepia: 85 } },
  cinema:   { e: '🎬', l: 'Cinema', v: { contrast: 22, saturation: -8, temperature: -12, vignette: 25 } }
};
function editRender(img, o) {
  const c = Engine.toCanvas(img), m = Math.min(c.width, c.height);
  if (o.auto) Pix.autoLevels(c);
  Pix.adjust(c, o);
  if (o.blur > 0) Pix.blur(c, o.blur / 100 * m * .03);
  if (o.sharpen > 0) Pix.sharpen(c, o.sharpen / 100 * 2.5, Math.max(1, m * .0025));
  if (o.pixelate > 0) Pix.pixelate(c, o.pixelate / 100 * m * .06);
  if (o.vignette > 0) Pix.vignette(c, o.vignette);
  return c;
}
const sl = (key, label, min, max, def, extra = {}) => ({ key, type: 'slider', label, min, max, default: def, ...extra });
T({
  id: 'photo-editor', title: 'Photo Editor', desc: 'Looks, colors, blur, sharpen – all in one.', icon: '🪄', menu: 'edit', group: 'All-in-one', kw: ['editor', 'filters', 'brightness', 'contrast', 'saturation', 'adjust', 'enhance', 'effects'], suffix: 'edited',
  controls: [
    { key: 'look', type: 'looks', label: 'Pick a look', default: 'none', options: Object.entries(LOOKS).map(([v, x]) => ({ v, l: x.l, e: x.e })) },
    { type: 'h', label: 'Fine tune' },
    sl('exposure', 'Exposure', -100, 100, 0), sl('brightness', 'Brightness', -100, 100, 0), sl('contrast', 'Contrast', -100, 100, 0), sl('saturation', 'Color strength', -100, 100, 0),
    sl('temperature', 'Warm ↔ Cool', -100, 100, 0), sl('hue', 'Hue', -180, 180, 0, { unit: '°' }),
    sl('sharpen', 'Sharpen', 0, 100, 0), sl('blur', 'Blur', 0, 100, 0), sl('vignette', 'Dark corners', 0, 100, 0), sl('grain', 'Film grain', 0, 100, 0),
    { key: 'auto', type: 'toggle', label: 'Auto-fix dull pictures', default: false }, ...fmtCtl('same')],
  render: editRender
});
T({ id: 'auto-enhance', title: 'Auto Enhance', desc: 'One click to fix dull, flat pictures.', icon: '✅', menu: 'edit', group: 'All-in-one', kw: ['auto', 'enhance', 'fix', 'improve', 'magic', 'better'], suffix: 'enhanced',
  controls: [sl('saturation', 'Extra color pop', 0, 50, 12), sl('sharpen', 'Extra sharpness', 0, 60, 15), ...fmtCtl('same')], render: (img, o) => editRender(img, { ...o, auto: true }) });
[
  ['brightness', 'Brightness', '☀️', 'Make a picture lighter or darker.', 'brightness', -100, 100, 25, ['bright', 'dark', 'lighter', 'darker']],
  ['contrast', 'Contrast', '◐', 'Make light and dark parts stronger.', 'contrast', -100, 100, 30, ['contrast']],
  ['saturation', 'Color Strength', '🎨', 'Make colors stronger or softer.', 'saturation', -100, 100, 40, ['saturation', 'colour', 'vibrance']],
  ['exposure', 'Exposure', '📸', 'Fix pictures that are too dark or too bright.', 'exposure', -100, 100, 30, ['exposure', 'light']],
  ['hue', 'Change Colors (Hue)', '🌈', 'Shift all colors around the rainbow.', 'hue', -180, 180, 60, ['hue', 'tint']],
  ['temperature', 'Warm or Cool', '🌡️', 'Make the picture warmer or cooler.', 'temperature', -100, 100, 40, ['temperature', 'warm', 'cool', 'white balance']]
].forEach(([id, title, icon, desc, key, min, max, def, kw]) => T({
  id, title, desc, icon, menu: 'edit', group: 'Adjust', kw: [...kw, 'adjust'], suffix: id,
  controls: [sl(key, title, min, max, def, key === 'hue' ? { unit: '°' } : {}), ...fmtCtl('same')], render: (img, o) => editRender(img, o)
}));
T({ id: 'blur', title: 'Blur Picture', desc: 'Make a picture soft and blurry.', icon: '🌫️', menu: 'edit', group: 'Adjust', kw: ['blur', 'soft', 'gaussian', 'hide'], suffix: 'blur', controls: [sl('blur', 'Blur amount', 0, 100, 35), ...fmtCtl('same')], render: editRender });
T({ id: 'sharpen', title: 'Sharpen Picture', desc: 'Make soft pictures crisp.', icon: '🔪', menu: 'edit', group: 'Adjust', kw: ['sharpen', 'crisp', 'clear', 'unblur', 'focus'], suffix: 'sharp', controls: [sl('sharpen', 'Sharpness', 0, 100, 50), ...fmtCtl('same')], render: editRender });
T({ id: 'vignette', title: 'Dark Corners (Vignette)', desc: 'Darken the edges for a cinema feel.', icon: '🔘', menu: 'edit', group: 'Adjust', kw: ['vignette', 'corners', 'edges', 'dark'], suffix: 'vignette', controls: [sl('vignette', 'Strength', 0, 100, 55), ...fmtCtl('same')], render: editRender });
[
  ['looks-vivid', 'Vivid Colors', 'vivid', '🌈', 'Rich, punchy colors.', ['vivid', 'colorful']],
  ['looks-warm', 'Warm Tone', 'warm', '🌅', 'Cozy, warm colors.', ['warm', 'cozy']],
  ['looks-cool', 'Cool Tone', 'cool', '❄️', 'Fresh, cool colors.', ['cool', 'cold', 'blue']],
  ['looks-vintage', 'Vintage Photo', 'vintage', '📻', 'Old-time film look with grain.', ['vintage', 'retro', 'old', 'film']],
  ['looks-dramatic', 'Dramatic', 'dramatic', '🎭', 'Strong contrast and dark edges.', ['dramatic', 'moody']],
  ['looks-fade', 'Faded Look', 'fade', '🌫️', 'Soft, matte, faded colors.', ['fade', 'matte', 'soft']],
  ['looks-noir', 'Noir Black & White', 'noir', '🎞️', 'Classic dramatic black & white.', ['noir', 'bw', 'black and white']],
  ['looks-golden', 'Golden Hour', 'golden', '🌇', 'Sunset glow on any picture.', ['golden', 'sunset', 'glow']],
  ['looks-cinema', 'Cinema Look', 'cinema', '🎬', 'Movie-style color grade.', ['cinema', 'movie', 'film', 'teal']]
].forEach(([id, title, look, icon, desc, kw]) => T({
  id, title, desc, icon, menu: 'edit', group: 'Looks', kw: [...kw, 'filter', 'look', 'preset'], suffix: look,
  controls: [sl('strength', 'How strong?', 0, 100, 100, { unit: '%' }), ...fmtCtl('same')],
  render(img, o) { const k = o.strength / 100, v = {}; for (const key in LOOKS[look].v) v[key] = LOOKS[look].v[key] * k; return editRender(img, v); }
}));
T({ id: 'black-and-white', title: 'Black & White', desc: 'Turn a color picture into grayscale.', icon: '⚫', menu: 'edit', group: 'Looks', kw: ['grayscale', 'gray', 'grey', 'black and white', 'monochrome'], suffix: 'bw', controls: [sl('gray', 'How gray?', 0, 100, 100, { unit: '%' }), sl('contrast', 'Contrast', -50, 100, 10), ...fmtCtl('same')], render: editRender });
T({ id: 'sepia', title: 'Sepia', desc: 'Warm brown old-photo tint.', icon: '🟤', menu: 'edit', group: 'Looks', kw: ['sepia', 'brown', 'old photo'], suffix: 'sepia', controls: [sl('sepia', 'Strength', 0, 100, 85, { unit: '%' }), ...fmtCtl('same')], render: editRender });
T({ id: 'invert', title: 'Invert Colors', desc: 'Flip all colors to their opposite.', icon: '🔁', menu: 'edit', group: 'Effects', kw: ['invert', 'negative', 'opposite'], suffix: 'inverted', controls: [sl('invert', 'Strength', 0, 100, 100, { unit: '%' }), ...fmtCtl('same')], render: editRender });
T({ id: 'pixelate', title: 'Pixelate', desc: 'Big square pixels – hide or style a picture.', icon: '🟩', menu: 'edit', group: 'Effects', kw: ['pixelate', 'mosaic', 'censor', 'pixel art', 'retro'], suffix: 'pixelated', controls: [sl('pixelate', 'Block size', 1, 100, 35), ...fmtCtl('same')], render: editRender });
T({ id: 'film-grain', title: 'Film Grain', desc: 'Add old-film noise to a picture.', icon: '🎲', menu: 'edit', group: 'Effects', kw: ['grain', 'noise', 'film'], suffix: 'grain', controls: [sl('grain', 'Amount', 0, 100, 40), ...fmtCtl('same')], render: editRender });

/* =====================================================================
   ADD & DECORATE
   ===================================================================== */
const grid9 = (def = 8) => ({ key: 'pos', type: 'grid9', label: 'Where?', default: def });
/* place one "stamp" (text or logo) on the picture: corner grid, or tiled all over */
function placeMark(c, mw, mh, o, drawOne) {
  const x = c.getContext('2d'), w = c.width, h = c.height, m = Math.min(w, h), ang = (o.angle || 0) * Math.PI / 180;
  x.save(); x.globalAlpha = (o.opacity == null ? 100 : o.opacity) / 100;
  if (o.tile) {
    const gx = mw * (o.gap == null ? 80 : o.gap) / 100, gy = mh * (o.gap == null ? 80 : o.gap) / 100 * 1.5, sx = mw + gx, sy = mh + gy, R = Math.hypot(w, h) / 2 + mw;
    x.translate(w / 2, h / 2); x.rotate(ang);
    let row = 0; for (let yy = -R; yy <= R; yy += sy, row++) for (let xx = -R + (row % 2 ? sx / 2 : 0); xx <= R; xx += sx) { x.save(); x.translate(xx, yy); drawOne(x); x.restore(); }
  } else {
    const pos = o.pos == null ? 8 : o.pos, col = pos % 3, row = (pos / 3) | 0, mg = (o.margin == null ? 3 : o.margin) / 100 * m;
    const bw = Math.abs(mw * Math.cos(ang)) + Math.abs(mh * Math.sin(ang)), bh = Math.abs(mw * Math.sin(ang)) + Math.abs(mh * Math.cos(ang));
    const cx = col === 0 ? mg + bw / 2 : col === 1 ? w / 2 : w - mg - bw / 2, cy = row === 0 ? mg + bh / 2 : row === 1 ? h / 2 : h - mg - bh / 2;
    x.translate(cx, cy); x.rotate(ang); drawOne(x);
  }
  x.restore();
}
function textStamp(img, o) {
  const c = Engine.toCanvas(img), x = c.getContext('2d'), m = Math.min(c.width, c.height), text = (o.text || '').trim();
  if (!text) return c;
  const px = Math.max(8, o.size / 100 * m);
  x.font = `${o.bold ? '800' : '500'} ${px}px ${FONTS[o.font] || FONTS.clean}`;
  const mw = x.measureText(text).width, mh = px * 1.15, back = o.back;
  placeMark(c, mw + (back ? px * .8 : 0), mh + (back ? px * .5 : 0), o, g => {
    g.font = x.font; g.textAlign = 'center'; g.textBaseline = 'middle';
    if (back) { g.fillStyle = o.backColor; const bw = mw + px * .8, bh = mh + px * .5; g.beginPath(); g.roundRect ? g.roundRect(-bw / 2, -bh / 2, bw, bh, px * .25) : g.rect(-bw / 2, -bh / 2, bw, bh); g.fill(); }
    if (o.outline) { g.lineJoin = 'round'; g.lineWidth = px * .14; g.strokeStyle = o.outlineColor || '#000'; g.strokeText(text, 0, px * .04); }
    else if (o.shadow) { g.shadowColor = 'rgba(0,0,0,.55)'; g.shadowBlur = px * .15; g.shadowOffsetY = px * .05; }
    g.fillStyle = o.color; g.fillText(text, 0, px * .04);
  });
  return c;
}
const textCtl = (d) => [
  { key: 'text', type: 'text', label: 'Your text', default: d.text, placeholder: 'Type here…' },
  { key: 'font', type: 'select', label: 'Letter style', default: d.font || 'clean', options: [{ v: 'clean', l: 'Clean' }, { v: 'bold', l: 'Heavy' }, { v: 'serif', l: 'Classic' }, { v: 'hand', l: 'Handwriting' }, { v: 'mono', l: 'Typewriter' }] },
  sl('size', 'Text size', 1, 40, d.size, { unit: '%' }), { key: 'color', type: 'color', label: 'Text color', default: d.color || '#ffffff' },
  sl('opacity', 'See-through', 10, 100, d.opacity, { unit: '%' }), grid9(d.pos == null ? 8 : d.pos),
  sl('angle', 'Turn', -90, 90, d.angle || 0, { unit: '°' }), sl('margin', 'Space from edge', 0, 15, 3, { unit: '%', showIf: o => !o.tile }),
  { key: 'tile', type: 'toggle', label: 'Repeat all over the picture', default: !!d.tile },
  sl('gap', 'Space between', 0, 300, 80, { unit: '%', showIf: o => o.tile }),
  { key: 'bold', type: 'toggle', label: 'Bold', default: true }, { key: 'shadow', type: 'toggle', label: 'Soft shadow', default: true, showIf: o => !o.outline },
  { key: 'outline', type: 'toggle', label: 'Outline', default: false }, { key: 'outlineColor', type: 'color', label: 'Outline color', default: '#000000', showIf: o => o.outline },
  { key: 'back', type: 'toggle', label: 'Label box behind text', default: false }, { key: 'backColor', type: 'color', label: 'Box color', default: '#000000', showIf: o => o.back },
  ...fmtCtl('same')];
T({ id: 'text-watermark', title: 'Text Watermark', desc: 'Protect your pictures with your name.', icon: '©️', menu: 'add', group: 'Text & watermark', kw: ['watermark', 'copyright', 'text', 'protect', 'logo', 'name'], suffix: 'watermark', controls: textCtl({ text: '© Your Name', size: 6, opacity: 70, pos: 8 }), render: textStamp });
T({ id: 'add-text', title: 'Add Text to Picture', desc: 'Write words on top of your photo.', icon: '🔤', menu: 'add', group: 'Text & watermark', kw: ['text', 'caption', 'write', 'words', 'quote', 'add text'], suffix: 'text', controls: textCtl({ text: 'Hello!', size: 10, opacity: 100, pos: 4, font: 'bold' }), render: textStamp });
T({ id: 'tiled-watermark', title: 'Repeating Watermark', desc: 'Text over the whole picture.', icon: '🔁', menu: 'add', group: 'Text & watermark', kw: ['watermark', 'tile', 'repeat', 'pattern', 'stock', 'sample'], suffix: 'watermark', controls: textCtl({ text: 'SAMPLE', size: 6, opacity: 35, pos: 4, angle: -30, tile: true }), render: textStamp });
T({
  id: 'image-watermark', title: 'Logo / Image Watermark', desc: 'Stamp your logo on your pictures.', icon: '🏷️', menu: 'add', group: 'Text & watermark', kw: ['watermark', 'logo', 'stamp', 'image', 'brand'], suffix: 'logo',
  controls: [{ key: 'logo', type: 'image', label: 'Your logo (PNG works best)' }, sl('size', 'Logo size', 3, 80, 22, { unit: '%' }), sl('opacity', 'See-through', 10, 100, 85, { unit: '%' }), grid9(8),
    sl('angle', 'Turn', -90, 90, 0, { unit: '°' }), sl('margin', 'Space from edge', 0, 15, 3, { unit: '%', showIf: o => !o.tile }),
    { key: 'tile', type: 'toggle', label: 'Repeat all over the picture', default: false }, sl('gap', 'Space between', 0, 300, 80, { unit: '%', showIf: o => o.tile }), ...fmtCtl('same')],
  render(img, o) {
    const c = Engine.toCanvas(img), L = o.logo;
    if (!L || !L.img) return c;
    const mw = c.width * o.size / 100, mh = mw * L.h / L.w;
    placeMark(c, mw, mh, o, g => g.drawImage(L.img, -mw / 2, -mh / 2, mw, mh));
    return c;
  }
});
function wrapLines(x, text, maxW) {
  const words = text.split(/\s+/).filter(Boolean), lines = []; let cur = '';
  for (const w of words) { const t = cur ? cur + ' ' + w : w; if (x.measureText(t).width > maxW && cur) { lines.push(cur); cur = w; } else cur = t; }
  if (cur) lines.push(cur); return lines;
}
T({
  id: 'meme-maker', title: 'Meme Maker', desc: 'Top and bottom text, classic meme style.', icon: '😂', menu: 'add', group: 'Text & watermark', kw: ['meme', 'funny', 'impact', 'top text', 'bottom text', 'caption'], suffix: 'meme', multiple: false,
  controls: [{ key: 'top', type: 'text', label: 'Top text', default: 'WHEN IT FINALLY WORKS', placeholder: 'Top text' }, { key: 'bottom', type: 'text', label: 'Bottom text', default: 'AND IT LOOKS GREAT', placeholder: 'Bottom text' },
    sl('size', 'Text size', 4, 22, 10, { unit: '%' }), { key: 'color', type: 'color', label: 'Text color', default: '#ffffff' }, ...fmtCtl('jpg')],
  render(img, o) {
    const c = Engine.toCanvas(img), x = c.getContext('2d'), w = c.width, h = c.height;
    const px = Math.max(12, w * o.size / 100); x.font = `900 ${px}px ${IMPACT}`; x.textAlign = 'center'; x.textBaseline = 'top'; x.lineJoin = 'round';
    const draw = (txt, top) => {
      const lines = wrapLines(x, (txt || '').toUpperCase(), w * .94), lh = px * 1.05;
      lines.forEach((ln, i) => {
        const y = top ? px * .15 + i * lh : h - px * .15 - (lines.length - i) * lh;
        x.lineWidth = px * .16; x.strokeStyle = '#000'; x.strokeText(ln, w / 2, y); x.fillStyle = o.color; x.fillText(ln, w / 2, y);
      });
    };
    draw(o.top, true); draw(o.bottom, false); return c;
  }
});
function rrect(x, a, b, w, h, r) {
  r = Math.max(0, Math.min(r, w / 2, h / 2)); x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath();
}
T({
  id: 'rounded-corners', title: 'Rounded Corners', desc: 'Round the corners of any picture.', icon: '🔲', menu: 'add', group: 'Frames & shapes', kw: ['rounded', 'corners', 'radius', 'border', 'round'], suffix: 'rounded',
  controls: [sl('radius', 'Roundness', 0, 50, 12, { unit: '%', hint: '50% makes a circle on square pictures.' }), sl('border', 'Border thickness', 0, 10, 0, { unit: '%' }), { key: 'color', type: 'color', label: 'Border color', default: '#ffffff', showIf: o => o.border > 0 }, ...fmtCtl('png', ['png', 'webp'])],
  render(img, o) {
    const w = img.w, h = img.h, m = Math.min(w, h), r = o.radius / 100 * m, bw = o.border / 100 * m, c = Engine.canvas(w, h), x = c.getContext('2d');
    x.save(); rrect(x, 0, 0, w, h, r); x.clip(); x.drawImage(img.src, 0, 0, w, h);
    if (bw > 0) { x.lineWidth = bw * 2; x.strokeStyle = o.color; rrect(x, 0, 0, w, h, r); x.stroke(); }
    x.restore(); return c;
  }
});
T({
  id: 'add-border', title: 'Add Border / Frame', desc: 'Put a colored frame around your picture.', icon: '🖼️', menu: 'add', group: 'Frames & shapes', kw: ['border', 'frame', 'outline', 'edge'], suffix: 'framed',
  controls: [sl('width', 'Frame thickness', 1, 30, 6, { unit: '%' }), { key: 'color', type: 'color', label: 'Frame color', default: '#ffffff' }, sl('round', 'Round the frame corners', 0, 30, 0, { unit: '%' }), ...fmtCtl('same')],
  render(img, o) {
    const m = Math.min(img.w, img.h), b = Math.round(o.width / 100 * m), W = img.w + b * 2, H = img.h + b * 2, c = Engine.canvas(W, H), x = c.getContext('2d');
    x.save(); rrect(x, 0, 0, W, H, o.round / 100 * Math.min(W, H)); x.clip(); x.fillStyle = o.color; x.fillRect(0, 0, W, H); x.drawImage(img.src, b, b, img.w, img.h); x.restore(); return c;
  }
});
T({
  id: 'polaroid', title: 'Polaroid Frame', desc: 'Instant-photo frame with a caption.', icon: '📷', menu: 'add', group: 'Frames & shapes', kw: ['polaroid', 'instant', 'frame', 'photo', 'caption', 'retro'], suffix: 'polaroid',
  controls: [{ key: 'text', type: 'text', label: 'Caption', default: 'Best day ever', placeholder: 'Write something…' }, { key: 'color', type: 'color', label: 'Paper color', default: '#fdfdfb' }, { key: 'ink', type: 'color', label: 'Ink color', default: '#333333' }, ...fmtCtl('jpg')],
  render(img, o) {
    const m = Math.min(img.w, img.h), b = Math.round(m * .06), bot = Math.round(m * .22), W = img.w + b * 2, H = img.h + b + bot, c = Engine.canvas(W, H), x = c.getContext('2d');
    x.fillStyle = o.color; x.fillRect(0, 0, W, H); x.drawImage(img.src, b, b, img.w, img.h);
    x.strokeStyle = 'rgba(0,0,0,.08)'; x.lineWidth = Math.max(1, m * .004); x.strokeRect(b, b, img.w, img.h);
    const px = bot * .42; x.font = `600 ${px}px ${FONTS.hand}`; x.fillStyle = o.ink; x.textAlign = 'center'; x.textBaseline = 'middle';
    let t = (o.text || '').trim(); while (t.length > 1 && x.measureText(t).width > W * .88) t = t.slice(0, -1);
    x.fillText(t, W / 2, img.h + b + bot / 2); return c;
  }
});
T({
  id: 'background-color', title: 'Background Color', desc: 'Put a color behind see-through pictures.', icon: '🪣', menu: 'add', group: 'Backgrounds', kw: ['background', 'transparent', 'color', 'png', 'fill', 'solid'], suffix: 'bg',
  controls: [{ key: 'mode', type: 'seg', label: 'Background type', default: 'color', options: [{ v: 'color', l: 'One color' }, { v: 'gradient', l: 'Gradient' }, { v: 'blur', l: 'Blurry picture' }] },
    { key: 'c1', type: 'color', label: 'Color', default: '#ffffff', showIf: o => o.mode !== 'blur' }, { key: 'c2', type: 'color', label: 'Second color', default: '#c7d2fe', showIf: o => o.mode === 'gradient' },
    sl('pad', 'Space around picture', 0, 40, 0, { unit: '%' }), ...fmtCtl('png')],
  render(img, o) {
    const p = Math.round(Math.min(img.w, img.h) * o.pad / 100), W = img.w + p * 2, H = img.h + p * 2;
    if (o.mode === 'blur') return Engine.fit(img, W, H, 'blur');
    const c = Engine.canvas(W, H), x = c.getContext('2d');
    if (o.mode === 'gradient') { const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, o.c1); g.addColorStop(1, o.c2); x.fillStyle = g; } else x.fillStyle = o.c1;
    x.fillRect(0, 0, W, H); x.drawImage(img.src, p, p, img.w, img.h); return c;
  }
});
T({
  id: 'make-square', title: 'Make Picture Square', desc: 'No cropping – fills the sides nicely.', icon: '⬜', menu: 'add', group: 'Backgrounds', kw: ['square', 'instagram', 'no crop', 'fit', 'padding', '1:1'], suffix: 'square',
  controls: [{ key: 'mode', type: 'seg', label: 'Fill the sides with', default: 'blur', options: [{ v: 'blur', l: 'Blurry picture' }, { v: 'contain', l: 'One color' }] }, { key: 'fill', type: 'color', label: 'Color', default: '#ffffff', showIf: o => o.mode === 'contain' },
    { key: 'side', type: 'seg', label: 'Size', default: 0, num: true, options: [{ v: 0, l: 'Biggest side' }, { v: 1080, l: '1080' }, { v: 2048, l: '2048' }] }, ...fmtCtl('jpg')],
  render(img, o, ctx) { const side = o.side ? o.side * pvK(o.side, o.side, ctx) : Math.max(img.w, img.h); return Engine.fit(img, side, side, o.mode, { bg: o.fill }); }
});

/* =====================================================================
   INFO & PRIVACY
   ===================================================================== */
const gcd = (a, b) => b ? gcd(b, a % b) : a;
async function metaInfo(file, item, full) {
  const ex = await Exif.read(file), rows = [];
  if (full) {
    const g = gcd(item.ow, item.oh);
    rows.push(['File name', esc(file.name)], ['Type', esc(file.type || Engine.ext(file.name).toUpperCase())], ['File size', Engine.formatBytes(file.size)],
      ['Size', `${item.ow} × ${item.oh} px`], ['Megapixels', (item.ow * item.oh / 1e6).toFixed(1) + ' MP'], ['Shape', `${item.ow / g}:${item.oh / g}  (${item.ow >= item.oh ? (item.ow === item.oh ? 'square' : 'landscape') : 'portrait'})`]);
  }
  let found = false;
  if (ex && ex.rows.length) { found = true; ex.rows.forEach(([k, v]) => rows.push([k, esc(v)])); }
  if (ex && ex.gps) { found = true; rows.push(['📍 Location', `<span class="warn">GPS found: ${ex.gps.lat.toFixed(5)}, ${ex.gps.lng.toFixed(5)} – anyone can see where this was taken!</span>`]); }
  const head = full ? 'Picture details' : (found ? '⚠️ Hidden data found in your original' : '✅ No hidden camera data found');
  if (!full && !found) rows.push(['Result', '<span class="okk">Nothing private inside. The saved copy is clean too.</span>']);
  if (!full && found) rows.push(['After saving', '<span class="okk">All of this is removed in the downloaded copy.</span>']);
  if (full && !found) rows.push(['Hidden data', 'No camera or GPS data found']);
  return `<div class="info"><h4>${head}</h4><table>${rows.map(r => `<tr><td>${r[0]}</td><td>${r[1]}</td></tr>`).join('')}</table></div>`;
}
T({ id: 'exif-remover', title: 'Remove Hidden Data (EXIF)', desc: 'Delete location, camera and date from pictures.', icon: '🧼', menu: 'info', group: 'Privacy', kw: ['exif', 'metadata', 'privacy', 'gps', 'location', 'remove', 'strip', 'clean'], suffix: 'clean',
  controls: fmtCtl('same').map(c => c.key === 'quality' ? { ...c, default: 95 } : c), render: copyCanvas, info: (f, it) => metaInfo(f, it, false) });
T({ id: 'image-info', title: 'Check Picture Info', desc: 'See size, type, camera and location.', icon: '🔍', menu: 'info', group: 'Privacy', kw: ['info', 'details', 'properties', 'dimensions', 'size', 'exif', 'viewer', 'metadata'], suffix: 'copy', multiple: false,
  controls: fmtCtl('same').map(c => c.key === 'quality' ? { ...c, default: 95 } : c), render: copyCanvas, info: (f, it) => metaInfo(f, it, true), dlLabel: '⬇️ Download clean copy' });

/* ---------- ICO / favicon maker ---------- */
function buildIco(entries) {                               // entries: [{size, bytes(PNG)}]
  const n = entries.length, head = new DataView(new ArrayBuffer(6 + 16 * n));
  head.setUint16(0, 0, true); head.setUint16(2, 1, true); head.setUint16(4, n, true);
  let off = 6 + 16 * n;
  entries.forEach((e, i) => {
    const p = 6 + i * 16; head.setUint8(p, e.size >= 256 ? 0 : e.size); head.setUint8(p + 1, e.size >= 256 ? 0 : e.size);
    head.setUint16(p + 4, 1, true); head.setUint16(p + 6, 32, true); head.setUint32(p + 8, e.bytes.length, true); head.setUint32(p + 12, off, true); off += e.bytes.length;
  });
  return new Blob([head.buffer, ...entries.map(e => e.bytes)], { type: 'image/x-icon' });
}
T({
  id: 'favicon-maker', title: 'Favicon (ICO) Maker', desc: 'Make favicon.ico with all sizes.', icon: '⭐', menu: 'convert', group: 'Code & icons', kw: ['ico', 'favicon', 'icon', 'website', 'app icon', 'apple touch'], suffix: 'favicon', multiple: false,
  controls: [{ key: 'fit', type: 'seg', label: 'Shape', default: 'cover', options: [{ v: 'cover', l: 'Fill (crop)' }, { v: 'contain', l: 'Keep all' }] },
    ...[16, 32, 48, 64, 128, 256].map(s => ({ key: 's' + s, type: 'toggle', label: `${s} × ${s}`, default: s <= 48 || s === 256 })),
    { key: 'pack', type: 'toggle', label: 'Also give me website PNG files (ZIP)', default: true, hint: 'favicon-16/32, apple-touch-icon (180), android 192 & 512.' }],
  render(img, o, ctx) { const n = ctx.preview ? 256 : 512; return Engine.fit(img, n, n, o.fit, { bg: null }); },
  async outputs(canvas, o, item) {
    const png = async n => new Uint8Array(await (await Engine.toBlob(Engine.resample(canvas, 0, 0, canvas.width, canvas.height, n, n), 'image/png')).arrayBuffer());
    const sizes = [16, 32, 48, 64, 128, 256].filter(s => o['s' + s]); if (!sizes.length) sizes.push(32);
    const entries = []; for (const s of sizes) entries.push({ size: s, bytes: await png(s) });
    const outs = [{ blob: buildIco(entries), name: 'favicon.ico', w: 256, h: 256 }];
    if (o.pack) for (const [n, name] of [[16, 'favicon-16x16.png'], [32, 'favicon-32x32.png'], [180, 'apple-touch-icon.png'], [192, 'android-chrome-192x192.png'], [512, 'android-chrome-512x512.png']])
      outs.push({ blob: new Blob([await png(n)], { type: 'image/png' }), name, w: n, h: n });
    return outs;
  }
});

/* =====================================================================
   PIXELNEST  –  UI
     A. Ads boxes            E. Standard tool workspace (preview + settings)
     B. Drop zone + sample   F. Pages (home, menu page, tool page, info pages)
     C. Settings panel (Ctl) G. Header menu (hover mega menu) + router
     D. Save pipeline
   ===================================================================== */

/* ---------- A. Ads: each ad has its own box so it never covers a tool ---------- */
const Ads = {
  loaded: false,
  html(slot) {
    if (!ADS.enabled && !ADS.showPlaceholders) return '';
    const size = { top: 'wide banner', side: '300 × 600', inline: 'in-page', bottom: 'wide banner' }[slot];
    if (!ADS.enabled) return `<aside class="ad ad-${slot} ph" aria-label="Advertisement"><span class="ad-l">Advertisement</span><div class="ad-box">Ad space · ${size}</div></aside>`;
    return `<aside class="ad ad-${slot}" aria-label="Advertisement"><span class="ad-l">Advertisement</span><div class="ad-box"><ins class="adsbygoogle" style="display:block" data-ad-client="${esc(ADS.client)}" data-ad-slot="${esc(ADS.slots[slot] || '')}" data-ad-format="auto" data-full-width-responsive="true"></ins></div></aside>`;
  },
  mount() {
    if (!ADS.enabled) return;
    if (!Ads.loaded) { const s = document.createElement('script'); s.async = true; s.crossOrigin = 'anonymous'; s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(ADS.client); document.head.appendChild(s); Ads.loaded = true; }
    $$('ins.adsbygoogle:not([data-done])').forEach(i => { i.dataset.done = 1; try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { /* ignore */ } });
  }
};

/* ---------- B. Drop zone + sample picture ---------- */
const ACCEPT = 'image/*,.heic,.heif,.avif,.svg,.bmp,.ico,.jfif,.tif,.tiff';
const Sample = {
  _f: null,
  async file() {                                           // a friendly sample picture drawn by code (so you can try any tool at once)
    if (Sample._f) return Sample._f;
    const W = 1600, H = 1067, c = Engine.canvas(W, H), x = c.getContext('2d');
    let g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#4FB3F6'); g.addColorStop(.55, '#FFD9A0'); g.addColorStop(1, '#FF9F80'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = '#FFF4B0'; x.beginPath(); x.arc(1250, 290, 120, 0, 7); x.fill();
    x.fillStyle = 'rgba(255,255,255,.85)'; [[300, 200, 1], [820, 130, .8], [1350, 470, .7]].forEach(([cx, cy, s]) => { [[0, 0, 70], [70, -20, 85], [150, 0, 65], [75, 20, 70]].forEach(([dx, dy, r]) => { x.beginPath(); x.arc(cx + dx * s, cy + dy * s, r * s, 0, 7); x.fill(); }); });
    x.fillStyle = '#6C63D9'; x.beginPath(); x.moveTo(0, 760); x.lineTo(330, 430); x.lineTo(620, 700); x.lineTo(900, 380); x.lineTo(1250, 760); x.lineTo(1600, 520); x.lineTo(1600, H); x.lineTo(0, H); x.fill();
    x.fillStyle = '#3FB37F'; x.beginPath(); x.moveTo(0, 860); x.quadraticCurveTo(400, 700, 800, 840); x.quadraticCurveTo(1200, 960, 1600, 800); x.lineTo(1600, H); x.lineTo(0, H); x.fill();
    const fx = 560, fy = 600, fr = 250;                    // a happy face, so you can check that faces are never cut off
    x.fillStyle = '#FFD25E'; x.beginPath(); x.arc(fx, fy, fr, 0, 7); x.fill(); x.lineWidth = 12; x.strokeStyle = '#F2A93B'; x.stroke();
    x.fillStyle = '#3B2A20'; [[-85, -50], [85, -50]].forEach(([dx, dy]) => { x.beginPath(); x.ellipse(fx + dx, fy + dy, 24, 38, 0, 0, 7); x.fill(); });
    x.fillStyle = '#FF8FA3'; [[-140, 30], [140, 30]].forEach(([dx, dy]) => { x.beginPath(); x.arc(fx + dx, fy + dy, 34, 0, 7); x.fill(); });
    x.lineWidth = 16; x.lineCap = 'round'; x.strokeStyle = '#3B2A20'; x.beginPath(); x.arc(fx, fy + 20, 120, .2 * Math.PI, .8 * Math.PI); x.stroke();
    x.fillStyle = '#fff'; x.font = '900 70px system-ui,Arial'; x.textAlign = 'right'; x.fillText('IMGENZA ✨', W - 50, H - 50);
    Sample._f = new File([await Engine.toBlob(c, 'image/jpeg', .92)], 'sample-picture.jpg', { type: 'image/jpeg' });
    return Sample._f;
  }
};
function dzHTML(tool, o = {}) {
  const many = tool.multiple !== false && o.multiple !== false;
  return `<div class="dz" id="dz" tabindex="0" role="button" aria-label="Choose pictures. Tap here or drop them here.">
    <div class="big" aria-hidden="true">${o.emoji || '🖼️'}</div>
    <h2>${o.title || (many ? 'Drop your pictures here' : 'Drop your picture here')}</h2>
    <p>or tap the big button below • you can also paste with Ctrl+V</p>
    <button type="button" class="btn" id="pick">📂 ${o.btn || (many ? 'Choose pictures' : 'Choose a picture')}</button>
    ${o.noSample ? '' : '<button type="button" class="link" id="sample">✨ No picture? Try a sample</button>'}
    <input id="fileIn" type="file" hidden accept="${o.accept || ACCEPT}" ${many ? 'multiple' : ''}>
  </div>
  <div class="mini-steps" aria-hidden="true"><span><b>1</b> Choose</span><span><b>2</b> Adjust</span><span><b>3</b> Download</span></div>`;
}
function bindDz(root, onFiles) {
  const dz = $('#dz', root), inp = $('#fileIn', root);
  dz.addEventListener('click', e => { if (e.target.closest('#sample') || e.target.closest('input')) return; inp.click(); });
  dz.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inp.click(); } });
  const s = $('#sample', root); if (s) s.addEventListener('click', async e => { e.stopPropagation(); onFiles([await Sample.file()]); });
  inp.addEventListener('change', () => { const f = [...inp.files]; inp.value = ''; if (f.length) onFiles(f); });
  ['dragenter', 'dragover'].forEach(n => dz.addEventListener(n, e => { e.preventDefault(); dz.classList.add('over'); }));
  ['dragleave', 'drop'].forEach(n => dz.addEventListener(n, e => { e.preventDefault(); dz.classList.remove('over'); if (n === 'drop' && e.dataTransfer) onFiles([...e.dataTransfer.files]); }));
}
function pickImages(files, toastIt = true) {
  const ok = files.filter(Engine.isImage), bad = files.length - ok.length;
  if (bad && toastIt) toast(`😅 ${bad === 1 ? 'That file is' : bad + ' files are'} not a picture. Please choose pictures like JPG, PNG, WebP or HEIC.`, 'bad');
  return ok;
}
function niceError(e) {
  const c = e && e.code;
  if (c === 'NET') return '📡 This picture type needs internet once (to get a small helper). Please connect and try again.';
  if (c === 'SIZE') return 'This result would be too big for the browser. Try a smaller size.';
  if (c === 'FORMAT') return 'Your browser cannot save in this type. Try Chrome or Edge, or pick JPG / PNG.';
  return 'Oops, this picture could not be read. Try another one.';
}

/* ---------- C. Settings panel: builds sliders, buttons, colors from a tool's controls ---------- */
const SWATCH = ['#ffffff', '#000000', '#f3f4f6', '#ff4d4f', '#4f7cff', '#22c55e', '#facc15'];
const Ctl = {
  ratio: () => null,
  defaults(tool) {
    const o = {};
    tool.controls.forEach(c => {
      if (c.type === 'size') { o[c.wkey] = 1080; o[c.hkey] = 1080; o[c.lkey] = true; }
      else if (c.key && c.type !== 'image' && !(c.key in o)) o[c.key] = c.default;
    });
    return o;
  },
  html(c, i, o) {
    const v = o[c.key], id = 'k' + i, hint = c.hint ? `<p class="hint">${esc(c.hint)}</p>` : '';
    switch (c.type) {
      case 'h': return `<div class="c-h2">${esc(c.label)}</div>`;
      case 'slider': return `<div class="c"><div class="c-h"><label for="${id}">${esc(c.label)}</label><output id="out${i}">${v}${c.unit || ''}</output></div><input id="${id}" data-i="${i}" type="range" min="${c.min}" max="${c.max}" step="${c.step || 1}" value="${v}">${hint}</div>`;
      case 'number': return `<div class="c"><div class="c-h"><label for="${id}">${esc(c.label)}</label></div><input id="${id}" data-i="${i}" type="number" inputmode="numeric" min="${c.min || 0}" max="${c.max || ''}" value="${v}">${hint}</div>`;
      case 'text': return `<div class="c"><div class="c-h"><label for="${id}">${esc(c.label)}</label></div><input id="${id}" data-i="${i}" type="text" maxlength="140" value="${esc(v)}" placeholder="${esc(c.placeholder || '')}">${hint}</div>`;
      case 'select': return `<div class="c"><div class="c-h"><label for="${id}">${esc(c.label)}</label></div><select id="${id}" data-i="${i}">${c.options.map(p => `<option value="${esc(p.v)}" ${String(p.v) === String(v) ? 'selected' : ''}>${esc(p.l)}</option>`).join('')}</select>${hint}</div>`;
      case 'seg': return `<div class="c"><div class="c-h"><span class="c-t">${esc(c.label)}</span></div><div class="seg" role="group" aria-label="${esc(c.label)}">${c.options.map(p => `<button type="button" class="seg-b ${String(p.v) === String(v) ? 'on' : ''}" data-i="${i}" data-v="${esc(p.v)}">${esc(p.l)}</button>`).join('')}</div>${hint}</div>`;
      case 'color': return `<div class="c"><div class="c-h"><label for="${id}">${esc(c.label)}</label></div><div class="colorrow"><input id="${id}" data-i="${i}" type="color" value="${v}">${SWATCH.map(s => `<button type="button" class="sw-c" data-i="${i}" data-sw="${s}" style="background:${s}" aria-label="Color ${s}"></button>`).join('')}</div>${hint}</div>`;
      case 'toggle': return `<div class="c"><label class="sw"><input id="${id}" data-i="${i}" type="checkbox" ${v ? 'checked' : ''}><span class="kn"></span>${esc(c.label)}</label>${hint}</div>`;
      case 'grid9': return `<div class="c"><div class="c-h"><span class="c-t">${esc(c.label)}</span></div><div class="g9">${[0, 1, 2, 3, 4, 5, 6, 7, 8].map(n => `<button type="button" data-i="${i}" data-v="${n}" class="${n === v ? 'on' : ''}" aria-label="Position ${n + 1}"></button>`).join('')}</div></div>`;
      case 'looks': return `<div class="c"><div class="c-h"><span class="c-t">${esc(c.label)}</span></div><div class="looks">${c.options.map(p => `<button type="button" class="look ${p.v === v ? 'on' : ''}" data-i="${i}" data-look="${p.v}"><span class="e">${p.e}</span>${esc(p.l)}</button>`).join('')}</div></div>`;
      case 'image': { const L = o[c.key]; return `<div class="c"><div class="c-h"><span class="c-t">${esc(c.label)}</span></div><div class="pickbtn"><button type="button" class="btn-o" data-i="${i}" data-pick="1">📁 ${L ? 'Change' : 'Choose'} picture</button><span>${L ? esc(L.name) : 'Nothing chosen yet'}</span><input type="file" hidden accept="image/*" data-i="${i}" data-file="1"></div></div>`; }
      case 'size': {
        const w = o[c.wkey], lock = o[c.lkey], r = Ctl.ratio(), h = lock && r ? Math.round(w * r) : o[c.hkey];
        return `<div class="c"><div class="c-h"><span class="c-t">${esc(c.label)}</span></div><div class="size-row"><input type="number" inputmode="numeric" min="1" max="16000" data-i="${i}" data-role="w" value="${w}" aria-label="Width"><span aria-hidden="true">×</span><input type="number" inputmode="numeric" min="1" max="16000" data-i="${i}" data-role="h" value="${h}" aria-label="Height" ${lock ? 'disabled' : ''}><button type="button" class="lock" data-i="${i}" data-lock="1" aria-pressed="${!!lock}" title="Keep the shape">${lock ? '🔒' : '🔓'}</button></div><p class="hint">${lock ? 'Shape is kept: the height changes by itself.' : 'Free size: pick any width and height.'}</p></div>`;
      }
    }
    return '';
  },
  render(el, controls, opts, cb) {
    el._c = { controls, opts, cb };
    const act = document.activeElement, keep = act && el.contains(act) ? { i: act.dataset.i, v: act.dataset.v, role: act.dataset.role } : null;
    el.innerHTML = controls.map((c, i) => (!c.showIf || c.showIf(opts)) ? Ctl.html(c, i, opts) : '').join('');
    if (keep && keep.i) { const q = `[data-i="${keep.i}"]` + (keep.v != null ? `[data-v="${keep.v}"]` : '') + (keep.role ? `[data-role="${keep.role}"]` : ''); const n = el.querySelector(q); if (n) n.focus({ preventScroll: true }); }
    if (!el._bound) { el._bound = true; Ctl.bind(el); }
  },
  syncSegs(el) {                                           // keep quick-pick buttons in step with a slider (no redraw)
    const { controls, opts } = el._c;
    $$('.seg-b', el).forEach(b => { const c = controls[+b.dataset.i]; b.classList.toggle('on', String(opts[c.key]) === b.dataset.v); });
  },
  bind(el) {
    const S_ = () => el._c;
    const done = (c, again) => { const { controls, opts, cb } = S_(); if (again) Ctl.render(el, controls, opts, cb); cb(c); };
    const num = (c, v) => c.num ? +v : v;
    el.addEventListener('input', e => {
      const t = e.target, { controls, opts } = S_(), c = controls[+t.dataset.i]; if (!c) return;
      if (c.type === 'slider') { opts[c.key] = +t.value; const out = $('#out' + t.dataset.i, el); if (out) out.textContent = t.value + (c.unit || ''); Ctl.syncSegs(el); done(c, false); }
      else if (c.type === 'number') { opts[c.key] = t.value === '' ? '' : +t.value; done(c, false); }
      else if (c.type === 'text') { opts[c.key] = t.value; done(c, false); }
      else if (c.type === 'color') { opts[c.key] = t.value; done(c, false); }
      else if (c.type === 'size') {
        const v = t.value === '' ? '' : +t.value;
        if (t.dataset.role === 'w') { opts[c.wkey] = v; const r = Ctl.ratio(); if (opts[c.lkey] && r && v) { const h = $('[data-role="h"]', el); if (h) h.value = Math.round(v * r); } }
        else opts[c.hkey] = v;
        done(c, false);
      }
    });
    el.addEventListener('change', e => {
      const t = e.target, { controls, opts } = S_(), c = controls[+t.dataset.i]; if (!c) return;
      if (c.type === 'toggle') { opts[c.key] = t.checked; done(c, true); }
      else if (c.type === 'select') { opts[c.key] = num(c, t.value); done(c, true); }
      else if (c.type === 'slider') { Ctl.render(el, controls, opts, S_().cb); }
      else if (c.type === 'image' && t.files && t.files[0]) {
        const f = t.files[0];
        Engine.load(f, { maxSide: 1600 }).then(im => { opts[c.key] = { img: im.src, w: im.w, h: im.h, name: f.name }; done(c, true); }).catch(() => toast('😅 That logo could not be read. Try a PNG or JPG.', 'bad'));
      }
    });
    el.addEventListener('click', e => {
      const t = e.target.closest('button'); if (!t || t.dataset.i == null) return;
      const { controls, opts } = S_(), c = controls[+t.dataset.i]; if (!c) return;
      if (t.dataset.sw) { opts[c.key] = t.dataset.sw; done(c, true); }
      else if (c.type === 'seg') { opts[c.key] = num(c, t.dataset.v); done(c, true); }
      else if (c.type === 'grid9') { opts[c.key] = +t.dataset.v; done(c, true); }
      else if (t.dataset.look) {
        Object.keys(ZERO).forEach(k => { if (k in opts) opts[k] = 0; }); Object.assign(opts, LOOKS[t.dataset.look].v); opts[c.key] = t.dataset.look; done(c, true);
      } else if (t.dataset.lock) { opts[c.lkey] = !opts[c.lkey]; done(c, true); }
      else if (t.dataset.pick) { $('[data-file]', t.closest('.c')).click(); }
    });
  }
};

/* ---------- D. Save pipeline: turns a canvas into a downloadable file ---------- */
function outSpec(t, o, file) {
  let key = t.format || o.format || 'same';
  if (key === 'same') {
    const e = Engine.ext(file.name), ty = file.type;
    key = (ty === 'image/jpeg' || e === 'jpg' || e === 'jpeg' || e === 'jfif') ? 'jpg' : (ty === 'image/webp' || e === 'webp') ? 'webp' : 'png';
  }
  return { fmt: FMT[key], q: (o.quality || 92) / 100 };
}
async function encodeCanvas(canvas, o, t, file) {
  const spec = outSpec(t, o, file), c = spec.fmt.key === 'jpg' ? Engine.flatten(canvas, o.bg || '#ffffff') : canvas;
  return { blob: await Engine.toBlob(c, spec.fmt.mime, spec.q), ext: spec.fmt.ext, w: c.width, h: c.height };
}
async function finalize(item, t, opts) {
  const o = { ...opts }, ver = S.ver;
  if (item.res && item.res.ver === ver) return item.res;
  if (item.resP && item.resP.ver === ver) return item.resP.p;
  const p = (async () => {
    const img = await Engine.load(item.file, { width: o.width });
    let canvas;
    try { canvas = await t.render(img, o, { preview: false, item }); } finally { img.close && img.close(); }
    let outs;
    if (t.outputs) outs = await t.outputs(canvas, o, item);
    else {
      const spec = outSpec(t, o, item.file);
      const r = t.encode ? await t.encode(canvas, o, item, spec) : await encodeCanvas(canvas, o, t, item.file);
      outs = [{ blob: r.blob, name: `${Engine.base(item.file.name)}-${t.suffix}.${r.ext}`, w: r.w || canvas.width, h: r.h || canvas.height, kept: r.kept }];
    }
    return { ver, outs, size: outs.reduce((a, b) => a + b.blob.size, 0), w: canvas.width, h: canvas.height };
  })();
  item.resP = { ver, p };
  try { const r = await p; if (ver === S.ver) item.res = r; return r; } finally { if (item.resP && item.resP.p === p) item.resP = null; }
}
function downloadOuts(outs, zipName) {
  if (!outs.length) return;
  if (outs.length === 1) { Engine.download(outs[0].blob, outs[0].name); return Promise.resolve(); }
  return Zip.build(outs).then(z => Engine.download(z, zipName));
}

/* =====================================================================
   E. STANDARD WORKSPACE  (big live preview on the left, settings on the right)
   ===================================================================== */
const S = { tool: null, items: [], opts: {}, ver: 0, active: 0, view: 'after', pvId: 0, urls: [], dl: false, initDone: false, paste: null, root: null, uid: 0 };

function leaveTool() {
  Tour.stop();
  S.pvId++; S.ver++; S.urls.forEach(u => URL.revokeObjectURL(u)); S.urls = []; S.items.forEach(i => i.prev && i.prev.close && i.prev.close());
  S.items = []; S.tool = null; S.paste = null; S.cleanup && S.cleanup(); S.cleanup = null;
}
function mountStandard(root, tool) {
  S.root = root; S.items = []; S.active = 0; S.opts = Ctl.defaults(tool); S.ver++; S.view = 'after'; S.initDone = false; S.dl = false;
  S.urls.forEach(u => URL.revokeObjectURL(u)); S.urls = [];
  root.innerHTML = dzHTML(tool, { multiple: tool.multiple });
  bindDz(root, files => addFiles(files));
  S.paste = files => addFiles(files);
}
function buildWorkspace() {
  const t = S.tool;
  S.root.innerHTML = `<div class="ws">
    <div class="card prev">
      <div class="prev-bar">
        <div class="seg" role="group" aria-label="Show"><button type="button" class="seg-b on" data-view="after">✨ After</button><button type="button" class="seg-b" data-view="before">📷 Before</button></div>
        <button type="button" class="btn-o" id="changePic">🔁 ${t.multiple ? 'Add pictures' : 'Change picture'}</button>
        <input id="moreIn" type="file" hidden accept="${ACCEPT}" ${t.multiple ? 'multiple' : ''}>
      </div>
      <div class="stage" id="stage"><canvas id="pv" aria-label="Live preview of your picture"></canvas><div class="busy" id="busy" hidden><div class="spin" role="status" aria-label="Working"></div></div></div>
      <div id="pvErr"></div>
      <div class="cap" id="cap"></div>
      <div class="strip" id="strip" hidden></div>
      <div id="infoBox"></div>
    </div>
    <div class="card set">
      <h3>⚙️ Settings</h3>
      <div id="ctl"></div>
      <button type="button" class="link" id="resetSet">↺ Reset settings</button>
      <div class="sizebox" id="sizeBox">Getting ready…</div>
      <div class="dl-wrap"><button type="button" class="btn-dl" id="dl"><span id="dlTxt">⬇️ Download</span><i class="pg" id="dlPg"></i></button><button type="button" class="btn-o danger" id="again">↺ Start over</button></div>
    </div></div>`;
  const r = S.root;
  if (!r._ws) { r._ws = true; r.addEventListener('click', onWsClick); }
  $('#moreIn', r).addEventListener('change', e => { const f = [...e.target.files]; e.target.value = ''; if (f.length) addFiles(f); });
  Ctl.ratio = () => { const it = S.items[S.active]; return it && it.ow ? it.oh / it.ow : null; };
}
function onWsClick(e) {
  const t = e.target;
  const v = t.closest('[data-view]'); if (v) { S.view = v.dataset.view; $$('[data-view]', S.root).forEach(b => b.classList.toggle('on', b === v)); renderPreview(); return; }
  if (t.closest('#changePic')) { $('#moreIn', S.root).click(); return; }
  if (t.closest('#again')) { mountStandard(S.root, S.tool); return; }
  if (t.closest('#resetSet')) { S.opts = Ctl.defaults(S.tool); S.initDone = false; const it = S.items[S.active]; if (it && it.prev && S.tool.init) { S.tool.init(S.opts, it.prev); S.initDone = true; } drawControls(); changed(); return; }
  if (t.closest('#dl')) { downloadAll(); return; }
  const x = t.closest('[data-x]'); if (x) { e.stopPropagation(); removeItem(+x.dataset.x); return; }
  const th = t.closest('.th'); if (th) { activate(+th.dataset.i); return; }
  if (t.closest('#addMore')) { $('#moreIn', S.root).click(); }
}
async function addFiles(list) {
  const t = S.tool; if (!t) return;
  const ok = pickImages([...list]); if (!ok.length) return;
  const fresh = S.items.length === 0;
  if (!t.multiple) { S.items.forEach(i => i.prev && i.prev.close && i.prev.close()); S.items = []; S.ver++; S.initDone = false; }
  ok.slice(0, 200 - S.items.length).forEach(f => S.items.push({ id: ++S.uid, file: f, thumb: null, res: null, prev: null }));
  if (fresh || !$('.ws', S.root)) buildWorkspace();
  if (fresh || !t.multiple) await activate(0, true);
  else renderStrip();
  makeThumbs();
}
async function ensurePrev(it) {
  const key = S.tool.reload ? S.tool.reload(S.opts) : '';
  if (it.prev && it.prevKey === key) return;
  const p = await Engine.load(it.file, { maxSide: PV_MAX, width: S.opts.width });
  if (it.prev && it.prev.close) it.prev.close();
  it.prev = p; it.prevKey = key; it.ow = p.ow; it.oh = p.oh;
}
async function activate(i, first) {
  const t = S.tool; if (!t || !S.items[i]) return;
  S.active = i; const it = S.items[i]; renderStrip(); showBusy(true); $('#pvErr', S.root).innerHTML = '';
  try { await ensurePrev(it); }
  catch (e) { showBusy(false); $('#pvErr', S.root).innerHTML = `<div class="err-box">${esc(niceError(e))}</div>`; $('#sizeBox', S.root).textContent = 'This picture could not be opened.'; return; }
  if (t.init && !S.initDone) { t.init(S.opts, it.prev); S.initDone = true; }
  drawControls(); loadInfo(it); changed(true);
}
function drawControls() { Ctl.render($('#ctl', S.root), S.tool.controls, S.opts, () => changed()); }
function changed(keepRes) {
  if (!keepRes) S.ver++;
  schedulePreview(); scheduleFinal();
}
const schedulePreview = rafThrottle(() => renderPreview());
const scheduleFinal = debounce(() => updateFinal(), 650);
function showBusy(on) { const b = $('#busy', S.root || document); if (b) b.hidden = !on; }
async function loadInfo(it) {
  const t = S.tool, box = $('#infoBox', S.root); if (!box) return;
  if (!t.info) { box.innerHTML = ''; return; }
  if (!it.info) { try { it.info = await t.info(it.file, it); } catch (e) { it.info = ''; } }
  if (S.items[S.active] === it) box.innerHTML = it.info;
}
async function renderPreview() {
  const t = S.tool, it = S.items[S.active]; if (!t || !it) return;
  const id = ++S.pvId, o = { ...S.opts }, timer = setTimeout(() => showBusy(true), 160);
  try {
    await ensurePrev(it); if (id !== S.pvId) return;
    let c;
    if (S.view === 'before') c = it.prev.src;
    else {
      c = await t.render(it.prev, o, { preview: true, item: it }); if (id !== S.pvId) return;
      const spec = outSpec(t, o, it.file);
      if (t.previewEncode && t.previewQuality && t.previewQuality(o) != null) {          // show the real compression look
        try {
          let f = spec.fmt; if (f.key === 'png') f = FMT.webp;
          const cc = f.key === 'jpg' ? Engine.flatten(c, o.bg || '#fff') : c, b = await Engine.toBlob(cc, f.mime, t.previewQuality(o)), bm = await createImageBitmap(b);
          const tmp = Engine.canvas(bm.width, bm.height); tmp.getContext('2d').drawImage(bm, 0, 0); bm.close && bm.close(); c = tmp;
        } catch (e) { /* ignore */ }
      } else if (spec.fmt.key === 'jpg') c = Engine.flatten(c, o.bg || '#ffffff');
    }
    const sw = c.width, sh = c.height, k = Math.min(1, 2200 / Math.max(sw, sh)), pv = $('#pv', S.root);
    pv.width = Math.max(1, Math.round(sw * k)); pv.height = Math.max(1, Math.round(sh * k));
    pv.getContext('2d').drawImage(c, 0, 0, pv.width, pv.height);
    $('#pvErr', S.root).innerHTML = '';
    $('#cap', S.root).innerHTML = `<span>${S.view === 'before' ? '📷 Your original picture' : '✨ Live preview – changes show instantly'}</span><b>${esc(it.file.name)}</b>`;
  } catch (e) {
    if (id !== S.pvId) return;
    console.warn('IMGENZA preview error:', e);
    $('#pvErr', S.root).innerHTML = `<div class="err-box">${esc(niceError(e))}</div>`;
  } finally { clearTimeout(timer); if (id === S.pvId) showBusy(false); }
}
async function updateFinal() {
  const t = S.tool, it = S.items[S.active]; if (!t || !it || S.dl) return;
  const ver = S.ver, box = $('#sizeBox', S.root); if (!box) return;
  box.innerHTML = '⏳ Working out your file…';
  try {
    const fp = finalize(it, t, S.opts); it.finalP = fp; it.finalVer = ver; const r = await fp; if (ver !== S.ver || it !== S.items[S.active]) return;
    const orig = it.file.size, d = Math.round((1 - r.size / orig) * 100), multi = r.outs.length > 1;
    const change = multi ? `${r.outs.length} files in a ZIP` : (r.outs[0].kept ? '<span class="good">Already very small – we kept your original.</span>' : d > 0 ? `<span class="good">${d}% smaller than the original</span>` : d < 0 ? `<span class="bad">${-d}% bigger than the original</span>` : 'Same size as the original');
    box.innerHTML = `<big>${Engine.formatBytes(r.size)}</big>${change}<br>Before: ${Engine.formatBytes(orig)} · ${it.ow || '?'}×${it.oh || '?'} px<br>${multi ? '' : `After: ${r.outs[0].w}×${r.outs[0].h} px`}`;
  } catch (e) {
    if (ver !== S.ver) return;
    console.warn('IMGENZA final error:', e);
    box.innerHTML = `<span class="bad">${esc(niceError(e))}</span>`;
  }
}
async function downloadAll() {
  if (S.dl || !S.tool || !S.items.length) return;
  S.dl = true; const t = S.tool, btn = $('#dl', S.root), txt = $('#dlTxt', S.root), pg = $('#dlPg', S.root); btn.disabled = true;
  let fails = 0;
  const work = async () => {
    const n = S.items.length, by = new Array(n); let next = 0, done = 0;
    const runner = async () => {
      while (next < n) {
        const i = next++;
        try { const it = S.items[i]; const reuse = it.finalP && it.finalVer === S.ver; let r; if (reuse) { try { r = await it.finalP; } catch (e) { r = null; } } if (!r) r = await finalize(it, t, S.opts); by[i] = r.outs; } catch (e) { fails++; console.warn(e); S.items[i].err = true; }
        done++; txt.textContent = n > 1 ? `⏳ Working… ${done} of ${n}` : '⏳ Working…'; pg.style.width = (done / n * 100) + '%'; await sleep(0);
      }
    };
    await Promise.all(Array.from({ length: Math.min(n, 3) }, runner));
    const outs = by.flat().filter(Boolean);
    pg.style.width = '100%';
    if (!outs.length) throw new Error('NOFILE');
    return outs;
  };
  try {
    await Anim.run({
      src: $('#pv', S.root), count: S.items.length, title: S.items.length > 1 ? `Packing ${S.items.length} pictures` : 'Making your picture ready', work,
      save: outs => downloadOuts(outs, `${t.id}-pictures.zip`),
      sub: outs => (outs.length > 1 ? `${outs.length} files in a ZIP` : Engine.formatBytes(outs[0].blob.size)) + (fails ? ` · ${fails} failed` : '')
    });
  } catch (e) {
    toast(e && e.message === 'NOFILE' ? '😅 We could not make your file. Please try another picture.' : '😅 Could not save the file. Please try again.', 'bad');
  }
  S.dl = false; if ($('#dl', S.root)) { btn.disabled = false; pg.style.width = '0'; setDlText(); }
}
function setDlText() {
  const txt = $('#dlTxt', S.root); if (!txt) return;
  const n = S.items.length, multiOut = S.tool.outputs;
  txt.textContent = (n > 1 || multiOut) ? (n > 1 ? `⬇️ Download all (ZIP) · ${n}` : '⬇️ Download (ZIP)') : (S.tool.dlLabel || '⬇️ Download');
}
function removeItem(i) {
  const it = S.items[i]; if (!it) return;
  S.items.splice(i, 1); S.ver++;
  if (!S.items.length) { mountStandard(S.root, S.tool); return; }
  activate(Math.min(S.active, S.items.length - 1));
}
function renderStrip() {
  const el = $('#strip', S.root); if (!el) return; setDlText();
  if (!S.tool.multiple) { el.hidden = true; return; }
  el.hidden = false;
  el.innerHTML = S.items.map((it, i) => `<div class="th ${i === S.active ? 'on' : ''}" data-i="${i}" role="button" tabindex="0" aria-label="Show ${esc(it.file.name)}">${it.thumb ? `<img src="${it.thumb}" alt="">` : '🖼️'}<button type="button" class="x" data-x="${i}" aria-label="Remove ${esc(it.file.name)}">✕</button></div>`).join('') + `<button type="button" class="add" id="addMore" aria-label="Add more pictures">＋</button>`;
}
let stripRaf = 0;
const renderStripSoon = () => { if (!stripRaf) stripRaf = requestAnimationFrame(() => { stripRaf = 0; renderStrip(); }); };
async function makeThumbs() {
  const tool = S.tool, todo = S.items.filter(it => !it.thumb && !it.thumbTried);
  todo.forEach(it => { it.thumbTried = true; });
  const worker = async () => {
    while (todo.length) {
      const it = todo.shift(); if (S.tool !== tool) return;
      try {
        const im = await Engine.load(it.file, { maxSide: 168 }); if (S.tool !== tool) { im.close && im.close(); return; }
        const c = Engine.toCanvas(im); im.close && im.close();
        const bl = await Engine.toBlob(c, 'image/jpeg', .7); it.thumb = URL.createObjectURL(bl); S.urls.push(it.thumb); renderStripSoon();
      } catch (e) { /* placeholder stays */ }
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
}

/* =====================================================================
   F. PAGES
   ===================================================================== */
const view = html => { $('#view').innerHTML = html; };
function setMeta(title, desc) {
  document.title = title;
  const m = $('meta[name=description]'); if (m) m.content = desc;
}
const anOf = id => { let h = 0; for (const c of id) h = (h * 31 + c.charCodeAt(0)) >>> 0; return 'an' + (h % 10); };
const cardHTML = t => { const m = menuOf(t.menu); return `<a class="tc" style="--acc:${m.color}" href="#/tool/${t.id}"><span class="ic ${anOf(t.id)}" aria-hidden="true"><i>${t.icon}</i></span><span><b>${esc(t.title)}</b><span>${esc(t.desc)}</span></span></a>`; };

function homeBody(q) {
  if (q) {
    const list = searchTools(q);
    if (!list.length) return `<div class="empty"><h3>🤔 No tool found</h3><p>Try a simpler word, like:</p><div class="quick">${['compress', 'resize', 'png', 'crop', 'pdf', 'heic', 'text'].map(s => `<a class="pill" href="#/?q=${s}">${s}</a>`).join('')}</div></div>`;
    return `<h2 class="sec">🔍 ${list.length} tool${list.length > 1 ? 's' : ''} found</h2><div class="grid">${list.map(cardHTML).join('')}</div>`;
  }
  const pop = POPULAR.map(getById).filter(Boolean);
  return `
    <div class="cats">${MENUS.map(m => `<a class="cat" style="--acc:${m.color}" href="#/c/${m.id}"><em>${byMenu(m.id).length}</em><span class="e" aria-hidden="true">${m.icon}</span><b>${m.label}</b><span>${m.desc}</span></a>`).join('')}</div>
    <h2 class="sec">⭐ Most used</h2><div class="grid">${pop.map(cardHTML).join('')}</div>
    ${Ads.html('inline')}
    ${MENUS.map(m => `<h2 class="sec"><span>${m.icon} ${m.label}</span><a href="#/c/${m.id}" style="--acc:${m.color}">See all ${byMenu(m.id).length} →</a></h2><div class="grid">${byMenu(m.id).slice(0, 8).map(cardHTML).join('')}</div>`).join('')}
    <h2 class="sec">💜 Why people love ${SITE.name}</h2>
    <div class="why">
      <div><span style="font-size:34px">🔒</span><b>Private. Really.</b><p>Your pictures never leave your phone or computer. Nothing is uploaded. Ever.</p></div>
      <div><span style="font-size:34px">⚡</span><b>Fast and simple</b><p>Pick a tool, drop a picture, press download. No sign-up, no waiting in line.</p></div>
      <div><span style="font-size:34px">🧰</span><b>${tools.length}+ tools in one place</b><p>Convert, resize, crop, compress, edit, watermark and make PDFs without leaving this site.</p></div>
      <div><span style="font-size:34px">💯</span><b>Free forever</b><p>No watermark, no limits, no hidden costs. Works great on phones too.</p></div>
    </div>
    ${Ads.html('bottom')}`;
}
function viewHome(q) {
  setMeta(`${SITE.name} – Free Online Picture Tools (Convert, Resize, Crop, Compress)`, `${tools.length}+ free picture tools that work inside your browser. Convert, resize, crop, compress, edit and make PDFs. Your files never leave your device.`);
  setKeywords(['image converter online','free photo editor online','resize image online','compress image online','reduce image size','crop image online','png to jpg','jpg to png','webp to jpg','heic to jpg','image to pdf','jpg to pdf','photo to pdf','remove exif data','add watermark to photo','rotate image online','passport size photo maker','instagram post size','youtube thumbnail size','favicon generator','free online picture tools','no upload image tools','bulk image resizer']);
  view(`<div class="wrap">
    <section class="hero">
      <span class="float" aria-hidden="true">🖼️</span><span class="float" aria-hidden="true">✂️</span><span class="float" aria-hidden="true">🎨</span><span class="float" aria-hidden="true">🗜️</span>
      <h1>Fix any picture in <em>2 clicks</em></h1>
      <p class="sub">${tools.length}+ free tools. Convert, resize, crop, compress and more. No sign-up.</p>
      <div class="search"><span class="si" aria-hidden="true">🔍</span><input id="hq" type="search" autocomplete="off" autofocus placeholder="Search: compress, resize, png to jpg..." aria-label="Search tools" value="${esc(q)}"><kbd aria-hidden="true">/</kbd></div>
      <div class="quick">${[['compress', '🗜️ Compress'], ['resize-pixels', '📐 Resize'], ['png-to-jpg', '🖼️ PNG to JPG'], ['crop', '✂️ Crop'], ['image-to-pdf', '📄 To PDF']].map(([id, l]) => `<a class="pill" href="#/tool/${id}">${l}</a>`).join('')}</div>
      <div class="trust">🔒 Your files never leave your device</div>
    </section>
    ${Ads.html('top')}
    <div id="homeBody">${homeBody(q)}</div>
    <section class="seo"><h2>Free online picture tools – convert, resize, crop and compress</h2>
      <p>${SITE.name} is a free toolbox with ${tools.length}+ picture tools that run inside your browser. Convert PNG to JPG, JPG to WebP or HEIC to JPG, resize images to exact pixels or social media sizes, crop and rotate photos, compress pictures to a few KB, edit with filters, add text and watermarks, build PDFs from photos and remove private EXIF data. Nothing is uploaded, nothing is saved on a server, and there is no sign-up or watermark.</p>
      ${MENUS.map(m => `<h3><a href="#/c/${m.id}">${m.icon} ${m.label}</a></h3><p>${esc(m.desc)} Popular: ${byMenu(m.id).slice(0, 6).map(t => `<a href="#/tool/${t.id}">${esc(t.title)}</a>`).join(', ')}.</p>`).join('')}
    </section>
    ${ld({ '@context': 'https://schema.org', '@graph': [{ '@type': 'WebSite', name: SITE.name, description: SITE.tagline, inLanguage: 'en', potentialAction: { '@type': 'SearchAction', target: '#/?q={search_term_string}', 'query-input': 'required name=search_term_string' } }, { '@type': 'Organization', name: SITE.name, description: SITE.tagline }] })}</div>`);
  const hq = $('#hq');
  hq.addEventListener('input', () => { const v = hq.value.trim(); history.replaceState(null, '', v ? '#/?q=' + encodeURIComponent(v) : '#/'); $('#homeBody').innerHTML = homeBody(v); });
}
function viewCat(m) {
  setMeta(`${m.label} Tools – Free Online | ${SITE.name}`, `${m.desc} ${byMenu(m.id).length} free tools. Your files never leave your device.`);
  setKeywords([`${m.label.toLowerCase()} tools`, `free online ${m.label.toLowerCase()} tools`, `${m.label.toLowerCase()} image online`, ...byMenu(m.id).slice(0, 14).map(t => t.title.toLowerCase() + ' online')]);
  view(`<div class="wrap" style="--acc:${m.color}">
    <div class="crumbs"><a href="#/">Home</a> › <span>${m.label}</span></div>
    <div class="th-head"><div class="ic">${m.icon}</div><div><h1>${m.label}</h1><p>${m.desc} (${byMenu(m.id).length} tools)</p></div></div>
    ${Ads.html('top')}
    ${groupsOf(m.id).map((g, i) => `<h2 class="sec">${esc(g.name)}</h2><div class="grid">${g.tools.map(cardHTML).join('')}</div>${i === 1 ? Ads.html('inline') : ''}`).join('')}
    <section class="seo"><h2>${m.label} tools online – free and private</h2><p>${esc(m.desc)} All ${byMenu(m.id).length} ${m.label.toLowerCase()} tools are free, work in your browser on phone and computer, and never upload your pictures. Popular searches: ${byMenu(m.id).slice(0, 12).map(t => esc(t.title.toLowerCase())).join(', ')}.</p></section>
    ${ld({ '@context': 'https://schema.org', '@type': 'CollectionPage', name: `${m.label} tools – ${SITE.name}`, description: m.desc, mainEntity: { '@type': 'ItemList', itemListElement: byMenu(m.id).map((t, i) => ({ '@type': 'ListItem', position: i + 1, name: t.title, url: `#/tool/${t.id}` })) } })}
    <h2 class="sec">Other tool groups</h2><div class="quick" style="justify-content:flex-start">${MENUS.filter(x => x.id !== m.id).map(x => `<a class="pill" href="#/c/${x.id}">${x.icon} ${x.label}</a>`).join('')}</div>
    ${Ads.html('bottom')}</div>`);
}

/* =====================================================================
   SEO: keywords people really type, meta tags, structured data (JSON-LD)
   ===================================================================== */
function seoKeys(t) {
  const b = t.title.toLowerCase().replace(/\s+/g, ' '), set = new Set(), add = k => { k = k.trim().replace(/\s+/g, ' '); if (k) set.add(k); };
  const m = b.match(/^(\w+) to (\w+)$/), a1 = m && m[1], a2 = m && m[2];
  [b, `${b} online`, `${b} free`, `${b} online free`, `free ${b}`, `${b} tool`, `best ${b}`, `how to ${b}`, `${b} without losing quality`, `${b} high quality`,
   `${b} no upload`, `${b} no watermark`, `${b} no sign up`, `${b} on mobile`, `${b} on iphone`, `${b} on android`, `${b} on pc`, `${b} offline`, `${b} in browser`, `${b} without software`, `${b} private`, `${b} fast`
  ].forEach(add);
  if (m) [`${b} converter`, `convert ${a1} to ${a2}`, `convert ${a1} to ${a2} online`, `${a1} to ${a2} converter online free`, `change ${a1} to ${a2}`, `${a1} file to ${a2}`, `${a1} into ${a2}`, `${a1} to ${a2} bulk`, `${a1} to ${a2} converter no upload`, `${a2} from ${a1}`].forEach(add);
  if (t.multiple) [`${b} bulk`, `${b} multiple files`, `${b} batch`].forEach(add);
  const mid = t.menu;
  const by = { convert: ['image converter', 'change picture format', 'photo converter online'], resize: ['resize image online', 'change image size', 'image resizer free', 'resize photo'], crop: ['crop image online', 'photo cropper', 'rotate image online', 'crop photo free'],
    compress: ['compress image online', 'reduce image size', 'reduce photo size kb', 'image compressor free', 'compress jpg'], edit: ['photo editor online', 'free photo editor', 'edit photo online', 'image filters online'],
    add: ['add text to photo', 'watermark photo online', 'photo effects online', 'add border to image'], pdf: ['image to pdf', 'photo to pdf converter', 'jpg to pdf online', 'convert picture to pdf free'], info: ['image metadata viewer', 'remove exif data', 'photo info online', 'image tools online'] }[mid] || [];
  by.forEach(add);
  t.kw.forEach(k => { add(k); add(`${k} online`); add(`${k} free`); add(`${t.title.toLowerCase()} ${k}`); });
  [t.desc.toLowerCase().replace(/[.!?]+$/, '')].forEach(add);
  return [...set].filter(k => k.length < 70).slice(0, 40);
}
function toolTitle(t, m) { const s = `${t.title} Online Free – No Upload | ${SITE.name}`; return s.length <= 62 ? s : `${t.title} – Free Online | ${SITE.name}`; }
function toolDesc(t) {
  const k = seoKeys(t).slice(1, 4).join(', '), s = `${t.desc.replace(/\s+$/, '')} Free ${t.title.toLowerCase()} online: no upload, no sign-up, no watermark. ${k}.`;
  return s.length > 158 ? s.slice(0, 155).replace(/[\s,;]+\S*$/, '') + '…' : s;
}
function setKeywords(list) {
  let m = $('meta[name=keywords]'); if (!m) { m = document.createElement('meta'); m.name = 'keywords'; document.head.appendChild(m); }
  m.content = list.join(', ');
}
const ld = o => `<script type="application/ld+json">${JSON.stringify(o).replace(/</g, '\\u003c')}</script>`;
function toolLD(t, m, faq) {
  return ld({ '@context': 'https://schema.org', '@graph': [
    { '@type': 'WebApplication', name: `${t.title} – ${SITE.name}`, description: t.desc, applicationCategory: 'MultimediaApplication', operatingSystem: 'Any (works in the browser)', browserRequirements: 'Requires JavaScript', isAccessibleForFree: true,
      offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' }, keywords: seoKeys(t).join(', '), inLanguage: 'en', featureList: ['No upload – private', 'Live preview', 'No watermark', 'Works on phone and computer'] },
    { '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: '#/' }, { '@type': 'ListItem', position: 2, name: m.label, item: `#/c/${m.id}` }, { '@type': 'ListItem', position: 3, name: t.title }] },
    { '@type': 'FAQPage', mainEntity: faq.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) }] });
}
function seoHTML(t) {
  const m = menuOf(t.menu), tl = t.title.toLowerCase(), keys = seoKeys(t);
  const how = t.how || [`Choose your ${t.multiple ? 'pictures' : 'picture'}: tap the big button, or drag it in, or paste with Ctrl+V.`, 'Change the settings. The big preview updates at once, so you see exactly what you will get.', 'Press the glowing Download button. Your file is saved on your device.'];
  const faq = [
    [`How do I use ${tl} online for free?`, `Open this page, add your ${t.multiple ? 'pictures' : 'picture'}, adjust the settings you see and press Download. ${SITE.name} is 100% free: no sign-up, no watermark and no limit.`],
    [`Is ${tl} safe and private?`, 'Yes. Every picture is processed inside your own browser. It is never uploaded to a server, so your photos stay private on your phone or computer.'],
    ['Will it ruin my picture quality?', 'No. We use high-quality processing and you can check the live before / after preview before you download. Lossless types like PNG keep every pixel.'],
    [`Can I do ${tl} on my phone (iPhone or Android)?`, 'Yes. It works in any modern browser on iPhone, Android, tablets, Windows, Mac and Linux. There is nothing to install.'],
    [`Can I ${tl} many files at once?`, t.multiple ? 'Yes. Add as many pictures as you like. They are processed one after another on your device and downloaded together in a ZIP.' : 'This tool works on one picture at a time so you can fine-tune it. Open it again for the next picture.'],
    ...(t.faq || [])];
  const related = byMenu(t.menu).filter(x => x.id !== t.id).slice(0, 6).map(x => x.title).join(', ');
  return `<section class="seo"><h2>How to use ${esc(t.title)}</h2><ol>${how.map(h => `<li>${esc(h)}</li>`).join('')}</ol>
    <h2>About ${esc(t.title)}</h2>
    <p>${esc(t.title)} is a free online ${esc(m.label.toLowerCase())} tool that works right inside your browser. ${esc(t.desc)} Because ${SITE.name} runs on your own device, there is no waiting for an upload, no account to create and no watermark on your result. It is a fast, private way to ${esc(tl)} on a phone, tablet or computer.</p>
    <p>People use it for social media posts, school and office work, online shops, websites, WhatsApp and e-mail. If you need something close to this, try ${esc(related)} in the ${esc(m.label)} menu.</p>
    <h2>Questions people ask</h2>${faq.map(([q, a]) => `<details><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}
    <h2>Popular searches</h2><ul class="kw">${keys.slice(0, 16).map(k => `<li>${esc(k)}</li>`).join('')}</ul>${toolLD(t, m, faq)}</section>`;
}
function viewTool(t) {
  const m = menuOf(t.menu);
  setMeta(toolTitle(t, m), toolDesc(t)); setKeywords(seoKeys(t));
  S.tool = t;
  const rel = byMenu(t.menu).filter(x => x.id !== t.id).sort((a, b) => (a.group === t.group ? -1 : 0) - (b.group === t.group ? -1 : 0)).slice(0, 8);
  view(`<div class="wrap" style="--acc:${m.color}">
    <a class="back" href="#/">← Back to Home</a>
    <div class="crumbs"><a href="#/">Home</a> › <a href="#/c/${m.id}">${m.icon} ${m.label}</a> › <span>${esc(t.title)}</span></div>
    <div class="th-head"><div class="ic ${anOf(t.id)} loop" aria-hidden="true"><i>${t.icon}</i></div><div><h1>${esc(t.title)}</h1><p>${esc(t.desc)}</p></div><button type="button" class="guide-btn" id="guideBtn">❓ Show me how</button></div>
    ${Ads.html('top')}
    <div class="layout side"><div><div id="work"></div></div><div class="side-col">${Ads.html('side')}</div></div>
    ${Ads.html('inline')}
    <h2 class="sec">More ${m.label} tools</h2><div class="grid">${rel.map(cardHTML).join('')}</div>
    ${seoHTML(t)}
    ${Ads.html('bottom')}</div>`);
  S.tool = t;
  if (t.mount) t.mount($('#work'), t); else mountStandard($('#work'), t);
  Tour.begin(t);
}
const PAGES = {
  about: { title: 'About', html: () => `<p>${SITE.name} is a free toolbox for pictures. You can convert, resize, crop, compress, edit and decorate pictures, and turn them into PDF files, all in one place.</p>
    <h2>How it works</h2><p>Everything happens inside your own browser. When you choose a picture, it is read by your device and changed by your device. It is never sent to us or to anyone else, because there is no server that receives pictures.</p>
    <h2>Why we made it</h2><p>Many picture sites make you wait, upload private photos, sign up, or pay to remove a watermark. We wanted a simple place where a person who has never used a tool like this can fix a picture in two clicks.</p>
    <h2>What you get</h2><p>${tools.length}+ tools in ${MENUS.length} groups: ${MENUS.map(m => m.label).join(', ')}. New tools are added often.</p>` },
  privacy: { title: 'Privacy Policy', html: () => `<p><b>Short version:</b> your pictures never leave your device.</p>
    <h2>Your pictures</h2><p>All picture work happens locally in your browser. We do not upload, store, view or share your pictures or any data inside them.</p>
    <h2>Information we store</h2><p>Your light / dark mode choice is saved in your browser (localStorage) so the site remembers it. This stays on your device.</p>
    <h2>Advertising and cookies</h2><p>This site may show ads served by Google AdSense or other ad partners. Third-party vendors, including Google, use cookies to serve ads based on a user's previous visits to this or other websites. Google's use of advertising cookies enables it and its partners to serve ads based on visits to this site and other sites on the Internet. You can opt out of personalised advertising at <a href="https://www.google.com/settings/ads" rel="noopener">google.com/settings/ads</a>.</p>
    <h2>Helper files</h2><p>For HEIC (iPhone) pictures the site downloads a small helper script from a public content network the first time it is needed. Your picture is not sent there.</p>
    <h2>Contact</h2><p>Questions about privacy? See the Contact page.</p>` },
  terms: { title: 'Terms of Use', html: () => `<p>By using ${SITE.name} you agree to these simple terms.</p>
    <h2>Use of the tools</h2><p>The tools are provided free, as they are. Please only use pictures you have the right to edit.</p>
    <h2>No guarantee</h2><p>We work hard to make every tool reliable, but we cannot promise it will be error-free. Keep a copy of your original pictures. We are not responsible for loss or damage from using the tools.</p>
    <h2>Your content</h2><p>You keep all rights to your pictures. We never receive them.</p>
    <h2>Changes</h2><p>We may improve or change the tools and these terms at any time.</p>` },
  contact: { title: 'Contact', html: () => SITE.email
    ? `<p>We would love to hear from you: ideas for new tools, problems, or just a hello.</p><p>E-mail: <a href="mailto:${esc(SITE.email)}">${esc(SITE.email)}</a></p>`
    : `<p>We would love to hear from you: ideas for new tools, problems, or just a hello.</p><p>The site owner can show an e-mail address here by setting <code>SITE.email</code> at the top of the code.</p>` }
};
function viewPage(k) {
  const p = PAGES[k]; setMeta(`${p.title} | ${SITE.name}`, `${p.title} – ${SITE.name}`);
  view(`<div class="wrap"><article class="doc"><h1>${p.title}</h1>${p.html()}</article></div>`);
}

/* =====================================================================
   G. HEADER (hover mega menu) + ROUTER + START
   ===================================================================== */
function buildNav() {
  $('#nav').innerHTML = MENUS.map(m => `<div class="nav-i" data-m="${m.id}" style="--acc:${m.color}">
    <button type="button" class="nav-b" aria-haspopup="true" aria-expanded="false"><span class="e" aria-hidden="true">${m.icon}</span>${m.label}</button>
    <div class="mega"><div class="mega-in">
      <div class="mega-top"><b>${m.icon} ${m.label}</b><span>${m.desc}</span><a href="#/c/${m.id}">See all ${byMenu(m.id).length} tools →</a></div>
      <div class="mega-cols">${groupsOf(m.id).map(g => `<div class="mg"><h4>${esc(g.name)}</h4>${g.tools.map(t => `<a href="#/tool/${t.id}"><span class="ic ${anOf(t.id)}" aria-hidden="true"><i>${t.icon}</i></span>${esc(t.title)}</a>`).join('')}</div>`).join('')}</div>
    </div></div></div>`).join('');
  $('#drawerBody').innerHTML = MENUS.map(m => `<details style="--acc:${m.color}"><summary><span aria-hidden="true">${m.icon}</span>${m.label}</summary><div class="dl"><a href="#/c/${m.id}"><b>See all ${byMenu(m.id).length} tools →</b></a>${groupsOf(m.id).map(g => `<h4>${esc(g.name)}</h4>${g.tools.map(t => `<a href="#/tool/${t.id}"><span aria-hidden="true"><i>${t.icon}</i></span>${esc(t.title)}</a>`).join('')}`).join('')}</div></details>`).join('');
  $('#foot').innerHTML = `<div class="wrap"><div class="fgrid">
    <div class="fbrand"><a href="#/" class="logo flogo" aria-label="${SITE.name} home">${LOGO}${SITE.name}</a><p>${SITE.tagline}<br>🔒 Your pictures never leave your device.</p></div>
    ${MENUS.slice(0, 4).map(m => `<div><h4>${m.label}</h4>${byMenu(m.id).slice(0, 5).map(t => `<a href="#/tool/${t.id}">${esc(t.title)}</a>`).join('')}<a href="#/c/${m.id}"><b>All ${m.label.toLowerCase()} →</b></a></div>`).join('')}
    <div><h4>More</h4>${MENUS.slice(4).map(m => `<a href="#/c/${m.id}">${m.icon} ${m.label}</a>`).join('')}</div>
    <div><h4>${SITE.name}</h4>${Object.entries(PAGES).map(([k, p]) => `<a href="#/page/${k}">${p.title}</a>`).join('')}</div></div>
    <div class="fcopy"><span>© ${new Date().getFullYear()} ${SITE.name}. All rights reserved.</span><span>Made with ❤️ for everyone who loves pictures</span></div></div>`;
}
let openItem = null, openT = null, closeT = null;
function openMenu(it) { if (openItem && openItem !== it) { openItem.classList.remove('open'); $('.nav-b', openItem).setAttribute('aria-expanded', 'false'); } openItem = it; it.classList.add('open'); $('.nav-b', it).setAttribute('aria-expanded', 'true'); }
function closeMenu() { clearTimeout(openT); if (openItem) { openItem.classList.remove('open'); $('.nav-b', openItem).setAttribute('aria-expanded', 'false'); openItem = null; } }
function bindNav() {
  const nav = $('#nav'), top = $('#top');
  nav.addEventListener('mouseover', e => {
    const it = e.target.closest('.nav-i'); if (!it) return; clearTimeout(closeT); clearTimeout(openT);
    if (openItem === it) return; openT = setTimeout(() => openMenu(it), openItem ? 0 : 80);
  });
  top.addEventListener('mouseleave', () => { clearTimeout(openT); closeT = setTimeout(closeMenu, 240); });
  top.addEventListener('mouseenter', () => clearTimeout(closeT));
  nav.addEventListener('focusin', e => { const it = e.target.closest('.nav-i'); if (it && e.target.closest('.nav-b')) openMenu(it); });
  nav.addEventListener('click', e => {
    const b = e.target.closest('.nav-b'); if (b) { const it = b.parentElement; if (openItem === it && it.dataset.touched !== '1') { location.hash = '#/c/' + it.dataset.m; closeMenu(); } else { openMenu(it); } return; }
    if (e.target.closest('a')) closeMenu();
  });
  nav.addEventListener('touchstart', e => { const it = e.target.closest('.nav-i'); if (it) it.dataset.touched = openItem === it ? '' : '1'; }, { passive: true });
  nav.addEventListener('touchend', e => { const it = e.target.closest('.nav-i'); if (it) setTimeout(() => { it.dataset.touched = ''; }, 400); }, { passive: true });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeMenu(); closeDrawer(); } });
  document.addEventListener('click', e => { if (!e.target.closest('.top')) closeMenu(); });
  $('#burger').addEventListener('click', () => { $('#drawer').classList.add('open'); document.body.style.overflow = 'hidden'; });
  $('#drawerClose').addEventListener('click', closeDrawer);
  $('#drawer').addEventListener('click', e => { if (e.target.closest('a')) closeDrawer(); });
  $('#themeBtn').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
  $('#hdrSearch').addEventListener('click', () => { if (!(location.hash === '' || location.hash === '#/' || location.hash.startsWith('#/?'))) location.hash = '#/'; setTimeout(() => { const q = $('#hq'); q && (q.focus(), q.scrollIntoView({ block: 'center', behavior: 'smooth' })); }, 60); });
}
function closeDrawer() { $('#drawer').classList.remove('open'); document.body.style.overflow = ''; }
function setTheme(t) {
  document.documentElement.dataset.theme = t; $('#themeBtn').textContent = t === 'dark' ? '☀️' : '🌙';
  try { localStorage.setItem('imgenza-theme', t); } catch (e) { /* ignore */ }
}
function initTheme() {
  let t = null; try { t = localStorage.getItem('imgenza-theme'); } catch (e) { /* ignore */ }
  if (!t) t = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  setTheme(t);
}
function route() {
  const h = location.hash || window.__ROUTE || '#/', qi = h.indexOf('?'), path = qi < 0 ? h : h.slice(0, qi), p = new URLSearchParams(qi < 0 ? '' : h.slice(qi + 1));
  leaveTool(); closeMenu(); closeDrawer(); let m;
  try {
    if ((m = path.match(/^#\/tool\/([\w-]+)/)) && getById(m[1])) viewTool(getById(m[1]));
    else if ((m = path.match(/^#\/c\/([\w-]+)/)) && menuOf(m[1])) viewCat(menuOf(m[1]));
    else if ((m = path.match(/^#\/page\/([\w-]+)/)) && PAGES[m[1]]) viewPage(m[1]);
    else viewHome(p.get('q') || '');
  } catch (err) {
    console.error(err);
    $('#view').innerHTML = '<div class="wrap" style="padding:60px 0;text-align:center"><h1>Oops, this page had a hiccup 🙈</h1><p>Please try again.</p><p><a class="btn-o" href="#/">Go to Home</a></p></div>';
  }
  document.documentElement.style.scrollBehavior = 'auto'; window.scrollTo(0, 0); document.documentElement.style.scrollBehavior = ''; Ads.mount();
}
function startApp() {
  initTheme(); buildNav(); bindNav();
  window.addEventListener('hashchange', route);
  document.addEventListener('click', e => {            // links always work: even same-page links and odd browsers
    const a = e.target.closest && e.target.closest('a[href^="#/"]'); if (!a || e.defaultPrevented || e.button || e.metaKey || e.ctrlKey || e.shiftKey) return;
    e.preventDefault(); const h = a.getAttribute('href');
    if (location.hash === h) route(); else location.hash = h;
  });
  document.addEventListener('paste', e => { if (!S.paste) return; const f = [...(e.clipboardData ? e.clipboardData.files : [])]; if (f.length) { e.preventDefault(); S.paste(f); } });
  document.addEventListener('keydown', e => { if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && $('#hq')) { e.preventDefault(); $('#hq').focus(); } });
  window.addEventListener('dragover', e => e.preventDefault());
  window.addEventListener('drop', e => e.preventDefault());
  route();
}

/* =====================================================================
   PIXELNEST  –  SPECIAL TOOLS (they need their own screen)
     1. Visual crop     2. Pictures to PDF     3. Base64 (both ways)
     4. Color picker + palette     5. Before / after compare slider
   They are still registered with T({...}) like every other tool.
   ===================================================================== */
async function copyText(text) {
  try { await navigator.clipboard.writeText(text); }
  catch (e) { const t = document.createElement('textarea'); t.value = text; t.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (er) { /* ignore */ } t.remove(); }
  toast('📋 Copied!', 'ok');
}
const asBlobUrl = async (file, max = 1600) => {            // a safe preview link for any picture type
  const im = await Engine.load(file, { maxSide: max }), c = Engine.toCanvas(im); im.close && im.close();
  return { url: URL.createObjectURL(await Engine.toBlob(c, 'image/png')), w: im.ow, h: im.oh, canvas: c };
};

/* ---------------------------------------------------------------------
   1. VISUAL CROP  (drag the box, drag the handles, rotate, flip, straighten)
   --------------------------------------------------------------------- */
const ASPECTS = [['Free', null], ['1:1', 1], ['4:3', 4 / 3], ['3:4', 3 / 4], ['3:2', 3 / 2], ['2:3', 2 / 3], ['16:9', 16 / 9], ['9:16', 9 / 16], ['4:5', .8]];
function mountCrop(root, tool) {
  const st = { file: null, prev: null, rot90: 0, flipH: false, flipV: false, angle: 0, fill: true, asp: tool.aspect || null, cr: { x: 0, y: 0, w: 1, h: 1 }, base: null, cw: 0, ch: 0, opts: Ctl.defaults({ controls: fmtCtl('same') }) };
  const fmtControls = fmtCtl('same');
  root.innerHTML = dzHTML(tool, { multiple: false, emoji: '✂️' });
  bindDz(root, f => load(pickImages(f)[0]));
  S.paste = f => load(pickImages(f)[0]);
  let cv, cx, dpr = 1, drag = null, onResize = null;

  async function load(file) {
    if (!file) return;
    try {
      const p = await Engine.load(file, { maxSide: PV_MAX });
      if (st.prev && st.prev.close) st.prev.close();
      Object.assign(st, { file, prev: p, rot90: 0, flipH: false, flipV: false, angle: 0 });
    } catch (e) { toast(niceError(e), 'bad'); return; }
    build();
  }
  function build() {
    root.innerHTML = `<div class="ws">
      <div class="card prev">
        <div class="prev-bar"><span class="c-t">👆 Drag the box to move it. Drag the dots to resize.</span><button type="button" class="btn-o" id="cChange">🔁 Change picture</button><input id="cIn" type="file" hidden accept="${ACCEPT}"></div>
        <div class="cropbox" id="cbox"><canvas id="cc" aria-label="Crop area. Drag to crop."></canvas></div>
        <div class="cap" id="ccap"></div>
      </div>
      <div class="card set">
        <h3>✂️ Crop</h3>
        <div class="c"><div class="c-h"><span class="c-t">Shape of the crop</span></div><div class="chips" id="asp">${ASPECTS.map(([l, a], i) => `<button type="button" class="chip" data-a="${i}">${l}</button>`).join('')}</div></div>
        <div class="c"><div class="c-h"><span class="c-t">Turn &amp; flip</span></div><div class="tools-row">
          <button type="button" data-act="l"><span>↺</span>Left</button><button type="button" data-act="r"><span>↻</span>Right</button>
          <button type="button" data-act="h"><span>↔️</span>Flip</button><button type="button" data-act="v"><span>↕️</span>Flip</button></div></div>
        <div class="c"><div class="c-h"><label for="cAng">Straighten</label><output id="cAngO">0°</output></div><input id="cAng" type="range" min="-30" max="30" step="0.1" value="0" style="width:100%;height:34px;accent-color:var(--acc)"><p class="hint">Fix a crooked horizon.</p></div>
        <div id="cctl"></div>
        <div class="sizebox" id="csize"></div>
        <div class="dl-wrap"><button type="button" class="btn-dl" id="cdl"><span id="cdlT">✂️ Crop &amp; Download</span></button><button type="button" class="btn-o danger" id="cagain">↺ Start over</button></div>
      </div></div>`;
    cv = $('#cc', root); cx = cv.getContext('2d');
    Ctl.render($('#cctl', root), fmtControls, st.opts, () => {});
    setAsp(st.asp); rebuild();
    $('#cChange', root).onclick = () => $('#cIn', root).click();
    $('#cIn', root).onchange = e => { const f = e.target.files[0]; e.target.value = ''; load(pickImages([f])[0]); };
    $('#cagain', root).onclick = () => mountCrop(root, tool);
    $('#cdl', root).onclick = doExport;
    $('#asp', root).onclick = e => { const b = e.target.closest('[data-a]'); if (b) { setAsp(ASPECTS[+b.dataset.a][1]); draw(); } };
    $('.tools-row', root).onclick = e => {
      const b = e.target.closest('[data-act]'); if (!b) return; const a = b.dataset.act;
      if (a === 'l' || a === 'r') { st.rot90 = (st.rot90 + (a === 'r' ? 1 : 3)) % 4; rebuild(); setAsp(st.asp); }
      else if (a === 'h') { st.flipH = !st.flipH; st.cr.x = 1 - st.cr.x - st.cr.w; rebuild(); }
      else { st.flipV = !st.flipV; st.cr.y = 1 - st.cr.y - st.cr.h; rebuild(); }
    };
    $('#cAng', root).oninput = rafThrottle(e => { st.angle = +e.target.value; $('#cAngO', root).textContent = st.angle.toFixed(1) + '°'; rebuild(); });
    cv.addEventListener('pointerdown', down); cv.addEventListener('pointermove', move); cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up);
    onResize = rafThrottle(() => { if (cv.isConnected) layout(); });
    window.addEventListener('resize', onResize);
    S.cleanup = () => window.removeEventListener('resize', onResize);
  }
  function rebuild() { st.base = transformImg(st.prev, { rot90: st.rot90, flipH: st.flipH, flipV: st.flipV, angle: st.angle, fill: st.fill }); layout(); }
  function layout() {
    const b = st.base, box = $('#cbox', root), maxW = Math.max(220, box.clientWidth - 24), maxH = Math.min(innerHeight * .72, 700);
    const sc = Math.min(maxW / b.width, maxH / b.height, 2);
    st.cw = Math.max(40, Math.round(b.width * sc)); st.ch = Math.max(40, Math.round(b.height * sc)); dpr = Math.min(2, window.devicePixelRatio || 1);
    cv.width = Math.round(st.cw * dpr); cv.height = Math.round(st.ch * dpr); cv.style.width = st.cw + 'px'; cv.style.height = st.ch + 'px';
    draw();
  }
  function setAsp(a) {
    st.asp = a; const b = st.base || st.prev, ba = (b.width || b.w) / (b.height || b.h);
    if (!a) st.cr = { x: 0, y: 0, w: 1, h: 1 };
    else { let w = 1, h = 1; if (a >= ba) h = ba / a; else w = a / ba; st.cr = { x: (1 - w) / 2, y: (1 - h) / 2, w, h }; }
    $$('#asp .chip', root).forEach((c, i) => c.classList.toggle('on', ASPECTS[i][1] === a || (a && ASPECTS[i][1] && Math.abs(ASPECTS[i][1] - a) < 1e-6)));
    if (st.base) draw();
  }
  const rectPx = () => ({ x: st.cr.x * st.cw, y: st.cr.y * st.ch, w: st.cr.w * st.cw, h: st.cr.h * st.ch });
  function draw() {
    const { cw, ch } = st, r = rectPx();
    cx.setTransform(dpr, 0, 0, dpr, 0, 0); cx.clearRect(0, 0, cw, ch); cx.imageSmoothingQuality = 'high'; cx.drawImage(st.base, 0, 0, cw, ch);
    cx.fillStyle = 'rgba(10,10,25,.6)'; cx.beginPath(); cx.rect(0, 0, cw, ch); cx.rect(r.x, r.y, r.w, r.h); cx.fill('evenodd');
    cx.strokeStyle = '#fff'; cx.lineWidth = 2; cx.strokeRect(r.x, r.y, r.w, r.h);
    cx.strokeStyle = 'rgba(255,255,255,.45)'; cx.lineWidth = 1; cx.beginPath();
    for (let i = 1; i < 3; i++) { cx.moveTo(r.x + r.w * i / 3, r.y); cx.lineTo(r.x + r.w * i / 3, r.y + r.h); cx.moveTo(r.x, r.y + r.h * i / 3); cx.lineTo(r.x + r.w, r.y + r.h * i / 3); }
    cx.stroke();
    handles(r).forEach(h => { cx.fillStyle = '#fff'; cx.strokeStyle = 'rgba(0,0,0,.55)'; cx.lineWidth = 1.5; cx.beginPath(); cx.arc(h.x, h.y, 8, 0, 7); cx.fill(); cx.stroke(); });
    const fw = Math.round(st.cr.w * st.base.width / st.prev.s), fh = Math.round(st.cr.h * st.base.height / st.prev.s);
    $('#csize', root).innerHTML = `<big>${fw} × ${fh} px</big>Size of your cropped picture<br>Original: ${st.prev.ow} × ${st.prev.oh} px`;
    $('#ccap', root).innerHTML = `<span>✂️ Everything outside the box will be removed</span><b>${esc(st.file.name)}</b>`;
  }
  const handles = r => [['tl', r.x, r.y], ['t', r.x + r.w / 2, r.y], ['tr', r.x + r.w, r.y], ['r', r.x + r.w, r.y + r.h / 2], ['br', r.x + r.w, r.y + r.h], ['b', r.x + r.w / 2, r.y + r.h], ['bl', r.x, r.y + r.h], ['l', r.x, r.y + r.h / 2]].map(([k, x, y]) => ({ k, x, y }));
  const pos = e => { const b = cv.getBoundingClientRect(); return { x: (e.clientX - b.left) * st.cw / b.width, y: (e.clientY - b.top) * st.ch / b.height }; };
  function hit(p, touch) {
    const r = rectPx(), R = touch ? 26 : 16; let best = null, bd = R * R;
    handles(r).forEach(h => { const d = (h.x - p.x) ** 2 + (h.y - p.y) ** 2; if (d < bd) { bd = d; best = h.k; } });
    if (best) return best;
    return p.x > r.x && p.x < r.x + r.w && p.y > r.y && p.y < r.y + r.h ? 'move' : null;
  }
  const CUR = { tl: 'nwse-resize', br: 'nwse-resize', tr: 'nesw-resize', bl: 'nesw-resize', t: 'ns-resize', b: 'ns-resize', l: 'ew-resize', r: 'ew-resize', move: 'move' };
  function down(e) { const p = pos(e), h = hit(p, e.pointerType === 'touch'); if (!h) return; drag = { h, s: rectPx(), p0: p }; cv.setPointerCapture(e.pointerId); e.preventDefault(); }
  function move(e) {
    const p = pos(e);
    if (!drag) { cv.style.cursor = CUR[hit(p, false)] || 'default'; return; }
    const s = drag.s; let r;
    if (drag.h === 'move') r = { x: clamp(s.x + p.x - drag.p0.x, 0, st.cw - s.w), y: clamp(s.y + p.y - drag.p0.y, 0, st.ch - s.h), w: s.w, h: s.h };
    else r = resizeRect(drag.h, s, p);
    st.cr = { x: r.x / st.cw, y: r.y / st.ch, w: r.w / st.cw, h: r.h / st.ch }; draw();
  }
  function up() { drag = null; }
  function resizeRect(h, s, p) {
    const MIN = 28, asp = st.asp, cw = st.cw, ch = st.ch, L = s.x, R = s.x + s.w, T = s.y, B = s.y + s.h;
    if (!asp) {
      let l = L, r = R, t = T, b = B;
      if (h.includes('l')) l = clamp(p.x, 0, R - MIN); if (h.includes('r')) r = clamp(p.x, L + MIN, cw);
      if (h.includes('t')) t = clamp(p.y, 0, B - MIN); if (h.includes('b')) b = clamp(p.y, T + MIN, ch);
      return { x: l, y: t, w: r - l, h: b - t };
    }
    const cxm = (L + R) / 2, cym = (T + B) / 2;
    if (h.length === 2) {
      const ax = h.includes('l') ? R : L, ay = h.includes('t') ? B : T, dx = h.includes('l') ? -1 : 1, dy = h.includes('t') ? -1 : 1;
      let w = Math.max(Math.abs(p.x - ax), Math.abs(p.y - ay) * asp);
      w = Math.max(MIN, Math.min(w, dx < 0 ? ax : cw - ax, (dy < 0 ? ay : ch - ay) * asp)); const hh = w / asp;
      return { x: dx < 0 ? ax - w : ax, y: dy < 0 ? ay - hh : ay, w, h: hh };
    }
    if (h === 'l' || h === 'r') {
      const ax = h === 'l' ? R : L; let w = Math.abs(p.x - ax);
      w = Math.max(MIN, Math.min(w, h === 'l' ? ax : cw - ax, 2 * Math.min(cym, ch - cym) * asp)); const hh = w / asp;
      return { x: h === 'l' ? ax - w : ax, y: cym - hh / 2, w, h: hh };
    }
    const ay = h === 't' ? B : T; let hh = Math.abs(p.y - ay);
    hh = Math.max(MIN / asp, Math.min(hh, h === 't' ? ay : ch - ay, 2 * Math.min(cxm, cw - cxm) / asp)); const w = hh * asp;
    return { x: cxm - w / 2, y: h === 't' ? ay - hh : ay, w, h: hh };
  }
  async function exportCanvas() {
    const img = await Engine.load(st.file);
    try {
      const T_ = transformImg(img, { rot90: st.rot90, flipH: st.flipH, flipV: st.flipV, angle: st.angle, fill: st.fill });
      const sx = clamp(Math.round(st.cr.x * T_.width), 0, T_.width - 1), sy = clamp(Math.round(st.cr.y * T_.height), 0, T_.height - 1);
      const w = clamp(Math.round(st.cr.w * T_.width), 1, T_.width - sx), h = clamp(Math.round(st.cr.h * T_.height), 1, T_.height - sy);
      const out = Engine.canvas(w, h); out.getContext('2d').drawImage(T_, sx, sy, w, h, 0, 0, w, h); return out;
    } finally { img.close && img.close(); }
  }
  async function doExport() {
    const btn = $('#cdl', root), t = $('#cdlT', root); btn.disabled = true; t.textContent = '⏳ Working…';
    try {
      const r = await Anim.run({ src: $('canvas', root), title: 'Cropping your picture', work: async () => encodeCanvas(await exportCanvas(), st.opts, tool, st.file),
        save: r => Engine.download(r.blob, `${Engine.base(st.file.name)}-cropped.${r.ext}`), sub: r => `${Engine.formatBytes(r.blob.size)} · ${r.w}×${r.h} px` });
      $('#csize', root).innerHTML = `<big>${Engine.formatBytes(r.blob.size)}</big>Saved ${r.w} × ${r.h} px`;
    } catch (e) { toast(niceError(e), 'bad'); }
    btn.disabled = false; t.textContent = '✂️ Crop & Download';
  }
}
[
  ['crop', 'Crop Picture', null, '✂️', 'Cut out the part you want.', ['crop', 'cut', 'trim', 'free']],
  ['crop-square', 'Crop to Square (1:1)', 1, '⬛', 'Perfect square for profile pictures.', ['square', '1:1', 'profile']],
  ['crop-4-3', 'Crop to 4:3', 4 / 3, '🖥️', 'Classic photo shape.', ['4:3']],
  ['crop-3-2', 'Crop to 3:2', 3 / 2, '📷', 'The shape of most cameras.', ['3:2']],
  ['crop-16-9', 'Crop to 16:9', 16 / 9, '🎞️', 'Wide screen and video shape.', ['16:9', 'widescreen', 'youtube']],
  ['crop-9-16', 'Crop to 9:16', 9 / 16, '📱', 'Tall phone shape for stories.', ['9:16', 'story', 'reel', 'vertical']],
  ['crop-4-5', 'Crop to 4:5', .8, '🤳', 'Instagram portrait shape.', ['4:5', 'instagram', 'portrait']]
].forEach(([id, title, aspect, icon, desc, kw]) => T({ id, title, desc, icon, menu: 'crop', group: 'Crop', kw: ['crop', ...kw], multiple: false, aspect, controls: [], mount: mountCrop }));

/* ---------------------------------------------------------------------
   2. PICTURES TO PDF
   --------------------------------------------------------------------- */
function mountPdf(root, tool) {
  const d = tool.pdfDefaults || {};
  const ctls = [
    { key: 'size', type: 'seg', label: 'Page size', default: d.size || 'a4', options: [{ v: 'a4', l: 'A4' }, { v: 'letter', l: 'Letter' }, { v: 'fit', l: 'Same as picture' }] },
    { key: 'orient', type: 'seg', label: 'Page direction', default: 'auto', options: [{ v: 'auto', l: 'Auto' }, { v: 'p', l: 'Upright' }, { v: 'l', l: 'Sideways' }], showIf: o => o.size !== 'fit' },
    { key: 'margin', type: 'seg', label: 'Space around the picture', default: d.margin || 'small', options: [{ v: 'none', l: 'None' }, { v: 'small', l: 'Small' }, { v: 'big', l: 'Big' }] },
    { key: 'qual', type: 'seg', label: 'Quality', default: d.qual || 'bal', options: [{ v: 'best', l: 'Best' }, { v: 'bal', l: 'Balanced' }, { v: 'small', l: 'Smaller file' }] }];
  const opts = Ctl.defaults({ controls: ctls }), items = [], urls = []; let sel = 0, busy = false, uid = 0;
  const MARGIN = { none: 0, small: 24, big: 48 }, QUAL = { best: [.95, 6000], bal: [.85, 2600], small: [.7, 1600] };
  root.innerHTML = dzHTML(tool, { emoji: '📄', title: 'Drop your pictures here', btn: 'Choose pictures' });
  bindDz(root, add); S.paste = add;

  async function add(files) {
    const ok = pickImages(files); if (!ok.length) return;
    const fresh = !items.length;
    for (const f of ok.slice(0, 100 - items.length)) items.push({ id: ++uid, file: f });
    if (fresh) build();
    render();
    for (const it of items) {
      if (it.url || it.bad) continue;
      try { const t = await asBlobUrl(it.file, 220); it.url = t.url; urls.push(t.url); it.ow = t.w; it.oh = t.h; render(); }
      catch (e) { it.bad = true; toast(`😅 "${it.file.name}" could not be read, so it was skipped.`, 'bad'); items.splice(items.indexOf(it), 1); render(); }
    }
    if (!items.length) mountPdf(root, tool);
  }
  function build() {
    root.innerHTML = `<div class="ws">
      <div class="card prev">
        <div class="prev-bar"><span class="c-t">📄 Page preview</span><button type="button" class="btn-o" id="pAdd">➕ Add more pictures</button><input id="pIn" type="file" hidden multiple accept="${ACCEPT}"></div>
        <div class="stage" id="pst"><div class="paper" id="paper"><img id="pimg" alt="Page preview"></div></div>
        <div class="cap" id="pcap"></div>
        <h4 style="margin:16px 0 0">Your pages <small style="font-weight:600;color:var(--muted)">(use ▲ ▼ to change the order)</small></h4>
        <div class="plist" id="plist"></div>
      </div>
      <div class="card set"><h3>⚙️ Settings</h3><div id="pctl"></div>
        <div class="sizebox" id="psize"></div>
        <div class="dl-wrap"><button type="button" class="btn-dl" id="pdl"><span id="pdlT">📄 Make PDF</span><i class="pg" id="ppg"></i></button><button type="button" class="btn-o danger" id="pagain">↺ Start over</button></div></div></div>`;
    Ctl.render($('#pctl', root), ctls, opts, () => preview());
    $('#pAdd', root).onclick = () => $('#pIn', root).click();
    $('#pIn', root).onchange = e => { const f = [...e.target.files]; e.target.value = ''; add(f); };
    $('#pagain', root).onclick = () => { urls.forEach(u => URL.revokeObjectURL(u)); mountPdf(root, tool); };
    $('#pdl', root).onclick = make;
    $('#plist', root).onclick = e => {
      const b = e.target.closest('[data-a]'), row = e.target.closest('[data-i]'); if (!row) return; const i = +row.dataset.i;
      if (b) { const a = b.dataset.a; if (a === 'up' && i > 0) { [items[i - 1], items[i]] = [items[i], items[i - 1]]; sel = i - 1; } else if (a === 'down' && i < items.length - 1) { [items[i + 1], items[i]] = [items[i], items[i + 1]]; sel = i + 1; } else if (a === 'rm') { items.splice(i, 1); sel = Math.max(0, Math.min(sel, items.length - 1)); if (!items.length) { mountPdf(root, tool); return; } } }
      else sel = i;
      render();
    };
    S.cleanup = () => urls.forEach(u => URL.revokeObjectURL(u));
  }
  const dims = it => {                                     // same page maths as the PDF writer
    const m = MARGIN[opts.margin], w = it.ow || 3, h = it.oh || 4;
    if (opts.size === 'fit') return { pw: w * .75 + 2 * m, ph: h * .75 + 2 * m, m, w, h };
    const A = opts.size === 'letter' ? [612, 792] : [595.28, 841.89], land = opts.orient === 'l' || (opts.orient !== 'p' && w > h);
    return { pw: land ? A[1] : A[0], ph: land ? A[0] : A[1], m, w, h };
  };
  function render() {
    if (!$('#plist', root)) return;
    $('#plist', root).innerHTML = items.map((it, i) => `<div class="pitem ${i === sel ? 'on' : ''}" data-i="${i}"><img src="${it.url || ''}" alt=""><div class="n">${i + 1}. ${esc(it.file.name)}</div><button type="button" data-a="up" aria-label="Move up" ${i === 0 ? 'disabled' : ''}>▲</button><button type="button" data-a="down" aria-label="Move down" ${i === items.length - 1 ? 'disabled' : ''}>▼</button><button type="button" data-a="rm" aria-label="Remove">✕</button></div>`).join('');
    preview();
  }
  async function preview() {
    const it = items[sel]; if (!it || !$('#paper', root)) return;
    const { pw, ph, m, w, h } = dims(it), st = $('#pst', root), availW = Math.max(180, st.clientWidth - 30), maxH = Math.min(innerHeight * .62, 560), sc = Math.min(availW / pw, maxH / ph);
    const paper = $('#paper', root), img = $('#pimg', root);
    paper.style.width = Math.round(pw * sc) + 'px'; paper.style.height = Math.round(ph * sc) + 'px';
    const bw = pw - 2 * m, bh = ph - 2 * m, r = Math.min(bw / w, bh / h), iw = w * r, ih = h * r, ix = (pw - iw) / 2, iy = (ph - ih) / 2;
    Object.assign(img.style, { left: ix / pw * 100 + '%', top: iy / ph * 100 + '%', width: iw / pw * 100 + '%', height: ih / ph * 100 + '%', objectFit: 'fill' });
    if (!it.big) { img.src = it.url || ''; try { const t = await asBlobUrl(it.file, 900); it.big = t.url; urls.push(t.url); if (items[sel] === it) img.src = t.url; } catch (e) { /* keep thumb */ } } else img.src = it.big;
    $('#pcap', root).innerHTML = `<span>Page ${sel + 1} of ${items.length}</span><b>${opts.size === 'fit' ? 'Page = picture size' : opts.size === 'a4' ? 'A4 page' : 'Letter page'}</b>`;
    $('#psize', root).innerHTML = `<big>${items.length} page${items.length > 1 ? 's' : ''}</big>Your pictures are never uploaded. The PDF is made on your device.`;
  }
  async function make() {
    if (busy || !items.length) return; busy = true;
    const btn = $('#pdl', root), t = $('#pdlT', root), pg = $('#ppg', root); btn.disabled = true;
    try {
      const [q, max] = QUAL[opts.qual], pages = [];
      for (let i = 0; i < items.length; i++) {
        t.textContent = `⏳ Page ${i + 1} of ${items.length}…`; pg.style.width = (i / items.length * 100) + '%';
        const im = await Engine.load(items[i].file, { maxSide: max });
        const c = Engine.flatten(Engine.toCanvas(im), '#ffffff'); im.close && im.close();
        const b = await Engine.toBlob(c, 'image/jpeg', q);
        pages.push({ jpg: new Uint8Array(await b.arrayBuffer()), w: c.width, h: c.height }); await sleep(0);
      }
      const blob = PDF.build(pages, { size: opts.size, orient: opts.orient, margin: MARGIN[opts.margin] });
      await Anim.run({ src: $('canvas', root), title: 'Building your PDF', work: async () => blob, save: b => Engine.download(b, items.length === 1 ? Engine.base(items[0].file.name) + '.pdf' : 'pictures.pdf'), sub: b => `PDF · ${Engine.formatBytes(b.size)}` });
      $('#psize', root).innerHTML = `<big>${Engine.formatBytes(blob.size)}</big>${pages.length} page${pages.length > 1 ? 's' : ''} saved as PDF`;
    } catch (e) { console.warn(e); toast(niceError(e), 'bad'); }
    busy = false; btn.disabled = false; t.textContent = '📄 Make PDF'; pg.style.width = '0';
  }
}
[
  ['image-to-pdf', 'Picture to PDF', '📄', 'Turn pictures into one PDF file.', ['image', 'picture', 'photo', 'pdf', 'merge'], {}],
  ['jpg-to-pdf', 'JPG to PDF', '🟧', 'Turn JPG pictures into a PDF.', ['jpg', 'jpeg'], {}],
  ['png-to-pdf', 'PNG to PDF', '🟦', 'Turn PNG pictures into a PDF.', ['png'], {}],
  ['webp-to-pdf', 'WebP to PDF', '🌐', 'Turn WebP pictures into a PDF.', ['webp'], {}],
  ['photos-to-pdf-album', 'Photo Album PDF', '📚', 'Big pictures, one per page, no borders.', ['album', 'photos', 'portfolio'], { size: 'fit', margin: 'none', qual: 'best' }],
  ['scan-to-pdf', 'Scan to PDF', '🧾', 'Turn phone photos of papers into a PDF.', ['scan', 'document', 'paper', 'receipt', 'id card'], { size: 'a4', margin: 'small', qual: 'bal' }]
].forEach(([id, title, icon, desc, kw, def]) => T({ id, title, desc, icon, menu: 'pdf', group: 'Pictures to PDF', kw: ['pdf', 'document', ...kw], multiple: true, controls: [], pdfDefaults: def, mount: mountPdf,
  how: ['Choose one or many pictures. Tap the big button or drop them in.', 'Use ▲ ▼ to put the pages in order and pick the page size. The preview shows each page.', 'Press “Make PDF”. Your PDF is saved on your device. Nothing is uploaded.'] }));

/* ---------------------------------------------------------------------
   3. BASE64  (picture → text, text → picture)
   --------------------------------------------------------------------- */
function mountB64Encode(root, tool) {
  root.innerHTML = dzHTML(tool, { multiple: false, emoji: '🔤' });
  const go = async files => {
    const f = pickImages(files)[0]; if (!f) return;
    const dataUrl = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
    const raw = dataUrl.slice(dataUrl.indexOf(',') + 1), mime = dataUrl.slice(5, dataUrl.indexOf(';'));
    let prevUrl = null; try { prevUrl = (await asBlobUrl(f, 600)).url; } catch (e) { /* no preview */ }
    root.innerHTML = `<div class="ws"><div class="card prev"><div class="prev-bar"><span class="c-t">🔤 Your picture as text</span><button type="button" class="btn-o" id="bChange">🔁 Change picture</button><input id="bIn" type="file" hidden accept="${ACCEPT}"></div>
      <div class="stage">${prevUrl ? `<img src="${prevUrl}" alt="Your picture" style="max-height:340px;border-radius:8px">` : '<p>No preview for this type</p>'}</div>
      <div class="cap"><span>${esc(mime)} · ${Engine.formatBytes(f.size)}</span><b>${raw.length.toLocaleString()} characters</b></div>
      <h4 style="margin:16px 0 8px">Text (Base64)</h4><textarea class="ta" id="bTa" readonly>${esc(dataUrl.length > 30000 ? dataUrl.slice(0, 30000) + '…  (cut for display – the copy buttons copy everything)' : dataUrl)}</textarea></div>
      <div class="card set"><h3>📋 Copy or save</h3><div class="dl-wrap">
        <button type="button" class="btn sm" data-c="uri">Copy full data link</button><button type="button" class="btn-o" data-c="raw">Copy Base64 only</button>
        <button type="button" class="btn-o" data-c="img">Copy &lt;img&gt; tag</button><button type="button" class="btn-o" data-c="css">Copy CSS background</button>
        <button type="button" class="btn-dl" id="bSave"><span>⬇️ Save as .txt</span></button><button type="button" class="btn-o danger" id="bAgain">↺ Start over</button></div>
        <p class="hint" style="margin-top:12px">Your picture is not changed or re-saved, so the text is a perfect copy.</p></div></div>`;
    const map = { uri: dataUrl, raw, img: `<img src="${dataUrl}" alt="">`, css: `background-image: url("${dataUrl}");` };
    root.onclick = e => { const b = e.target.closest('[data-c]'); if (b) copyText(map[b.dataset.c]); };
    $('#bSave', root).onclick = () => Anim.run({ src: $('img', root) || null, title: 'Saving your text file', work: async () => new Blob([dataUrl], { type: 'text/plain' }), save: b => Engine.download(b, Engine.base(f.name) + '-base64.txt'), sub: b => Engine.formatBytes(b.size) }).catch(() => {});
    $('#bAgain', root).onclick = () => { if (prevUrl) URL.revokeObjectURL(prevUrl); mountB64Encode(root, tool); };
    $('#bChange', root).onclick = () => $('#bIn', root).click(); $('#bIn', root).onchange = e => { const x = [...e.target.files]; e.target.value = ''; go(x); };
  };
  bindDz(root, go); S.paste = go;
}
T({ id: 'image-to-base64', title: 'Picture to Base64', desc: 'Turn a picture into text for websites and code.', icon: '🔤', menu: 'convert', group: 'Code & icons', kw: ['base64', 'data uri', 'encode', 'text', 'html', 'css', 'developer'], multiple: false, controls: [], mount: mountB64Encode,
  how: ['Choose a picture.', 'See your picture as Base64 text and choose what to copy: data link, plain Base64, an <img> tag or CSS.', 'Paste it into your website or code, or save it as a .txt file.'] });

function sniffType(u) {
  const a = u;
  if (a[0] === 0x89 && a[1] === 0x50 && a[2] === 0x4E) return ['image/png', 'png'];
  if (a[0] === 0xFF && a[1] === 0xD8) return ['image/jpeg', 'jpg'];
  if (a[0] === 0x47 && a[1] === 0x49 && a[2] === 0x46) return ['image/gif', 'gif'];
  if (a[0] === 0x52 && a[1] === 0x49 && a[8] === 0x57 && a[9] === 0x45) return ['image/webp', 'webp'];
  if (a[0] === 0x42 && a[1] === 0x4D) return ['image/bmp', 'bmp'];
  if (a[0] === 0 && a[1] === 0 && a[2] === 1 && a[3] === 0) return ['image/x-icon', 'ico'];
  const head = new TextDecoder().decode(u.slice(0, 200)).trim().toLowerCase();
  if (head.startsWith('<svg') || head.startsWith('<?xml')) return ['image/svg+xml', 'svg'];
  return null;
}
function b64ToBlob(str) {
  let s = (str || '').trim(), mime = '';
  const m = /^data:([^;,]*)(;[^,]*)?,/i.exec(s); if (m) { mime = m[1]; s = s.slice(m[0].length); }
  s = s.replace(/\s+/g, '').replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '=';
  const bin = atob(s), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
  const sn = sniffType(u); if (!sn) throw coded('DECODE');
  return { blob: new Blob([u], { type: sn[0] }), ext: sn[1], mime: sn[0] };
}
function mountB64Decode(root, tool) {
  let url = null, cur = null;
  root.innerHTML = `<div class="ws"><div class="card prev"><div class="prev-bar"><span class="c-t">📥 Paste your Base64 text below</span></div>
    <textarea class="ta" id="dTa" placeholder="Paste text like  data:image/png;base64,iVBORw0KGgo…  or just the Base64 code" aria-label="Base64 text"></textarea>
    <div class="prev-bar" style="margin-top:10px"><button type="button" class="btn-o" id="dFile">📁 Open a .txt file</button><button type="button" class="btn-o" id="dClr">Clear</button><input id="dIn" type="file" hidden accept=".txt,text/plain"></div>
    <div class="stage" id="dSt" style="margin-top:12px" hidden><img id="dImg" alt="Decoded picture" style="max-height:420px;max-width:100%;border-radius:8px"></div><div id="dErr"></div><div class="cap" id="dCap"></div></div>
    <div class="card set"><h3>🖼️ Your picture</h3><div class="sizebox" id="dSize">Paste text on the left and your picture appears here.</div>
      <div class="dl-wrap"><button type="button" class="btn-dl" id="dDl" disabled><span>⬇️ Download picture</span></button></div></div></div>`;
  const ta = $('#dTa', root), apply = () => {
    if (url) { URL.revokeObjectURL(url); url = null; } cur = null; $('#dErr', root).innerHTML = ''; $('#dSt', root).hidden = true; $('#dDl', root).disabled = true; $('#dCap', root).textContent = '';
    if (!ta.value.trim()) { $('#dSize', root).textContent = 'Paste text on the left and your picture appears here.'; return; }
    try {
      cur = b64ToBlob(ta.value); url = URL.createObjectURL(cur.blob); const im = $('#dImg', root); im.src = url; $('#dSt', root).hidden = false; $('#dDl', root).disabled = false;
      $('#dSize', root).innerHTML = `<big>${cur.ext.toUpperCase()}</big>${Engine.formatBytes(cur.blob.size)}`; im.onload = () => { $('#dCap', root).innerHTML = `<span>Decoded picture</span><b>${im.naturalWidth} × ${im.naturalHeight} px</b>`; };
    } catch (e) { $('#dErr', root).innerHTML = '<div class="err-box">😅 This text is not a picture. Check that you copied all of it.</div>'; $('#dSize', root).textContent = 'Waiting for a valid Base64 picture…'; }
  };
  ta.addEventListener('input', debounce(apply, 250));
  $('#dClr', root).onclick = () => { ta.value = ''; apply(); };
  $('#dFile', root).onclick = () => $('#dIn', root).click();
  $('#dIn', root).onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) { ta.value = await f.text(); apply(); } };
  $('#dDl', root).onclick = () => { if (cur) Anim.run({ src: $('img', root) || null, title: 'Saving your picture', work: async () => cur, save: c => Engine.download(c.blob, `decoded-picture.${c.ext}`), sub: c => Engine.formatBytes(c.blob.size) }).catch(() => {}); };
  S.cleanup = () => url && URL.revokeObjectURL(url);
}
T({ id: 'base64-to-image', title: 'Base64 to Picture', desc: 'Turn Base64 text back into a picture.', icon: '🖼️', menu: 'convert', group: 'Code & icons', kw: ['base64', 'decode', 'data uri', 'text to image', 'developer'], multiple: false, controls: [], mount: mountB64Decode,
  how: ['Paste your Base64 text (with or without data:image/…).', 'Your picture appears at once, so you can check it.', 'Press Download to save it as a normal picture file.'] });

/* ---------------------------------------------------------------------
   4. COLOR PICKER + PALETTE
   --------------------------------------------------------------------- */
const hex = (r, g, b) => '#' + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('').toUpperCase();
function extractPalette(canvas, n = 8) {
  const k = 120 / Math.max(canvas.width, canvas.height), w = Math.max(1, Math.round(canvas.width * k)), h = Math.max(1, Math.round(canvas.height * k));
  const s = Engine.resample(canvas, 0, 0, canvas.width, canvas.height, w, h), d = s.getContext('2d').getImageData(0, 0, w, h).data, B = new Map();
  let total = 0;
  for (let i = 0; i < d.length; i += 4) {
    if (d[i + 3] < 128) continue; const key = (d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | d[i + 2] >> 4;
    const e = B.get(key) || { n: 0, r: 0, g: 0, b: 0 }; e.n++; e.r += d[i]; e.g += d[i + 1]; e.b += d[i + 2]; B.set(key, e); total++;
  }
  const arr = [...B.values()].sort((a, b) => b.n - a.n).map(e => ({ r: e.r / e.n, g: e.g / e.n, b: e.b / e.n, n: e.n })), out = [];
  for (const c of arr) { if (out.length >= n) break; if (out.every(o => Math.hypot(o.r - c.r, o.g - c.g, o.b - c.b) > 52)) out.push(c); }
  return out.map(c => ({ hex: hex(c.r, c.g, c.b), pct: Math.round(c.n / total * 100) }));
}
function mountPalette(root, tool) {
  root.innerHTML = dzHTML(tool, { multiple: false, emoji: '🎨' });
  const go = async files => {
    const f = pickImages(files)[0]; if (!f) return; let im;
    try { im = await Engine.load(f, { maxSide: 1100 }); } catch (e) { toast(niceError(e), 'bad'); return; }
    const c = Engine.toCanvas(im); im.close && im.close();
    const pal = extractPalette(c, 8), picked = [];
    root.innerHTML = `<div class="ws"><div class="card prev"><div class="prev-bar"><span class="c-t">👆 Tap or drag on the picture to pick a color</span><button type="button" class="btn-o" id="pChange">🔁 Change picture</button><input id="pIn2" type="file" hidden accept="${ACCEPT}"></div>
      <div class="stage"><canvas id="pc" style="cursor:crosshair;touch-action:none" aria-label="Picture. Tap to pick a color."></canvas></div>
      <h4 style="margin:18px 0 0">🎨 Main colors in this picture <small style="font-weight:600;color:var(--muted)">(tap one to copy)</small></h4>
      <div class="swatches" id="pal">${pal.map(p => `<button type="button" class="swt" data-h="${p.hex}"><i style="background:${p.hex}"></i><span>${p.hex}</span><small>${p.pct}%</small></button>`).join('')}</div></div>
      <div class="card set"><h3>🎯 Picked color</h3><div class="big-hex"><i id="pSw" style="background:#fff"></i><div><b id="pHex">#FFFFFF</b><span id="pRgb">Tap the picture</span></div></div>
        <div class="dl-wrap" style="margin-top:14px"><button type="button" class="btn" id="pCopy">📋 Copy HEX</button><button type="button" class="btn-o" id="pCopyAll">Copy all palette colors</button><button type="button" class="btn-o danger" id="pAgain">↺ Start over</button></div>
        <h4 style="margin:18px 0 0">Colors you picked</h4><div class="swatches" id="hist"><p class="hint">Nothing yet.</p></div></div></div>`;
    const cv = $('#pc', root); cv.width = c.width; cv.height = c.height; const x = cv.getContext('2d', { willReadFrequently: true }); x.drawImage(c, 0, 0);
    let curHex = '#FFFFFF';
    const pick = e => {
      const r = cv.getBoundingClientRect(), px = clamp(Math.floor((e.clientX - r.left) / r.width * cv.width), 1, cv.width - 2), py = clamp(Math.floor((e.clientY - r.top) / r.height * cv.height), 1, cv.height - 2);
      const d = x.getImageData(px - 1, py - 1, 3, 3).data; let R = 0, G = 0, B = 0; for (let i = 0; i < 36; i += 4) { R += d[i]; G += d[i + 1]; B += d[i + 2]; }
      R /= 9; G /= 9; B /= 9; curHex = hex(R, G, B); $('#pSw', root).style.background = curHex; $('#pHex', root).textContent = curHex; $('#pRgb', root).textContent = `RGB ${Math.round(R)}, ${Math.round(G)}, ${Math.round(B)}`; return curHex;
    };
    let down = false; cv.onpointerdown = e => { down = true; cv.setPointerCapture(e.pointerId); pick(e); };
    cv.onpointermove = e => { if (down) pick(e); };
    cv.onpointerup = () => { if (!down) return; down = false; if (!picked.includes(curHex)) { picked.unshift(curHex); picked.length = Math.min(picked.length, 12); $('#hist', root).innerHTML = picked.map(h => `<button type="button" class="swt" data-h="${h}"><i style="background:${h}"></i><span>${h}</span></button>`).join(''); } };
    root.onclick = e => { const b = e.target.closest('.swt'); if (b) copyText(b.dataset.h); };
    $('#pCopy', root).onclick = () => copyText(curHex);
    $('#pCopyAll', root).onclick = () => copyText(pal.map(p => p.hex).join(', '));
    $('#pAgain', root).onclick = () => mountPalette(root, tool);
    $('#pChange', root).onclick = () => $('#pIn2', root).click(); $('#pIn2', root).onchange = e => { const q = [...e.target.files]; e.target.value = ''; go(q); };
  };
  bindDz(root, go); S.paste = go;
}
T({ id: 'color-picker', title: 'Color Picker & Palette', desc: 'Tap a picture to get any color code (HEX).', icon: '🎯', menu: 'info', group: 'Colors', kw: ['color', 'colour', 'picker', 'palette', 'hex', 'rgb', 'eyedropper', 'extract colors'], multiple: false, controls: [], mount: mountPalette,
  how: ['Choose a picture.', 'Tap or drag anywhere on it to pick a color. The main colors are listed for you too.', 'Tap a color to copy its HEX code.'] });

/* ---------------------------------------------------------------------
   5. BEFORE / AFTER COMPARE
   --------------------------------------------------------------------- */
function mountCompare(root, tool) {
  const sl = { a: null, b: null }; const urls = [];
  const slot = k => `<div class="card" style="padding:16px;text-align:center"><b style="font-size:19px">${k === 'a' ? '📷 Before' : '✨ After'}</b>
    ${sl[k] ? `<img src="${sl[k].url}" alt="" style="width:100%;height:170px;object-fit:contain;margin:10px 0;border-radius:10px;background:var(--surface2)"><div class="hint">${esc(sl[k].name)}</div>` : '<div style="font-size:54px;margin:14px 0">🖼️</div><p class="hint">No picture yet</p>'}
    <button type="button" class="btn sm" data-pick="${k}">${sl[k] ? 'Change' : 'Choose picture'}</button><input type="file" hidden accept="${ACCEPT}" data-in="${k}"></div>`;
  async function setSlot(k, f) {
    if (!f) return; try { const t = await asBlobUrl(f, 1800); urls.push(t.url); sl[k] = { url: t.url, name: f.name, w: t.w, h: t.h, canvas: t.canvas }; } catch (e) { toast(niceError(e), 'bad'); return; } draw();
  }
  function draw() {
    if (!sl.a || !sl.b) {
      root.innerHTML = `<p style="text-align:center;font-size:18px;color:var(--muted);margin:0 0 14px">Choose two pictures: the <b>before</b> and the <b>after</b>. You can pick both at once, or one by one.</p>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">${slot('a')}${slot('b')}</div>
        <div style="text-align:center;margin-top:16px"><button type="button" class="link" id="cSample">✨ No pictures? Try a sample</button></div>`;
      return;
    }
    const ar = sl.a.w / sl.a.h;
    root.innerHTML = `<div class="card prev"><div class="prev-bar"><span class="c-t">👆 Drag the line left and right</span><button type="button" class="btn-o" id="cReset">↺ Start over</button></div>
      <div class="stage"><div class="cmp" id="cmp" style="width:min(100%,${Math.round(ar * 640)}px);aspect-ratio:${sl.a.w}/${sl.a.h}"><img src="${sl.b.url}" alt="After"><div class="ov" id="ov" style="width:50%"><img id="ovi" src="${sl.a.url}" alt="Before"></div><span class="lb" style="left:10px">Before</span><span class="lb" style="right:10px">After</span><div class="hd" id="hd" style="left:50%" role="slider" tabindex="0" aria-label="Compare slider" aria-valuemin="0" aria-valuemax="100" aria-valuenow="50"></div></div></div>
      <div class="dl-wrap" style="margin-top:16px;max-width:420px;margin-inline:auto"><button type="button" class="btn-dl" id="cSave"><span>⬇️ Download side by side</span></button></div></div>`;
    const cmp = $('#cmp', root), ov = $('#ov', root), hd = $('#hd', root), ovi = $('#ovi', root);
    const setPos = p => { p = clamp(p, 0, 100); ov.style.width = p + '%'; hd.style.left = p + '%'; hd.setAttribute('aria-valuenow', Math.round(p)); ovi.style.width = (cmp.clientWidth) + 'px'; };
    setPos(50); let drag = false;
    const mv = e => { const r = cmp.getBoundingClientRect(); setPos((e.clientX - r.left) / r.width * 100); };
    cmp.onpointerdown = e => { drag = true; cmp.setPointerCapture(e.pointerId); mv(e); }; cmp.onpointermove = e => { if (drag) mv(e); }; cmp.onpointerup = () => { drag = false; };
    hd.onkeydown = e => { const v = +hd.getAttribute('aria-valuenow'); if (e.key === 'ArrowLeft') setPos(v - 3); if (e.key === 'ArrowRight') setPos(v + 3); };
    $('#cReset', root).onclick = () => { sl.a = sl.b = null; draw(); };
    $('#cSave', root).onclick = async () => {
      const H = Math.min(1400, Math.max(sl.a.canvas.height, sl.b.canvas.height)), wa = Math.round(sl.a.canvas.width * H / sl.a.canvas.height), wb = Math.round(sl.b.canvas.width * H / sl.b.canvas.height);
      const c = Engine.canvas(wa + wb + 12, H), x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
      x.drawImage(sl.a.canvas, 0, 0, wa, H); x.drawImage(sl.b.canvas, wa + 12, 0, wb, H);
      x.font = `800 ${Math.max(18, H / 30)}px system-ui,Arial`; x.textBaseline = 'middle';
      [['Before', 14], ['After', wa + 26]].forEach(([t, px]) => { const w = x.measureText(t).width + 24, h = Math.max(18, H / 30) * 1.7; x.fillStyle = 'rgba(0,0,0,.65)'; x.beginPath(); x.roundRect ? x.roundRect(px, 14, w, h, h / 2) : x.rect(px, 14, w, h); x.fill(); x.fillStyle = '#fff'; x.fillText(t, px + 12, 14 + h / 2); });
      await Anim.run({ src: c, title: 'Building before / after', work: () => Engine.toBlob(c, 'image/png'), save: b => Engine.download(b, 'before-after.png'), sub: b => Engine.formatBytes(b.size) });
    };
    window.addEventListener('resize', onR); S.cleanup = () => { window.removeEventListener('resize', onR); urls.forEach(u => URL.revokeObjectURL(u)); };
    function onR() { if (cmp.isConnected) setPos(+hd.getAttribute('aria-valuenow')); }
  }
  root.addEventListener('click', async e => {
    const p = e.target.closest('[data-pick]'); if (p) { $(`[data-in="${p.dataset.pick}"]`, root).click(); return; }
    if (e.target.closest('#cSample')) {
      const f = await Sample.file(), im = await Engine.load(f, { maxSide: 1200 }), c = Engine.toCanvas(im); im.close && im.close();
      const a = Engine.toCanvas({ src: c, w: c.width, h: c.height }); Pix.adjust(a, LOOKS.vintage.v); Pix.vignette(a, 35);
      sl.a = { url: URL.createObjectURL(await Engine.toBlob(c, 'image/png')), name: 'sample-before', w: c.width, h: c.height, canvas: c };
      sl.b = { url: URL.createObjectURL(await Engine.toBlob(a, 'image/png')), name: 'sample-after', w: a.width, h: a.height, canvas: a }; urls.push(sl.a.url, sl.b.url); draw();
    }
  });
  root.addEventListener('change', async e => {
    const i = e.target.closest('[data-in]'); if (!i) return; const files = pickImages([...i.files]); i.value = '';
    if (files.length >= 2 && !sl.a && !sl.b) { await setSlot('a', files[0]); await setSlot('b', files[1]); } else await setSlot(i.dataset.in, files[0]);
  });
  S.paste = async f => { const fs = pickImages(f); for (const x of fs) await setSlot(!sl.a ? 'a' : 'b', x); };
  draw();
}
T({ id: 'compare-slider', title: 'Before / After Slider', desc: 'Compare two pictures with a sliding line.', icon: '↔️', menu: 'info', group: 'Compare', kw: ['compare', 'before after', 'slider', 'difference', 'side by side'], multiple: true, controls: [], mount: mountCompare,
  how: ['Choose the BEFORE picture and the AFTER picture (or both at once).', 'Drag the line left and right to see the difference.', 'Download a side-by-side picture to share.'] });

startApp();