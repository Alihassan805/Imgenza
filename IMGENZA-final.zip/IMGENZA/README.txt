IMGENZA – FINAL PACKAGE  (README)
====================================

Is folder mein kya hai
----------------------
index.html          -> poori website ek hi file mein (double-click karke test kar sakte ho)
assets/             -> app.css + app.js (tool/category/page folders inhi ko use karte hain)
tool/<name>/        -> har tool ka apna alag web-address (Google ke liye)  e.g. /tool/png-to-jpg/
category/<name>/    -> har menu ka page    e.g. /category/convert/
page/               -> About, Privacy, Terms, Contact  (AdSense ke liye zaroori)
sitemap.xml, robots.txt, ads.txt, 404.html
set-domain.py       -> apna domain daalne ki chhoti script

Online kaise daalein (sab free)
-------------------------------
1. Netlify Drop (app.netlify.com/drop) ya Cloudflare Pages ya GitHub Pages par poora "IMGENZA" folder upload karo.
2. Jab domain mil jaye:   python3 set-domain.py https://tumhara-domain.com
   (sitemap, robots aur canonical links khud theek ho jayenge)
3. Google Search Console mein sitemap.xml submit karo.

Apni email / ads ki settings
----------------------------
index.html aur assets/app.js ke shuru mein (Ctrl+F karke dhoondo):
  const SITE = { ... email: '' }      -> apni contact email likho (Contact page par dikhegi)
  const ADS  = { enabled:false, client:'ca-pub-XXXXXXXXXXXXXXXX', slots:{top:'',side:'',inline:'',bottom:''}, showPlaceholders:true }
AdSense approve hone ke baad: enabled:true, apna client id aur 4 slot ids daalo, showPlaceholders:false karo.
ads.txt mein bhi apna pub-id likho.
(Dono jagah same change karna: index.html aur assets/app.js.)

AdSense approval ke liye tips
-----------------------------
- Site ko public domain par daalo, kam az kam kuch din chalne do, Search Console mein sitemap do.
- About / Privacy / Terms / Contact pages already bane hue hain; Contact mein apni asli email zaroor likho.
- Ads wale dabbe alag jagah par hain, koi tool ya button ads ke peeche nahi chhupta.

Privacy
-------
Saari pictures sirf user ke apne browser mein process hoti hain. Koi server ya upload nahi hai.
Sirf HEIC tool ek helper library internet se ek baar mangta hai.
