#!/usr/bin/env python3
"""Run once after you know your website address:   python3 set-domain.py https://mysite.com
It fixes the sitemap, robots.txt and the canonical links in every page."""
import os,sys
if len(sys.argv)<2: sys.exit('Usage: python3 set-domain.py https://yourdomain.com')
d=sys.argv[1].rstrip('/');n=0
for dp,_,fs in os.walk(os.path.dirname(os.path.abspath(__file__))):
    for f in fs:
        if f.endswith(('.html','.xml','.txt')):
            p=os.path.join(dp,f);s=open(p,encoding='utf-8').read()
            if 'https://YOUR-DOMAIN.com' in s: open(p,'w',encoding='utf-8').write(s.replace('https://YOUR-DOMAIN.com',d));n+=1
print('updated',n,'files')
